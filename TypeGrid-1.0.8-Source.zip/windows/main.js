const { app, BrowserWindow, ipcMain, dialog, clipboard, shell, protocol, net } = require('electron');
const { execFile } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const MAX_STATE_BYTES = 64 * 1024 * 1024;
const MAX_OPEN_FILE_BYTES = 32 * 1024 * 1024;
const MAX_MEDIA_BYTES = 24 * 1024 * 1024;

// Extensions exposed in Windows Explorer "Open with" without overriding defaults
const OPEN_WITH_EXTENSIONS = [
  '.txt', '.text', '.log', '.md', '.markdown', '.rtf', '.nfo', '.csv', '.tsv',
  '.json', '.json5', '.jsonl', '.xml', '.svg', '.yaml', '.yml', '.toml',
  '.ini', '.cfg', '.conf', '.env', '.properties', '.reg', '.inf',
  '.html', '.htm', '.css', '.scss', '.less', '.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx',
  '.py', '.pyw', '.java', '.c', '.cpp', '.cc', '.cxx', '.h', '.hpp', '.cs',
  '.go', '.rs', '.php', '.rb', '.sh', '.bash', '.zsh', '.bat', '.cmd', '.ps1',
  '.sql', '.lua', '.pl', '.r', '.swift', '.kt', '.dart', '.vue', '.svelte',
  '.gitignore', '.gitattributes', '.editorconfig', '.dockerignore'
];

const MIME_TO_EXT = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/bmp': 'bmp',
  'image/x-icon': 'ico',
  'image/vnd.microsoft.icon': 'ico',
  'image/avif': 'avif',
  'image/svg+xml': 'svg',
};

protocol.registerSchemesAsPrivileged([
  {
    scheme: 'typegrid-media',
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      corsEnabled: true,
    },
  },
]);

let mainWindow = null;
let rendererReady = false;
let startupFile = null;
let isAlwaysOnTop = false;
let saveChain = Promise.resolve(true);

const notesPath = () => path.join(app.getPath('userData'), 'notes.json');
const attachmentsDir = () => path.join(app.getPath('userData'), 'attachments');

function extractFilePath(argv) {
  if (!Array.isArray(argv)) return null;
  const appRoot = path.resolve(__dirname).toLowerCase();
  const exePath = process.execPath ? path.resolve(process.execPath).toLowerCase() : '';
  for (let i = 1; i < argv.length; i++) {
    const raw = argv[i];
    if (!raw || typeof raw !== 'string') continue;
    const arg = raw.trim().replace(/^"+|"+$/g, '');
    if (!arg || arg === '.' || arg.startsWith('-') || arg.startsWith('typegrid:') || arg.startsWith('about:')) {
      continue;
    }
    try {
      const resolved = path.resolve(arg);
      const low = resolved.toLowerCase();
      if (
        low === exePath ||
        low === appRoot ||
        low.endsWith('electron.exe') ||
        low.endsWith('typegrid.exe') ||
        low.endsWith('main.js') ||
        low.endsWith('main.cjs') ||
        low.endsWith('app.asar')
      ) {
        continue;
      }
      const st = fs.statSync(resolved);
      if (st.isFile()) return resolved;
    } catch {}
  }
  return null;
}

function decodeTextBuffer(buf) {
  if (buf.length >= 2 && buf[0] === 0xFF && buf[1] === 0xFE) {
    return { text: buf.subarray(2).toString('utf16le'), encoding: 'UTF-16 LE' };
  }
  if (buf.length >= 2 && buf[0] === 0xFE && buf[1] === 0xFF) {
    const swapped = Buffer.from(buf.subarray(2));
    swapped.swap16();
    return { text: swapped.toString('utf16le'), encoding: 'UTF-16 BE' };
  }
  if (buf.length >= 3 && buf[0] === 0xEF && buf[1] === 0xBB && buf[2] === 0xBF) {
    return { text: buf.subarray(3).toString('utf8'), encoding: 'UTF-8 BOM' };
  }

  const sampleLen = Math.min(buf.length, 8192);
  let ctrlCount = 0;
  for (let i = 0; i < sampleLen; i++) {
    const b = buf[i];
    if (b === 0x00) {
      return { binary: true };
    }
    if ((b < 0x08 || (b > 0x0d && b < 0x20 && b !== 0x1b))) {
      ctrlCount++;
    }
  }
  if (sampleLen > 0 && ctrlCount / sampleLen > 0.1) {
    return { binary: true };
  }
  return { text: buf.toString('utf8'), encoding: 'UTF-8' };
}

function readExternalFile(filePath) {
  try {
    const resolved = path.resolve(filePath);
    const st = fs.statSync(resolved);
    if (!st.isFile()) return null;
    const name = path.basename(resolved);
    const ext = path.extname(resolved);
    if (st.size > MAX_OPEN_FILE_BYTES) {
      return {
        name,
        path: resolved,
        ext,
        error: `File is too large (${Math.round(st.size / (1024 * 1024))} MB). Max supported size is 32 MB.`,
      };
    }
    const buf = fs.readFileSync(resolved);
    const decoded = decodeTextBuffer(buf);
    if (decoded.binary) {
      return {
        name,
        path: resolved,
        ext,
        binary: true,
        error: `"${name}" appears to be a binary file and cannot be edited as plain text.`,
      };
    }
    const eol = decoded.text.includes('\r\n') ? 'CRLF' : 'LF';
    return {
      name,
      path: resolved,
      ext,
      eol,
      encoding: decoded.encoding,
      content: decoded.text,
    };
  } catch (err) {
    console.error('Error reading external file:', err);
    return {
      name: path.basename(String(filePath || '')),
      path: String(filePath || ''),
      ext: path.extname(String(filePath || '')),
      error: err?.message || 'Could not read file.',
    };
  }
}

function normalizeEol(text, eol) {
  const lf = String(text ?? '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  return eol === 'CRLF' ? lf.replace(/\n/g, '\r\n') : lf;
}

function atomicSaveSync(data) {
  if (typeof data !== 'string' || Buffer.byteLength(data, 'utf8') > MAX_STATE_BYTES) return false;
  const target = notesPath();
  const temp = `${target}.${process.pid}.sync.tmp`;
  try {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(temp, data, 'utf8');
    fs.renameSync(temp, target);
    return true;
  } catch (error) {
    console.error('Could not save notes:', error);
    try { fs.unlinkSync(temp); } catch {}
    return false;
  }
}

function saveAsyncSerialized(data) {
  if (typeof data !== 'string' || Buffer.byteLength(data, 'utf8') > MAX_STATE_BYTES) {
    return Promise.resolve(false);
  }
  saveChain = saveChain.catch(() => false).then(async () => {
    const target = notesPath();
    const temp = `${target}.${process.pid}.tmp`;
    try {
      await fs.promises.mkdir(path.dirname(target), { recursive: true });
      await fs.promises.writeFile(temp, data, 'utf8');
      await fs.promises.rename(temp, target);
      return true;
    } catch (error) {
      console.error('Could not save notes async:', error);
      try { await fs.promises.unlink(temp); } catch {}
      return false;
    }
  });
  return saveChain;
}

function saveDataUrlToAttachment(dataUrl) {
  if (typeof dataUrl !== 'string') return null;
  if (dataUrl.startsWith('typegrid-media://')) return dataUrl;
  const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=\r\n]+)$/.exec(dataUrl);
  if (!match) return null;
  const mime = match[1].toLowerCase();
  const ext = MIME_TO_EXT[mime] || 'png';
  const buf = Buffer.from(match[2], 'base64');
  if (!buf.length || buf.length > MAX_MEDIA_BYTES) return null;
  const hash = crypto.createHash('sha1').update(buf).digest('hex').slice(0, 16);
  const filename = `img-${hash}.${ext}`;
  const dir = attachmentsDir();
  const fullPath = path.join(dir, filename);
  fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(fullPath)) {
    const tmp = `${fullPath}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, buf);
    fs.renameSync(tmp, fullPath);
  }
  return `typegrid-media://local/${filename}`;
}

function backupLegacyNotesIfLarge() {
  try {
    const target = notesPath();
    const backup = `${target}.v107.bak`;
    if (fs.existsSync(target) && !fs.existsSync(backup)) {
      const st = fs.statSync(target);
      if (st.size > 200 * 1024) {
        fs.copyFileSync(target, backup);
      }
    }
  } catch {}
}

function escapeReg(str) {
  return String(str).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

function registerWindowsOpenWith(force = false) {
  if (process.platform !== 'win32') return Promise.resolve({ ok: false, reason: 'not-windows' });
  const exePath = process.execPath;
  if (!exePath || path.basename(exePath).toLowerCase() === 'electron.exe') {
    return Promise.resolve({ ok: false, reason: 'dev-electron' });
  }

  const stampHash = crypto.createHash('sha1').update(`1.0.8|${exePath}|${OPEN_WITH_EXTENSIONS.length}`).digest('hex').slice(0, 12);
  const markerPath = path.join(app.getPath('userData'), `open-with-${stampHash}.ok`);
  if (!force && fs.existsSync(markerPath)) {
    return Promise.resolve({ ok: true, cached: true, exePath });
  }

  const exeEsc = escapeReg(exePath);
  const lines = [
    'Windows Registry Editor Version 5.00',
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\Applications\\TypeGrid.exe]',
    '"FriendlyAppName"="TypeGrid"',
    '@="TypeGrid"',
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\Applications\\TypeGrid.exe\\DefaultIcon]',
    `@="\\"${exeEsc}\\",0"`,
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\Applications\\TypeGrid.exe\\shell\\open]',
    '@="Open with TypeGrid"',
    `"Icon"="\\"${exeEsc}\\",0"`,
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\Applications\\TypeGrid.exe\\shell\\open\\command]',
    `@="\\"${exeEsc}\\" \\"%1\\""`,
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\Applications\\TypeGrid.exe\\SupportedTypes]',
  ];

  for (const ext of OPEN_WITH_EXTENSIONS) {
    lines.push(`"${ext}"=""`);
  }

  lines.push(
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\TypeGrid.Document]',
    '@="TypeGrid Text Document"',
    '"FriendlyTypeName"="TypeGrid Text Document"',
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\TypeGrid.Document\\DefaultIcon]',
    `@="\\"${exeEsc}\\",0"`,
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\TypeGrid.Document\\shell\\open]',
    '@="Open with TypeGrid"',
    `"Icon"="\\"${exeEsc}\\",0"`,
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\TypeGrid.Document\\shell\\open\\command]',
    `@="\\"${exeEsc}\\" \\"%1\\""`,
    '',
    '[HKEY_CURRENT_USER\\Software\\Classes\\*\\OpenWithList\\TypeGrid.exe]',
    '',
    '[HKEY_CURRENT_USER\\Software\\TypeGrid\\Capabilities]',
    '"ApplicationName"="TypeGrid"',
    '"ApplicationDescription"="Fast, lightweight autosaving notepad and code editor"',
    '',
    '[HKEY_CURRENT_USER\\Software\\TypeGrid\\Capabilities\\FileAssociations]'
  );

  for (const ext of OPEN_WITH_EXTENSIONS) {
    lines.push(`"${ext}"="TypeGrid.Document"`);
  }

  lines.push(
    '',
    '[HKEY_CURRENT_USER\\Software\\RegisteredApplications]',
    '"TypeGrid"="Software\\\\TypeGrid\\\\Capabilities"',
    ''
  );

  for (const ext of OPEN_WITH_EXTENSIONS) {
    lines.push(
      `[HKEY_CURRENT_USER\\Software\\Classes\\${ext}\\OpenWithProgids]`,
      '"TypeGrid.Document"=""',
      ''
    );
  }

  const regContent = lines.join('\r\n');
  const tempReg = path.join(app.getPath('temp'), `typegrid-openwith-${process.pid}.reg`);

  return new Promise((resolve) => {
    try {
      fs.writeFileSync(tempReg, Buffer.concat([Buffer.from([0xFF, 0xFE]), Buffer.from(regContent, 'utf16le')]));
    } catch (err) {
      return resolve({ ok: false, error: err?.message });
    }
    execFile('reg.exe', ['import', tempReg], { windowsHide: true }, (err) => {
      try { fs.unlinkSync(tempReg); } catch {}
      if (err) {
        return resolve({ ok: false, error: err.message });
      }
      try {
        fs.mkdirSync(path.dirname(markerPath), { recursive: true });
        fs.writeFileSync(markerPath, new Date().toISOString(), 'utf8');
      } catch {}
      // Notify Windows Explorer of association change
      execFile(
        'powershell.exe',
        [
          '-NoProfile',
          '-NonInteractive',
          '-Command',
          'Add-Type -Namespace Win32 -Name Shell -MemberDefinition \'[DllImport("shell32.dll")] public static extern void SHChangeNotify(int wEventId, int uFlags, IntPtr dwItem1, IntPtr dwItem2);\'; [Win32.Shell]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)'
        ],
        { windowsHide: true, timeout: 4000 },
        () => resolve({ ok: true, exePath, extensions: OPEN_WITH_EXTENSIONS.length })
      );
    });
  });
}

// Check startup argv once before window creation
const initArg = extractFilePath(process.argv);
if (initArg) {
  startupFile = readExternalFile(initArg);
}

function dispatchExternalFile(fileData) {
  if (!fileData) return;
  if (mainWindow && !mainWindow.isDestroyed() && rendererReady) {
    mainWindow.webContents.send('typegrid:open-external-file', fileData);
  } else {
    startupFile = fileData;
  }
}

function createWindow() {
  const iconPath = path.join(__dirname, 'assets', 'icon.ico');
  rendererReady = false;

  mainWindow = new BrowserWindow({
    width: 1320,
    height: 860,
    minWidth: 780,
    minHeight: 580,
    title: 'TypeGrid — Fast Autosaving Notes',
    icon: iconPath,
    frame: false,
    backgroundColor: '#f5f7f7',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      spellcheck: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, 'app', 'windows.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('maximize', () => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('typegrid:win-state', { maximized: true });
  });
  mainWindow.on('unmaximize', () => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('typegrid:win-state', { maximized: false });
  });

  const allowedLinks = new Set([
    'https://www.typegrid.site',
    'https://typegrid.site',
    'https://www.svgrepo.com',
    'https://creativecommons.org',
    'https://www.sadiqtbh.com',
    'https://sadiqtbh.com',
  ]);

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const parsed = new URL(url);
      if (allowedLinks.has(parsed.origin)) shell.openExternal(url);
    } catch {}
    return { action: 'deny' };
  });

  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (url !== mainWindow.webContents.getURL()) event.preventDefault();
  });
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (_, commandLine) => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
    const filePath = extractFilePath(commandLine);
    if (filePath) {
      const fileData = readExternalFile(filePath);
      if (fileData) dispatchExternalFile(fileData);
    }
  });

  app.whenReady().then(() => {
    protocol.handle('typegrid-media', (request) => {
      try {
        const parsed = new URL(request.url);
        const seg = parsed.pathname && parsed.pathname !== '/' ? parsed.pathname : parsed.hostname;
        const name = path.basename(decodeURIComponent(seg || ''));
        if (!name || !/^[a-zA-Z0-9._-]+$/.test(name)) {
          return new Response('Not found', { status: 404 });
        }
        const dir = attachmentsDir();
        const full = path.join(dir, name);
        if (!full.startsWith(dir + path.sep)) {
          return new Response('Forbidden', { status: 403 });
        }
        return net.fetch(pathToFileURL(full).toString());
      } catch {
        return new Response('Not found', { status: 404 });
      }
    });

    ipcMain.on('typegrid:load', (event) => {
      try {
        event.returnValue = fs.readFileSync(notesPath(), 'utf8');
      } catch {
        event.returnValue = null;
      }
    });

    ipcMain.on('typegrid:save', (event, data) => {
      event.returnValue = atomicSaveSync(data);
    });

    ipcMain.handle('typegrid:save-async', (_, data) => saveAsyncSerialized(data));

    ipcMain.handle('typegrid:save-attachment', (_, dataUrl) => {
      try {
        return saveDataUrlToAttachment(dataUrl);
      } catch (err) {
        console.error('save-attachment failed:', err);
        return null;
      }
    });

    ipcMain.handle('typegrid:migrate-attachments', (_, dataUrls) => {
      if (!Array.isArray(dataUrls)) return [];
      backupLegacyNotesIfLarge();
      return dataUrls.map((src) => {
        try {
          return saveDataUrlToAttachment(src) || src;
        } catch {
          return src;
        }
      });
    });

    ipcMain.on('typegrid:copy', (event, text) => {
      if (typeof text !== 'string') {
        event.returnValue = false;
        return;
      }
      clipboard.writeText(text);
      event.returnValue = true;
    });

    ipcMain.handle('typegrid:paste', () => clipboard.readText());

    ipcMain.handle('typegrid:open-file-dialog', async () => {
      const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Open File in TypeGrid',
        properties: ['openFile'],
        filters: [
          { name: 'All Files (*.*)', extensions: ['*'] },
          { name: 'Plain Text (*.txt, *.text, *.log, *.md)', extensions: ['txt', 'text', 'log', 'md', 'markdown', 'csv', 'tsv'] },
          { name: 'Web & Data (*.html, *.css, *.js, *.ts, *.json, *.xml, *.yaml)', extensions: ['html', 'htm', 'css', 'scss', 'less', 'js', 'jsx', 'ts', 'tsx', 'mjs', 'cjs', 'json', 'json5', 'xml', 'svg', 'yaml', 'yml', 'toml'] },
          { name: 'Code & Config (*.py, *.c, *.cpp, *.java, *.ini, *.env, etc.)', extensions: ['py', 'pyw', 'java', 'c', 'cpp', 'cc', 'cxx', 'h', 'hpp', 'cs', 'go', 'rs', 'php', 'rb', 'sh', 'bash', 'bat', 'cmd', 'ps1', 'sql', 'ini', 'cfg', 'conf', 'env'] },
        ],
      });
      if (result.canceled || !result.filePaths || !result.filePaths[0]) {
        return null;
      }
      return readExternalFile(result.filePaths[0]);
    });

    ipcMain.handle('typegrid:read-file', (_, filePath) => {
      if (typeof filePath !== 'string') return null;
      return readExternalFile(filePath);
    });

    ipcMain.handle('typegrid:get-startup-file', () => {
      rendererReady = true;
      const f = startupFile;
      startupFile = null;
      return f;
    });

    ipcMain.handle('typegrid:save-file', async (_, targetPath, text, eol) => {
      if (typeof targetPath !== 'string' || !targetPath.trim() || typeof text !== 'string') {
        return { ok: false, error: 'Invalid file target.' };
      }
      if (Buffer.byteLength(text, 'utf8') > MAX_STATE_BYTES) {
        return { ok: false, error: 'Content exceeds size limit.' };
      }
      try {
        const resolved = path.resolve(targetPath);
        const content = normalizeEol(text, eol);
        await fs.promises.writeFile(resolved, content, 'utf8');
        return {
          ok: true,
          path: resolved,
          name: path.basename(resolved),
          ext: path.extname(resolved),
        };
      } catch (err) {
        return { ok: false, error: err?.message || 'Failed to save file.' };
      }
    });

    ipcMain.handle('typegrid:export', async (_, text, suggestedName, eol) => {
      if (typeof text !== 'string' || Buffer.byteLength(text, 'utf8') > MAX_STATE_BYTES) return { ok: false };
      const rawName = path.basename(String(suggestedName || 'TypeGrid-note.txt')).replace(/[<>:"/\\|?*]/g, '_') || 'TypeGrid-note.txt';
      const parsed = path.parse(rawName);
      const extClean = (parsed.ext || '').replace(/^\./, '');
      const filters = [{ name: 'All Files (*.*)', extensions: ['*'] }];
      if (extClean && extClean.toLowerCase() !== 'txt') {
        filters.unshift({ name: `${extClean.toUpperCase()} File (*.${extClean})`, extensions: [extClean] });
      }
      filters.splice(extClean && extClean.toLowerCase() !== 'txt' ? 1 : 0, 0, { name: 'Text Files (*.txt)', extensions: ['txt'] });

      const result = await dialog.showSaveDialog(mainWindow, {
        title: 'Save File As',
        defaultPath: rawName,
        filters,
      });
      if (result.canceled || !result.filePath) return { ok: false, canceled: true };
      try {
        const content = normalizeEol(text, eol);
        await fs.promises.writeFile(result.filePath, content, 'utf8');
        return {
          ok: true,
          path: result.filePath,
          name: path.basename(result.filePath),
          ext: path.extname(result.filePath),
        };
      } catch (err) {
        return { ok: false, error: err?.message || 'Failed to save file.' };
      }
    });

    ipcMain.handle('typegrid:export-docx', async (_, b64, suggestedName) => {
      if (typeof b64 !== 'string' || b64.length > MAX_STATE_BYTES * 2) return false;
      const name = path.basename(String(suggestedName || 'TypeGrid-note.docx')).replace(/[<>:"/\\|?*]/g, '_');
      const result = await dialog.showSaveDialog(mainWindow, {
        defaultPath: name.endsWith('.docx') ? name : `${name}.docx`,
        filters: [{ name: 'Word documents', extensions: ['docx'] }],
      });
      if (result.canceled || !result.filePath) return false;
      try {
        fs.writeFileSync(result.filePath, Buffer.from(b64, 'base64'));
        return true;
      } catch {
        return false;
      }
    });

    ipcMain.handle('typegrid:export-pdf', async (_, html, suggestedName) => {
      if (typeof html !== 'string' || Buffer.byteLength(html, 'utf8') > MAX_STATE_BYTES) return false;
      const name = path.basename(String(suggestedName || 'TypeGrid-note.pdf')).replace(/[<>:"/\\|?*]/g, '_');
      const result = await dialog.showSaveDialog(mainWindow, {
        defaultPath: name.endsWith('.pdf') ? name : `${name}.pdf`,
        filters: [{ name: 'PDF documents', extensions: ['pdf'] }],
      });
      if (result.canceled || !result.filePath) return false;
      let printWin;
      try {
        printWin = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false } });
        await printWin.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
        const pdf = await printWin.webContents.printToPDF({ printBackground: true, pageSize: 'A4' });
        fs.writeFileSync(result.filePath, pdf);
        return true;
      } catch (error) {
        console.error('Could not export PDF:', error);
        return false;
      } finally {
        if (printWin) printWin.destroy();
      }
    });

    ipcMain.handle('typegrid:register-open-with', (_, force = true) => registerWindowsOpenWith(Boolean(force)));

    ipcMain.on('typegrid:set-theme', (_, theme) => {
      if (!mainWindow || mainWindow.isDestroyed()) return;
      mainWindow.setBackgroundColor(theme === 'dark' ? '#0e1116' : '#f5f7f7');
    });

    ipcMain.handle('typegrid:set-always-on-top', (_, flag) => {
      isAlwaysOnTop = Boolean(flag);
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.setAlwaysOnTop(isAlwaysOnTop, 'floating');
        return mainWindow.isAlwaysOnTop();
      }
      return isAlwaysOnTop;
    });

    ipcMain.handle('typegrid:get-always-on-top', () => {
      if (mainWindow && !mainWindow.isDestroyed()) return mainWindow.isAlwaysOnTop();
      return isAlwaysOnTop;
    });

    ipcMain.on('typegrid:window', (_, action) => {
      if (!mainWindow || mainWindow.isDestroyed()) return;
      if (action === 'min') mainWindow.minimize();
      if (action === 'max') mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
      if (action === 'close') mainWindow.close();
    });

    createWindow();
    setTimeout(() => {
      registerWindowsOpenWith(false).catch(() => {});
    }, 300);

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  });
}

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

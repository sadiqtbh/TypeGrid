
(()=>{if(window.TypeGridNative)document.body.classList.add('typegrid-native');const root=document.getElementById('typegrid'),content=root.querySelector('.content'),win=root.querySelector('.window'),picker=root.querySelector('select');let platform='windows',screen='notes',filter='',chosen=0,timer;let notes=[{title:'',tag:'Uncategorized',body:'',createdAt:new Date().toISOString()}];let setupComplete=false;let activeProfile='personal';const profiles={personal:{name:'Admin',photo:''},work:{name:'Work profile',photo:''}};let categories=[];let trash=[];const workspaces={personal:{notes,categories,trash},work:{notes:[],categories:[],trash:[]}};
let findOpen=false,replaceOpen=false,findQuery='',replaceQuery='',findMatchCase=false,findWholeWord=false,findMatches=[],currentMatchIdx=-1;
let isWordWrap=true,isFocusMode=false;
let saveDebounceTimer=null,pendingSaveState=false;
let editorSize=15;let editorFont='default';let customFont=null;let editorZoom=100;let uploadOpen=false;let noteSort='pinned';let editorTabSize=2;let openTabs=[0];let splitActive=false;let splitChosen=null;let activePane='primary';let isAlwaysOnTop=false;const bundledFonts=[['default','Default','sans'],['roboto','Roboto','sans'],['open-sans','Open Sans','sans'],['lato','Lato','sans'],['montserrat','Montserrat','sans'],['oswald','Oswald','sans'],['raleway','Raleway','sans'],['nunito','Nunito','sans'],['ubuntu','Ubuntu','sans'],['pt-sans','PT Sans','sans'],['work-sans','Work Sans','sans'],['dm-sans','DM Sans','sans'],['manrope','Manrope','sans'],['rubik','Rubik','sans'],['noto-sans','Noto Sans','sans'],['merriweather','Merriweather','serif'],['playfair-display','Playfair Display','serif'],['pt-serif','PT Serif','serif'],['libre-baskerville','Libre Baskerville','serif'],['crimson-pro','Crimson Pro','serif'],['noto-serif','Noto Serif','serif'],['jetbrains-mono','JetBrains Mono','mono'],['space-mono','Space Mono','mono']];const fontFamilyById=Object.fromEntries(bundledFonts.map(([id,label])=>[id,id==='default'?"'Figtree'":`'${label}'`]));function fontPickerMarkup(){const groups=[['Sans serif','sans'],['Serif','serif'],['Monospace','mono']];return `<div class="font-control" title="Editor font family"><span>Aa</span><select class="font-picker" aria-label="Note font"><option value="default" ${editorFont==='default'?'selected':''}>Default</option>${groups.map(([label,group])=>`<optgroup label="${label}">${bundledFonts.filter(([, ,kind])=>kind===group).map(([id,name])=>`<option value="${id}" ${editorFont===id?'selected':''}>${name}</option>`).join('')}</optgroup>`).join('')}${customFont?`<optgroup label="Your fonts"><option value="custom" ${editorFont==='custom'?'selected':''}>${esc(customFont.name)}</option></optgroup>`:''}</select><button type="button" class="font-add-btn" data-action="choose-font" aria-label="Import custom font" title="Import custom font (.ttf, .otf, .woff, .woff2)">+</button></div><input class="custom-font-upload" type="file" accept=".ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff,font/woff2" aria-label="Import custom font">`}
function toolsDropdownMarkup(){return `<div class="tg-tools-wrap"><button type="button" data-action="toggle-tools" aria-haspopup="menu" aria-expanded="false" title="Text transforms & utilities">Tools ▾</button><div class="tg-tools-menu" role="menu" hidden><button type="button" role="menuitem" data-action="tool-datetime"><span>Insert Date &amp; Time</span><kbd>F5</kbd></button><button type="button" role="menuitem" data-action="tool-dup-line"><span>Duplicate Line</span><kbd>Ctrl+D</kbd></button><button type="button" role="menuitem" data-action="note-copy"><span>Copy Entire Note</span></button><div class="tg-tools-divider"></div><button type="button" role="menuitem" data-action="tool-sort-asc"><span>Sort Lines A → Z</span></button><button type="button" role="menuitem" data-action="tool-sort-desc"><span>Sort Lines Z → A</span></button><button type="button" role="menuitem" data-action="tool-dedupe-blank"><span>Remove Blank Lines</span></button><button type="button" role="menuitem" data-action="tool-trim-lines"><span>Trim Trailing Spaces</span></button><div class="tg-tools-divider"></div><button type="button" role="menuitem" data-action="tool-upper"><span>UPPERCASE</span></button><button type="button" role="menuitem" data-action="tool-lower"><span>lowercase</span></button><button type="button" role="menuitem" data-action="tool-title"><span>Title Case</span></button></div></div>`}let menuIndex=null,shareOpen=false;const esc=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let toastTimer;const say=s=>{const t=root.querySelector('.toast');t.textContent=s;clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.textContent='',3000)};const solarIcons={"wrap":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" d=\"M3 6h18M3 12h14a3 3 0 0 1 0 6H11m0 0l2.5-2.5M11 18l2.5 2.5M3 18h4\"/></g>","find":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><circle cx=\"11.5\" cy=\"11.5\" r=\"9.5\"/><path stroke-linecap=\"round\" d=\"m18.5 18.5 3.5 3.5\"/></g>","replace":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" d=\"M4 12h11a3 3 0 0 1 3 3v1m0 0l2-2m-2 2l-2-2M20 7H9a3 3 0 0 0-3 3v1m0 0l2-2M6 11l-2-2\"/></g>","undo":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"m9 14-5-5 5-5\"/><path stroke-linecap=\"round\" d=\"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v1.5\"/></g>","redo":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"m15 14 5-5-5-5\"/><path stroke-linecap=\"round\" d=\"M20 9H9.5A5.5 5.5 0 0 0 4 14.5v1.5\"/></g>","go-to":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" d=\"M4 6h16M4 12h10m-10 6h6m8-3v6m0 0-2.5-2.5M18 21l2.5-2.5\"/></g>","info-circle":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><circle cx=\"12\" cy=\"12\" r=\"10\"/><path stroke-linecap=\"round\" d=\"M12 17v-6\"/><path stroke-linecap=\"round\" d=\"M12 8h.01\"/></g>","notebook-pen":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path d=\"m20.312 12.647l.517-1.932c.604-2.255.907-3.382.68-4.358a4 4 0 0 0-1.162-2.011c-.731-.685-1.859-.987-4.114-1.591c-2.255-.605-3.383-.907-4.358-.68a4 4 0 0 0-2.011 1.162c-.587.626-.893 1.543-1.348 3.209l-.244.905l-.517 1.932c-.605 2.255-.907 3.382-.68 4.358a4 4 0 0 0 1.162 2.011c.731.685 1.859.987 4.114 1.592c2.032.544 3.149.843 4.064.73q.15-.019.294-.052a4 4 0 0 0 2.011-1.16c.685-.732.987-1.86 1.592-4.115Z\"/><path d=\"M16.415 17.974a4 4 0 0 1-1.068 1.678c-.731.685-1.859.987-4.114 1.591s-3.383.907-4.358.679a4 4 0 0 1-2.011-1.161c-.685-.731-.988-1.859-1.592-4.114l-.517-1.932c-.605-2.255-.907-3.383-.68-4.358a4 4 0 0 1 1.162-2.011c.731-.685 1.859-.987 4.114-1.592q.638-.172 1.165-.309\"/><path stroke-linecap=\"round\" d=\"m11.777 10l4.83 1.294M11 12.898l2.898.776\"/></g>","square-pen":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" d=\"M22 10.5V12c0 4.714 0 7.071-1.465 8.535C19.072 22 16.714 22 12 22s-7.071 0-8.536-1.465C2 19.072 2 16.714 2 12s0-7.071 1.464-8.536C4.93 2 7.286 2 12 2h1.5\"/><path d=\"m16.652 3.455l.649-.649A2.753 2.753 0 0 1 21.194 6.7l-.65.649m-3.892-3.893s.081 1.379 1.298 2.595c1.216 1.217 2.595 1.298 2.595 1.298m-3.893-3.893L10.687 9.42c-.404.404-.606.606-.78.829q-.308.395-.524.848c-.121.255-.211.526-.392 1.068L8.412 13.9m12.133-6.552l-5.965 5.965c-.404.404-.606.606-.829.78a4.6 4.6 0 0 1-.848.524c-.255.121-.526.211-1.068.392l-1.735.579m0 0l-1.123.374a.742.742 0 0 1-.939-.94l.374-1.122m1.688 1.688L8.412 13.9\"/></g>","pencil":"<path fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" d=\"m14.36 4.079l.927-.927a3.932 3.932 0 0 1 5.561 5.561l-.927.927m-5.56-5.561s.115 1.97 1.853 3.707C17.952 9.524 19.92 9.64 19.92 9.64m-5.56-5.561l-8.522 8.52c-.577.578-.866.867-1.114 1.185a6.6 6.6 0 0 0-.749 1.211c-.173.364-.302.752-.56 1.526l-1.094 3.281m17.6-10.162L11.4 18.16c-.577.577-.866.866-1.184 1.114a6.6 6.6 0 0 1-1.211.749c-.364.173-.751.302-1.526.56l-3.281 1.094m0 0l-.802.268a1.06 1.06 0 0 1-1.342-1.342l.268-.802m1.876 1.876l-1.876-1.876\"/>","plus":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path d=\"M2 12c0-4.714 0-7.071 1.464-8.536C4.93 2 7.286 2 12 2s7.071 0 8.535 1.464C22 4.93 22 7.286 22 12s0 7.071-1.465 8.535C19.072 22 16.714 22 12 22s-7.071 0-8.536-1.465C2 19.072 2 16.714 2 12Z\"/><path stroke-linecap=\"round\" d=\"M15 12h-3m0 0H9m3 0V9m0 3v3\"/></g>","pin":"<path fill=\"currentColor\" d=\"m15.99 4.95l.53-.53zm3.082 3.086l-.531.53zM8.738 19.429l-.53.53zm-4.116-4.12l.53-.53zm12.945-.315l-.264-.702zm-1.917.72l.264.703zM8.332 8.383l-.704-.258zm.695-1.896l.704.258zm-3.182 4.188l.2.723zm1.457-.539l-.439-.609zm.374-.345l.57.487zm6.575 6.59l.491.568zm-.87 1.821l-.724-.199zm.536-1.454l-.61-.438zM2.718 12.755l-.75.005zm.212-.803l-.65-.374zm8.375 9.391l.001-.75zm.788-.208l-.371-.652zm-.396-19.099l.162.732zM1.47 21.47a.75.75 0 0 0 1.062 1.06zm5.715-3.598a.75.75 0 0 0-1.061-1.06zM15.459 5.48l3.082 3.086l1.061-1.06L16.52 4.42zM9.269 18.9l-4.117-4.12l-1.06 1.06l4.116 4.12zm8.034-4.607l-1.917.72l.528 1.405l1.917-.72zM9.036 8.64l.695-1.896l-1.409-.516l-.694 1.896zm-2.992 2.756c.712-.196 1.253-.334 1.696-.652l-.877-1.218c-.172.125-.397.198-1.217.424zm1.584-3.272c-.293.8-.385 1.018-.523 1.18l1.142.973c.353-.415.535-.944.79-1.637zm.112 2.62q.281-.203.507-.467l-1.142-.973a1.4 1.4 0 0 1-.242.222zm7.646 4.268c-.689.26-1.214.445-1.626.801l.982 1.135c.16-.14.377-.233 1.172-.531zM14.104 18.4c.225-.819.298-1.043.422-1.216l-1.219-.875c-.317.443-.454.983-.65 1.693zm-.344-2.586q-.256.22-.453.495l1.22.875q.093-.132.215-.236zm-8.608-1.036c-.646-.647-1.084-1.087-1.368-1.444c-.286-.359-.315-.514-.316-.583l-1.5.009c.004.582.293 1.07.642 1.508c.35.44.861.95 1.481 1.57zm.494-4.828c-.846.234-1.542.424-2.063.634c-.52.208-1.012.49-1.302.994l1.3.748c.034-.06.136-.18.56-.35s1.022-.337 1.903-.58zm-2.178 2.8a.84.84 0 0 1 .112-.424l-1.3-.748a2.34 2.34 0 0 0-.312 1.182zm4.74 7.21c.624.624 1.137 1.139 1.578 1.49c.441.352.932.642 1.518.643l.002-1.5c-.07 0-.225-.029-.585-.316c-.36-.286-.802-.727-1.452-1.378zm4.45-1.958c-.245.888-.412 1.49-.583 1.917c-.172.428-.293.53-.353.564l.743 1.303c.509-.29.792-.786 1.002-1.309c.21-.524.402-1.225.637-2.077zm-1.354 4.091c.407 0 .807-.105 1.161-.307l-.743-1.303a.84.84 0 0 1-.416.11zm7.237-13.527c1.064 1.064 1.8 1.803 2.25 2.413c.444.598.495.917.441 1.167l1.466.317c.19-.878-.16-1.647-.701-2.377c-.534-.72-1.366-1.551-2.395-2.58zm-.71 7.13c1.361-.511 2.463-.923 3.246-1.358c.795-.44 1.431-.996 1.621-1.875l-1.466-.317c-.054.25-.232.52-.883.88c-.663.369-1.638.737-3.046 1.266zM16.52 4.42c-1.036-1.037-1.872-1.876-2.595-2.414c-.734-.544-1.508-.897-2.39-.702l.324 1.464c.25-.055.569-.005 1.171.443c.613.455 1.358 1.197 2.429 2.27zM9.73 6.744c.522-1.423.886-2.41 1.251-3.08c.36-.66.628-.84.878-.896l-.323-1.464c-.882.194-1.435.84-1.872 1.642c-.431.792-.837 1.906-1.342 3.282zM2.53 22.53l4.654-4.658l-1.061-1.06l-4.654 4.658z\"/>","search":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><circle cx=\"11.5\" cy=\"11.5\" r=\"9.5\"/><path stroke-linecap=\"round\" d=\"M18.5 18.5L22 22\"/></g>","settings-2":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M13.765 2.152C13.398 2 12.932 2 12 2s-1.398 0-1.765.152a2 2 0 0 0-1.083 1.083c-.092.223-.129.484-.143.863a1.62 1.62 0 0 1-.79 1.353a1.62 1.62 0 0 1-1.567.008c-.336-.178-.579-.276-.82-.308a2 2 0 0 0-1.478.396C4.04 5.79 3.806 6.193 3.34 7s-.7 1.21-.751 1.605a2 2 0 0 0 .396 1.479c.148.192.355.353.676.555c.473.297.777.803.777 1.361s-.304 1.064-.777 1.36c-.321.203-.529.364-.676.556a2 2 0 0 0-.396 1.479c.052.394.285.798.75 1.605c.467.807.7 1.21 1.015 1.453a2 2 0 0 0 1.479.396c.24-.032.483-.13.819-.308a1.62 1.62 0 0 1 1.567.008c.483.28.77.795.79 1.353c.014.38.05.64.143.863a2 2 0 0 0 1.083 1.083C10.602 22 11.068 22 12 22s1.398 0 1.765-.152a2 2 0 0 0 1.083-1.083c.092-.223.129-.483.143-.863c.02-.558.307-1.074.79-1.353a1.62 1.62 0 0 1 1.567-.008c.336.178.579.276.819.308a2 2 0 0 0 1.479-.396c.315-.242.548-.646 1.014-1.453s.7-1.21.751-1.605a2 2 0 0 0-.396-1.479c-.148-.192-.355-.353-.676-.555A1.62 1.62 0 0 1 19.562 12c0-.558.304-1.064.777-1.36c.321-.203.529-.364.676-.556a2 2 0 0 0 .396-1.479c-.052-.394-.285-.798-.75-1.605c-.467-.807-.7-1.21-1.015-1.453a2 2 0 0 0-1.479-.396c-.24.032-.483.13-.82.308a1.62 1.62 0 0 1-1.566-.008a1.62 1.62 0 0 1-.79-1.353c-.014-.38-.05-.64-.143-.863a2 2 0 0 0-1.083-1.083Z\"/></g>","folder-plus":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" d=\"M10 14h2m0 0h2m-2 0v2m0-2v-2\"/><path d=\"M2 6.95c0-.883 0-1.324.07-1.692A4 4 0 0 1 5.257 2.07C5.626 2 6.068 2 6.95 2c.386 0 .58 0 .766.017a4 4 0 0 1 2.18.904c.144.119.28.255.554.529L11 4c.816.816 1.224 1.224 1.712 1.495a4 4 0 0 0 .848.352C14.098 6 14.675 6 15.828 6h.374c2.632 0 3.949 0 4.804.77q.119.105.224.224c.77.855.77 2.172.77 4.804V14c0 3.771 0 5.657-1.172 6.828S17.771 22 14 22h-4c-3.771 0-5.657 0-6.828-1.172S2 17.771 2 14z\"/></g>","folder":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" d=\"M18 10h-5\"/><path d=\"M2 6.95c0-.883 0-1.324.07-1.692A4 4 0 0 1 5.257 2.07C5.626 2 6.068 2 6.95 2c.386 0 .58 0 .766.017a4 4 0 0 1 2.18.904c.144.119.28.255.554.529L11 4c.816.816 1.224 1.224 1.712 1.495a4 4 0 0 0 .848.352C14.098 6 14.675 6 15.828 6h.374c2.632 0 3.949 0 4.804.77q.119.105.224.224c.77.855.77 2.172.77 4.804V14c0 3.771 0 5.657-1.172 6.828S17.771 22 14 22h-4c-3.771 0-5.657 0-6.828-1.172S2 17.771 2 14z\"/></g>","trash-2":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-width=\"1.5\" d=\"M9.17 4a3.001 3.001 0 0 1 5.66 0m5.67 2h-17m15.333 2.5l-.46 6.9c-.177 2.654-.265 3.981-1.13 4.79s-2.196.81-4.856.81h-.774c-2.66 0-3.991 0-4.856-.81c-.865-.809-.954-2.136-1.13-4.79l-.46-6.9M9.5 11l.5 5m4.5-5l-.5 5\"/>","image-plus":"<g fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-width=\"1.5\"><path d=\"M22 12c0 4.714 0 7.071-1.465 8.535C19.072 22 16.714 22 12 22s-7.071 0-8.536-1.465C2 19.072 2 16.714 2 12s0-7.071 1.464-8.536C4.93 2 7.286 2 12 2\"/><path d=\"m2 12.5l1.752-1.533a2.3 2.3 0 0 1 3.14.105l4.29 4.29a2 2 0 0 0 2.564.222l.299-.21a3 3 0 0 1 3.731.225L21 18.5m-6-13h3.5m0 0H22m-3.5 0V9m0-3.5V2\"/></g>","list-checks":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path d=\"M2 12c0-4.714 0-7.071 1.464-8.536C4.93 2 7.286 2 12 2s7.071 0 8.535 1.464C22 4.93 22 7.286 22 12s0 7.071-1.465 8.535C19.072 22 16.714 22 12 22s-7.071 0-8.536-1.465C2 19.072 2 16.714 2 12Z\"/><path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M6 15.8L7.143 17L10 14M6 8.8L7.143 10L10 7\"/><path stroke-linecap=\"round\" d=\"M13 9h5m-5 7h5\"/></g>","list":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-width=\"1.5\" d=\"M20 7H4m11 5H4m5 5H4\"/>","download":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"1.5\" d=\"M3 15c0 2.828 0 4.243.879 5.121C4.757 21 6.172 21 9 21h6c2.828 0 4.243 0 5.121-.879C21 19.243 21 17.828 21 15M12 3v13m0 0l4-4.375M12 16l-4-4.375\"/>","upload":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"1.5\" d=\"M3 15c0 2.828 0 4.243.879 5.121C4.757 21 6.172 21 9 21h6c2.828 0 4.243 0 5.121-.879C21 19.243 21 17.828 21 15m-9 1V3m0 0l4 4.375M12 3L8 7.375\"/>","share-2":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path d=\"M9 12a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0Z\"/><path stroke-linecap=\"round\" d=\"M14 6.5L9 10m5 7.5L9 14\"/><path d=\"M19 18.5a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0Zm0-13a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0Z\"/></g>","panel-left":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path d=\"M2 11c0-3.771 0-5.657 1.172-6.828S6.229 3 10 3h4c3.771 0 5.657 0 6.828 1.172S22 7.229 22 11v2c0 3.771 0 5.657-1.172 6.828S17.771 21 14 21h-4c-3.771 0-5.657 0-6.828-1.172S2 16.771 2 13z\"/><path stroke-linecap=\"round\" d=\"M15 21V3\"/></g>","bold":"<path fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" d=\"M5 4.609A2.61 2.61 0 0 1 7.609 2H12a5 5 0 0 1 0 10H5zM5 12h9a5 5 0 0 1 0 10H7.059A2.06 2.06 0 0 1 5 19.941z\"/>","italic":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"1.5\" d=\"M3 22h12M9 2h12M9 22l6-20\"/>","underline":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"1.5\" d=\"M4 21h16M4 3v6a8 8 0 1 0 16 0V3\"/>","strikeThrough":"<g fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-width=\"1.5\"><path stroke-linejoin=\"round\" d=\"M12 3H8c-1.886 0-2.828 0-3.414.586S4 5.114 4 7v.95M12 3h4c1.886 0 2.828 0 3.414.586S20 5.114 20 7v.95M12 3v6m0 12v-6m-5 6h10\"/><path d=\"M4 12h16\"/></g>","removeFormat":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"1.5\" d=\"m18.364 8.05l-.707-.707a8 8 0 1 0 2.28 4.658m-1.573-3.95h-4.243m4.243 0V3.807\"/>","copy":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path d=\"M6 11c0-2.828 0-4.243.879-5.121C7.757 5 9.172 5 12 5h3c2.828 0 4.243 0 5.121.879C21 6.757 21 8.172 21 11v5c0 2.828 0 4.243-.879 5.121C19.243 22 17.828 22 15 22h-3c-2.828 0-4.243 0-5.121-.879C6 20.243 6 18.828 6 16z\"/><path d=\"M6 19a3 3 0 0 1-3-3v-6c0-3.771 0-5.657 1.172-6.828S7.229 2 11 2h4a3 3 0 0 1 3 3\"/></g>","cut":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-width=\"1.5\" d=\"M16.401 20.5L6 2m16 17a3 3 0 1 1-6 0a3 3 0 0 1 6 0ZM7.599 20.5L18 2M2 19a3 3 0 1 0 6 0a3 3 0 0 0-6 0Z\"/>","paste":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path d=\"M16 4.002c2.175.012 3.353.109 4.121.877C21 5.758 21 7.172 21 10v6c0 2.829 0 4.243-.879 5.122C19.243 22 17.828 22 15 22H9c-2.828 0-4.243 0-5.121-.878C3 20.242 3 18.829 3 16v-6c0-2.828 0-4.242.879-5.121c.768-.768 1.946-.865 4.121-.877\"/><path stroke-linecap=\"round\" d=\"M8 14h8m-9-3.5h10m-8 7h6\"/><path d=\"M8 3.5A1.5 1.5 0 0 1 9.5 2h5A1.5 1.5 0 0 1 16 3.5v1A1.5 1.5 0 0 1 14.5 6h-5A1.5 1.5 0 0 1 8 4.5z\"/></g>","all":"<g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"><path stroke-linecap=\"round\" d=\"M9 9h6m-3 6V9\"/><path d=\"M6 4a2 2 0 1 1-4 0a2 2 0 0 1 4 0Zm0 16a2 2 0 1 1-4 0a2 2 0 0 1 4 0ZM22 4a2 2 0 1 1-4 0a2 2 0 0 1 4 0Zm0 16a2 2 0 1 1-4 0a2 2 0 0 1 4 0Z\"/><path stroke-linecap=\"round\" d=\"M6 20h12m0-16H6m14 14V6M4 6v12\"/></g>","line":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-width=\"1.5\" d=\"M20 7H4m11 5H4m5 5H4\"/>","with-above":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"1.5\" d=\"M12 20V4m0 0l6 6m-6-6l-6 6\"/>","with-below":"<path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"1.5\" d=\"M12 4v16m0 0l6-6m-6 6l-6-6\"/>"};function solarIcon(name){return '<svg class="tg-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">'+(solarIcons[name]||solarIcons['notebook-pen'])+'</svg>'}function icons(){root.querySelectorAll('[data-tg-icon]').forEach(el=>{el.outerHTML=solarIcon(el.dataset.tgIcon)})}function saveState(){window.openai?.setWidgetState?.({modelContent:{platform,screen},privateContent:{chosen}})?.catch(()=>{})}function noteMenu(i,n){if(menuIndex!==i)return '';return `<div class="note-actions" role="group" aria-label="Actions for ${esc(n.title)}"><button data-action="note-copy"><i data-tg-icon="copy" aria-hidden="true"></i>Copy</button><button data-action="note-pin"><i data-tg-icon="pin" aria-hidden="true"></i>${n.pinned?'Unpin':'Pin'}</button><button data-action="note-duplicate"><i data-tg-icon="plus" aria-hidden="true"></i>Duplicate</button><button data-action="note-edit"><i data-tg-icon="pencil" aria-hidden="true"></i>Edit</button><button data-action="note-split"><i data-tg-icon="panel-left" aria-hidden="true"></i>Open Side-by-Side</button><button data-action="note-image"><i data-tg-icon="image-plus" aria-hidden="true"></i>+ Image</button><button data-action="note-share"><i data-tg-icon="share-2" aria-hidden="true"></i>Share</button><button data-action="note-delete" class="delete-action"><i data-tg-icon="trash-2" aria-hidden="true"></i>Delete</button></div>`}function sharePanel(n){if(!shareOpen)return '';const fullText=(n.title&&!n.filePath&&!n.fileExt?n.title+'\n\n':'')+(n.body||'');return `<section class="share-panel" aria-label="Share note"><div class="editorhead"><strong>Share note</strong><span class="spacer"></span><button data-action="close-share" aria-label="Close share preview">×</button></div><textarea class="share-text" aria-label="Text to share" readonly>${esc(fullText)}</textarea><div class="share-buttons"><button data-action="copy-note">Copy text</button><button data-action="export">Save ${n.fileExt?esc(n.fileExt):'.txt'}</button><button data-action="export-pdf">Download PDF</button><button data-action="export-docx">Download Word</button></div><p class="upload-hint">Text only. Image attachments stay in your note.</p></section>`}function cardTimeLabel(iso){if(!iso)return 'New note';const d=new Date(iso),now=new Date();return d.toDateString()===now.toDateString()?d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'}):d.toLocaleDateString('en-US',{month:'short',day:'numeric'})}
function cards(q=''){const qq=q.toLowerCase();const result=notes.map((n,i)=>({n,i})).filter(({n})=>(!filter||filter==='Pinned'&&n.pinned||n.tag===filter)&&((n.title||'')+' '+(n.body||'')).toLowerCase().includes(qq));result.sort((a,b)=>{if(noteSort==='pinned'&&!!a.n.pinned!==!!b.n.pinned)return a.n.pinned?-1:1;if(noteSort==='title')return (a.n.title||'').localeCompare(b.n.title||'');const ka=noteSort==='created'?(a.n.createdAt||a.n.updatedAt||''):(a.n.updatedAt||a.n.createdAt||'');const kb=noteSort==='created'?(b.n.createdAt||b.n.updatedAt||''):(b.n.updatedAt||b.n.createdAt||'');return kb.localeCompare(ka)});return result.map(({n,i})=>`<div class="note-item"><button class="notecard ${i===chosen?'selected':''}" data-note="${i}"><strong>${n.pinned?'⌑ &nbsp; ':''}${esc(n.title)||'Untitled note'}</strong><p>${esc((n.body||'').slice(0,120).trim())||'Empty note'}</p><span class="meta"><span>${esc(n.fileExt?n.fileExt.slice(1).toUpperCase():n.tag)}</span><span>${cardTimeLabel(n.updatedAt||n.createdAt)}</span></span></button><button class="note-more" data-note-options="${i}" aria-label="Note actions" title="Note options">⋯</button>${noteMenu(i,n)}</div>`).join('')||'<p class="empty">No notes found.</p>'}function attachmentBlock(n){const files=n.images||[];if(!files.length)return '';return `<div class="attachment-row"><button class="attachment-folder" data-action="attachments" aria-label="Preview ${files.length} attached images" aria-expanded="false"><span class="folder-back"></span>${files.slice(0,3).map((f,i)=>`<img class="file-peek" style="--file-i:${files.length===1?1:i}" src="${f.url}" alt="">`).join('')}<span class="folder-front"></span></button><div class="attachment-info"><strong>${files.length} image${files.length===1?'':'s'} attached</strong><small>${platform==='android'?'Tap to view images':'Hover to peek · Click to view'}</small></div></div><div class="attachment-gallery" hidden><div class="editorhead"><strong>Attached images</strong><span class="spacer"></span><button data-action="attachments">Close preview</button></div><div class="gallery-grid">${files.map(f=>`<figure><img src="${f.url}" alt="${esc(f.name)}"><figcaption>${esc(f.name)}</figcaption></figure>`).join('')}</div></div>`}function uploadPanel(){const files=notes[chosen]?.images||[];return `<section class="upload-panel" ${uploadOpen?'':'hidden'} aria-label="Add images"><div class="upload-heading"><strong>Add images to your note</strong><span class="spacer"></span><button data-action="close-upload" aria-label="Close image upload">×</button></div><button class="upload-drop" data-action="choose-images" aria-label="Drop images here or choose image files"><strong>Upload images</strong><small>Drag and drop your images here, or click to choose</small><span class="upload-tile"><i data-tg-icon="upload" aria-hidden="true"></i></span></button><div class="upload-files">${files.map(f=>`<div class="upload-file"><img src="${f.url}" alt=""><span class="file-name">${esc(f.name)}</span><small>✓ Attached</small></div>`).join('')}</div><p class="upload-hint">Images stay tucked inside your note’s folder.</p></section>`}async function readLocalPicture(file,size=1024){if(file.size>20*1024*1024)throw Error('Choose an image smaller than 20 MB.');const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('Could not read image.'));reader.readAsDataURL(file)});const image=await new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(Error('This image format is not supported.'));im.src=data});const ratio=Math.min(1,size/Math.max(image.naturalWidth,image.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*ratio));canvas.height=Math.max(1,Math.round(image.naturalHeight*ratio));canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);return canvas.toDataURL('image/webp',.88)}async function addImages(fileList){const incoming=Array.from(fileList).filter(f=>f.type.startsWith('image/'));if(!incoming.length){say('Choose an image file to attach.');return}const note=notes[chosen];if(!note)return;note.images=note.images||[];try{for(const f of incoming){let url=await readLocalPicture(f);if(window.TypeGridNative?.saveAttachment){const storedUrl=await window.TypeGridNative.saveAttachment(url);if(storedUrl)url=storedUrl}note.images.push({name:f.name,url})}uploadOpen=true;const saved=persistNotes();if(screen==='editor'&&getBodyEl()){syncAttachmentUI();const up=root.querySelector('.upload-panel');if(up)up.hidden=false}else{render()}say(saved?incoming.length+' image'+(incoming.length===1?'':'s')+' attached and saved':'Could not save the images.')}catch(err){say(err.message)}}function editor(){ensureTabOpen(chosen);const n=notes[chosen];if(!n)return '<section class="editor editor-empty"><h2>A fresh space for your ideas</h2><button class="primary" data-action="new">+ Create a note</button></section>';const activeNote=notes[getPaneIndex()]||n;const m=computeBodyMetrics(activeNote.body||'');const saveBtnLabel=activeNote.fileExt?esc(activeNote.fileExt):'Save';const pathBadge=n.filePath?`<span class="file-path-badge" title="${esc(n.filePath)}">${esc(n.fileName||n.filePath)}</span>`:'';const tagBadge=`<span class="head-tag">${n.tag==='Uncategorized'?'Note':esc(n.tag)}</span>`;const tabsHtml=openTabs.map(idx=>{const tn=notes[idx];if(!tn)return '';const lbl=(tn.fileName||tn.title||'').trim()||'Untitled note';return `<div class="note-tab ${idx===chosen?'active':''}"><button type="button" class="note-tab-btn" data-tab="${idx}" title="${esc(lbl)}">${esc(lbl)}</button><button type="button" class="note-tab-close" data-close-tab="${idx}" aria-label="Close tab">×</button></div>`}).join('');const rightNote=splitActive&&splitChosen!==null&&notes[splitChosen]?notes[splitChosen]:null;const splitOptions=notes.map((sn,si)=>`<option value="${si}" ${si===splitChosen?'selected':''}>${esc((sn.title||'').trim()||'Untitled note')}</option>`).join('');const splitPaneHtml=rightNote?`<div class="writing-pane split-pane ${activePane==='split'?'is-active':''}" data-pane="split"><div class="split-pane-head"><select class="split-note-picker" aria-label="Choose note for right side">${splitOptions}</select><button type="button" data-action="swap-split" title="Swap left & right notes">⇄</button><button type="button" data-action="split-new" title="Create new note in right side">+</button><button type="button" data-action="close-split" title="Close side-by-side split">×</button></div><textarea class="note-title" rows="1" spellcheck="false" placeholder="Note title" aria-label="Split note title">${esc(rightNote.title)}</textarea><textarea aria-label="Split note content" spellcheck="false" class="note-body ${isWordWrap?'word-wrap':'no-wrap'}" placeholder="Type notes, code, or plain text here...">${esc(rightNote.body)}</textarea></div>`:'';return `<section class="editor"><div class="notetabs-bar"><div class="notetabs-list">${tabsHtml}<button type="button" class="note-tab-add" data-action="new" title="Open new tab (Ctrl+N)" aria-label="New tab">+</button></div>${tagBadge}${pathBadge}<div class="editorhead-actions"><button type="button" data-action="toggle-split" class="${splitActive?'active':''}" title="Split view: edit two notes side by side (Ctrl+\\)">◫ Split</button><button type="button" data-action="note-copy" title="Copy note text">Copy All</button><button type="button" data-action="note-duplicate" title="Duplicate note">Dup</button>${activeNote.filePath?'<button type="button" data-action="save-file" title="Save file (Ctrl+S)">Save File</button>':''}<button type="button" data-action="pin" class="${n.pinned?'active':''}" aria-label="Pin note">${n.pinned?'Pinned':'Pin'}</button><button type="button" data-action="delete" aria-label="Move note to trash">Trash</button></div></div><div class="toolbar"><button data-action="open-file" title="Open any file (Ctrl+O)"><i data-tg-icon="folder" aria-hidden="true"></i>Open</button><button data-action="export" title="Save As / Export file (Ctrl+Shift+S)"><i data-tg-icon="download" aria-hidden="true"></i>${saveBtnLabel}</button><span class="tb-sep" aria-hidden="true"></span><button class="tb-icon-only" data-action="editor-undo" aria-label="Undo (Ctrl+Z)" title="Undo (Ctrl+Z)"><i data-tg-icon="undo" aria-hidden="true"></i></button><button class="tb-icon-only" data-action="editor-redo" aria-label="Redo (Ctrl+Y)" title="Redo (Ctrl+Y)"><i data-tg-icon="redo" aria-hidden="true"></i></button><span class="tb-sep" aria-hidden="true"></span><button data-action="editor-cut" title="Cut (Ctrl+X)"><i data-tg-icon="cut" aria-hidden="true"></i>Cut</button><button data-action="editor-copy" title="Copy (Ctrl+C)"><i data-tg-icon="copy" aria-hidden="true"></i>Copy</button><button data-action="editor-paste" title="Paste (Ctrl+V)"><i data-tg-icon="paste" aria-hidden="true"></i>Paste</button><span class="tb-sep" aria-hidden="true"></span><button data-action="open-find" class="${findOpen?'active':''}" title="Find &amp; Replace (Ctrl+F)"><i data-tg-icon="find" aria-hidden="true"></i>Find</button><button data-action="goto-line" title="Go to Line (Ctrl+G)"><i data-tg-icon="go-to" aria-hidden="true"></i>Go to</button><button data-action="toggle-wrap" class="${isWordWrap?'active':''}" title="Toggle Word Wrap (Ctrl+W)"><i data-tg-icon="wrap" aria-hidden="true"></i>Wrap</button><span class="tb-sep" aria-hidden="true"></span><button data-action="insert" data-text="☐ " aria-label="Insert checklist" title="Insert checklist item"><i data-tg-icon="list-checks" aria-hidden="true"></i>Check</button><button data-action="insert" data-text="• " aria-label="Insert bullet" title="Insert bullet item"><i data-tg-icon="list" aria-hidden="true"></i>List</button><button data-action="add-image" title="Attach image"><i data-tg-icon="image-plus" aria-hidden="true"></i>Image</button><input class="image-upload" type="file" accept="image/*" multiple aria-label="Attach images">${toolsDropdownMarkup()}<span class="tb-sep" aria-hidden="true"></span><button data-action="export-pdf" title="Export PDF (Ctrl+P)"><i data-tg-icon="download" aria-hidden="true"></i>PDF</button><button data-action="export-docx" title="Export Word (.docx)"><i data-tg-icon="download" aria-hidden="true"></i>Word</button>${fontPickerMarkup()}${categoryDropdown(n)}</div>${uploadPanel()}${sharePanel(n)}${findReplaceMarkup()}<div class="writing-sheet"><div class="writing-split ${rightNote?'is-split':''}"><div class="writing-pane primary-pane ${activePane==='primary'?'is-active':''}" data-pane="primary"><textarea class="note-title" rows="1" spellcheck="false" placeholder="Note title" aria-label="Note title">${esc(n.title)}</textarea><textarea aria-label="Note content" spellcheck="false" class="note-body ${isWordWrap?'word-wrap':'no-wrap'}" placeholder="Type notes, code, or plain text here...">${esc(n.body)}</textarea><div class="attachment-slot">${attachmentBlock(n)}</div></div>${splitPaneHtml}</div>${timeIsland(n)}<div class="notepad-status-bar" role="status" aria-label="Notepad status"><div class="status-left"><button type="button" class="status-item status-action status-lncol" data-action="goto-line" title="Go to Line (Ctrl+G)">Ln 1, Col 1</button><span class="status-item status-lines">${m.lines} line${m.lines===1?'':'s'}</span><span class="status-item status-chars">${(activeNote.body||'').length.toLocaleString()} chars</span><span class="status-item status-words">${m.words.toLocaleString()} words</span><span class="status-item status-selection" hidden></span></div><div class="status-right"><div class="zoom-controls" aria-label="Editor zoom"><button data-action="zoom-out" aria-label="Zoom out" ${editorZoom<=50?'disabled':''}>−</button><button data-action="zoom-reset" aria-label="Reset zoom to 100 percent">${editorZoom}%</button><button data-action="zoom-in" aria-label="Zoom in" ${editorZoom>=200?'disabled':''}>+</button></div><button type="button" class="status-item status-action status-eol" data-action="toggle-eol" title="Click to toggle CRLF / LF">${activeNote.eol==='LF'?'Unix (LF)':'Windows (CRLF)'}</button><span class="status-item status-enc">${esc(activeNote.encoding||'UTF-8')}</span><span class="status-item status-saved">${n.updatedAt?'✓ Saved locally':'Autosave ready'}</span></div></div></div></section>`}function categoryDropdown(n){if(!categories.length)return '';const h=52+categories.length*40+12;return `<div class="goo-dropdown" style="--goo-height:${h}px" aria-label="Addon categories"><div class="goo-dropdown-blobs" aria-hidden="true"><div class="goo-dropdown-pill"></div><div class="goo-dropdown-shape"></div></div><button class="goo-dropdown-trigger" data-action="toggle-addon" aria-haspopup="menu" aria-expanded="false">Addon${n.tag==='Uncategorized'?'':' ('+esc(n.tag)+')'} <span aria-hidden="true">⌄</span></button><div class="goo-dropdown-content" inert><div class="goo-dropdown-menu" role="menu" aria-label="Choose note category">${categories.map((c,i)=>`<button role="menuitem" data-addon-index="${i}">${esc(c)}</button>`).join('')}</div></div></div>`}function gooeySearch(label,placeholder){return `<div class="gooey-search"><div class="gooey-surfaces"><span class="gooey-pill"></span><span class="gooey-bubble"></span></div><button class="gooey-trigger" data-action="open-search" aria-label="Open note search" aria-expanded="false">${solarIcon('search')}<span class="gooey-label">Search</span></button><input class="search" aria-label="${label}" placeholder="${placeholder}"><button class="gooey-clear" data-action="close-search" aria-label="Clear and close search">×</button></div>`}
const reducedMotion=()=>true;
let activeEditorField='body';
let _metricsSrc=null,_metricsLines=1,_metricsWords=0;
function getActivePaneKey(){return splitActive&&activePane==='split'&&splitChosen!==null?'split':'primary'}
function getPaneIndex(paneKey=getActivePaneKey()){return paneKey==='split'&&splitChosen!==null?splitChosen:chosen}
function getPaneContainer(paneKey=getActivePaneKey()){return root.querySelector(`.writing-pane[data-pane="${paneKey}"]`)||root.querySelector('.writing-pane')}
function getTitleEl(paneKey=getActivePaneKey()){return getPaneContainer(paneKey)?.querySelector('.note-title')||root.querySelector('.note-title')}
function getBodyEl(paneKey=getActivePaneKey()){return getPaneContainer(paneKey)?.querySelector('textarea.note-body')||root.querySelector('textarea.note-body')}
function getTargetField(){
  const active=document.activeElement;
  if(active&&active.matches&&active.matches('.editor .note-title, .editor textarea.note-body'))return active;
  return activeEditorField==='title'?(getTitleEl()||getBodyEl()):(getBodyEl()||getTitleEl());
}
function ensureTabOpen(idx){
  if(idx!=null&&idx>=0&&idx<notes.length&&!openTabs.includes(idx))openTabs.push(idx);
  openTabs=[...new Set(openTabs)].filter(i=>i>=0&&i<notes.length);
  if(notes.length&&!openTabs.length)openTabs=[Math.max(0,Math.min(chosen,notes.length-1))];
}
function onNoteInsertedAtZero(){
  openTabs=openTabs.map(i=>i+1);
  if(!openTabs.includes(0))openTabs.unshift(0);
  if(splitChosen!==null)splitChosen+=1;
  chosen=0;
  activePane='primary';
}
function onNoteRemovedAt(idx){
  openTabs=openTabs.filter(i=>i!==idx).map(i=>i>idx?i-1:i);
  if(splitChosen!==null){
    if(splitChosen===idx){splitActive=false;splitChosen=null;activePane='primary'}
    else if(splitChosen>idx)splitChosen-=1;
  }
  if(chosen>=notes.length)chosen=Math.max(0,notes.length-1);
  else if(chosen>idx)chosen-=1;
  ensureTabOpen(chosen);
}
function closeCatMenu(){
  const m=root.querySelector('.topbar-cat-menu'),btn=root.querySelector('[data-action="toggle-cats"]');
  if(m)m.hidden=true;
  if(btn)btn.setAttribute('aria-expanded','false');
}
async function toggleAlwaysOnTop(explicitVal=null){
  isAlwaysOnTop=explicitVal===null?!isAlwaysOnTop:Boolean(explicitVal);
  if(window.TypeGridNative?.setAlwaysOnTop){
    try{isAlwaysOnTop=await window.TypeGridNative.setAlwaysOnTop(isAlwaysOnTop)}catch(_){}
  }
  root.querySelectorAll('[data-action="toggle-always-on-top"]').forEach(btn=>{
    btn.classList.toggle('active',isAlwaysOnTop);
    btn.setAttribute('aria-pressed',String(isAlwaysOnTop));
  });
  scheduleSave(200);
  if(explicitVal===null)say(isAlwaysOnTop?'App pinned Always on Top (Alt+P to unpin)':'App unpinned from Always on Top');
}
function closeToolsMenu(){
  const wrap=root.querySelector('.tg-tools-wrap');
  if(!wrap)return;
  wrap.classList.remove('open');
  wrap.querySelector('[data-action="toggle-tools"]')?.setAttribute('aria-expanded','false');
  const m=wrap.querySelector('.tg-tools-menu');
  if(m)m.hidden=true;
}
function runEditorTool(kind){
  closeToolsMenu();
  const t=getBodyEl();
  if(!t)return;
  t.focus();
  const val=t.value,s=t.selectionStart??0,e=t.selectionEnd??0;
  if(kind==='tool-datetime'){
    const stamp=new Intl.DateTimeFormat('en-US',{year:'numeric',month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date());
    replaceRangePreserveUndo(t,s,e,stamp);
    t.dispatchEvent(new Event('input',{bubbles:true}));
    say('Inserted date & time');
    return;
  }
  if(kind==='tool-dup-line'){
    const ls=val.lastIndexOf('\n',s-1)+1;
    let le=val.indexOf('\n',e);if(le===-1)le=val.length;
    const chunk=val.slice(ls,le);
    replaceRangePreserveUndo(t,le,le,'\n'+chunk);
    t.dispatchEvent(new Event('input',{bubbles:true}));
    say('Line duplicated');
    return;
  }
  const hasSel=e>s;
  const start=hasSel?s:0,end=hasSel?e:val.length;
  const target=val.slice(start,end);
  let out=target;
  if(kind==='tool-sort-asc')out=target.split('\n').sort((a,b)=>a.localeCompare(b)).join('\n');
  else if(kind==='tool-sort-desc')out=target.split('\n').sort((a,b)=>b.localeCompare(a)).join('\n');
  else if(kind==='tool-dedupe-blank')out=target.split('\n').filter(l=>l.trim().length>0).join('\n');
  else if(kind==='tool-trim-lines')out=target.split('\n').map(l=>l.replace(/[ \t]+$/,'')).join('\n');
  else if(kind==='tool-upper')out=target.toUpperCase();
  else if(kind==='tool-lower')out=target.toLowerCase();
  else if(kind==='tool-title')out=target.toLowerCase().replace(/\b([a-z])/g,(_,c)=>c.toUpperCase());
  if(out!==target){
    replaceRangePreserveUndo(t,start,end,out);
    t.dispatchEvent(new Event('input',{bubbles:true}));
    say('Updated text');
  }else{
    say('No changes needed');
  }
}
function autoSizeTitle(el=getTitleEl()){
  if(!el)return;
  el.style.setProperty('height','0px','important');
  const h=Math.max(32,Math.min(200,el.scrollHeight));
  el.style.setProperty('height',h+'px','important');
  el.style.overflowY=el.scrollHeight>200?'auto':'hidden';
}
function computeBodyMetrics(val){
  if(val===_metricsSrc)return {lines:_metricsLines,words:_metricsWords};
  let lines=1,words=0,inWord=false;
  for(let i=0;i<val.length;i++){
    const ch=val.charCodeAt(i);
    if(ch===10)lines++;
    if(ch===32||ch===9||ch===10||ch===13||ch===11||ch===12||ch===160){
      inWord=false;
    }else if(!inWord){
      inWord=true;
      words++;
    }
  }
  _metricsSrc=val;_metricsLines=lines;_metricsWords=words;
  return {lines,words};
}
function replaceRangePreserveUndo(el,start,end,text){
  if(!el)return;
  el.focus();
  el.setSelectionRange(start,end);
  let ok=false;
  try{ok=document.execCommand(text===''?'delete':'insertText',false,text)}catch(_){}
  if(!ok)el.setRangeText(text,start,end,'end');
}
function syncTitlebarDoc(){
  const doc=root.querySelector('.titlebar-doc'),nameEl=root.querySelector('.titlebar-doc-name');
  const n=notes[chosen];
  if(screen==='editor'&&n){
    let label=(n.fileName||n.title||'').trim()||'Untitled note';
    if(splitActive&&splitChosen!==null&&notes[splitChosen]){
      const rLabel=(notes[splitChosen].fileName||notes[splitChosen].title||'').trim()||'Untitled note';
      label=label+'  |  '+rLabel;
    }
    if(nameEl)nameEl.textContent=label;
    if(doc)doc.hidden=false;
    document.title=label+' — TypeGrid';
  }else{
    if(doc)doc.hidden=true;
    document.title='TypeGrid — Fast Autosaving Notes';
  }
}
function syncFindBarUI(){
  const ed=root.querySelector('.editor');
  if(!ed)return;
  const oldBar=ed.querySelector('.find-replace-bar');
  if(oldBar)oldBar.remove();
  const markup=findReplaceMarkup();
  if(markup){
    const sheet=ed.querySelector('.writing-sheet');
    if(sheet)sheet.insertAdjacentHTML('beforebegin',markup);
    else ed.insertAdjacentHTML('beforeend',markup);
  }
}
function syncAttachmentUI(){
  const slot=root.querySelector('.attachment-slot');
  const n=notes[chosen];
  if(slot&&n)slot.innerHTML=attachmentBlock(n);
  const upList=root.querySelector('.upload-files');
  if(upList&&n){
    const files=n.images||[];
    upList.innerHTML=files.map(f=>`<div class="upload-file"><img src="${f.url}" alt=""><span class="file-name">${esc(f.name)}</span><small>✓ Attached</small></div>`).join('');
  }
}
function htmlToPlainText(html){
  if(!html)return '';
  const tmp=document.createElement('div');
  tmp.innerHTML=String(html).replace(/<br\s*\/?>/gi,'\n').replace(/<\/(div|p|li|h[1-6])>/gi,'\n');
  return (tmp.textContent||'').replace(/\r\n/g,'\n').replace(/\n+$/,'');
}
function revealPanel(){}
function hidePanel(panel,done){if(typeof done==='function')done()}
/* Button click animation removed for instant response */
function animateDropdown(wrap,open,after){const shape=wrap.querySelector('.goo-dropdown-shape'),content=wrap.querySelector('.goo-dropdown-content'),trigger=wrap.querySelector('.goo-dropdown-trigger');wrap.querySelectorAll('.goo-dropdown-shape,.goo-dropdown-content').forEach(el=>el.getAnimations().forEach(a=>a.cancel()));const editor=wrap.closest('.editor');const er=editor.getBoundingClientRect(),r=wrap.getBoundingClientRect();wrap.classList.toggle('align-end',r.left+230>er.right-8);const width=content.getBoundingClientRect().width,height=content.getBoundingClientRect().height;const end=wrap.classList.contains('align-end');function clip(t){const x=(end?width-160:0)*(1-t),y=52*t,w=160+(width-160)*t,h=34+(height-52-34)*t,rad=12+8*t;return `inset(${y}px ${width-x-w}px ${height-y-h}px ${x}px round ${rad}px)`}wrap.classList.toggle('is-open',open);trigger.setAttribute('aria-expanded',String(open));content.inert=!open;const target=clip(open?1:0);if(reducedMotion()){shape.style.clipPath=target;content.style.clipPath=target;after?.();return}const steps=open?[0,.7,1.04,.99,1]:[1,.3,-.025,0];const frames=steps.map(t=>({clipPath:clip(t)}));shape.style.clipPath=target;content.style.clipPath=target;shape.animate(frames,{duration:open?360:240,easing:'ease-out'});const anim=content.animate(frames,{duration:open?360:240,easing:'ease-out'});anim.finished.then(()=>after?.()).catch(()=>{})}
root.addEventListener('click',e=>{const trigger=e.target.closest('[data-action="toggle-addon"]');if(trigger){const w=trigger.closest('.goo-dropdown');animateDropdown(w,!w.classList.contains('is-open'));return}const item=e.target.closest('[data-addon-index]');if(item){notes[chosen].tag=categories[+item.dataset.addonIndex];persistNotes();const w=item.closest('.goo-dropdown');animateDropdown(w,false,()=>{render();say('Added to category: '+notes[chosen].tag)})}});
document.addEventListener('pointerdown',e=>{root.querySelectorAll('.goo-dropdown.is-open').forEach(w=>{if(!w.contains(e.target))animateDropdown(w,false)})});
root.addEventListener('keydown',e=>{const w=e.target.closest('.goo-dropdown');if(!w)return;if(e.key==='Escape'){animateDropdown(w,false);w.querySelector('.goo-dropdown-trigger').focus();e.preventDefault()}if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();if(!w.classList.contains('is-open'))animateDropdown(w,true);const items=[...w.querySelectorAll('[role=menuitem]')];const i=items.indexOf(document.activeElement);let next=e.key==='Home'?0:e.key==='End'?items.length-1:e.key==='ArrowDown'?(i+1)%items.length:(i<0?items.length-1:(i-1+items.length)%items.length);items[next]?.focus()}});

function animateMenuOpen(){}
function closeGooMenu(el,done){if(typeof done==='function')done()}
root.addEventListener('pointerdown',e=>{const menu=root.querySelector('.note-actions');if(menu&&!e.target.closest('.note-actions')&&!e.target.closest('[data-note]')&&!e.target.closest('[data-note-options]')){menuIndex=null;menu.remove()}});
root.addEventListener('keydown',e=>{if(e.key==='Escape'){const menu=root.querySelector('.note-actions');if(menu){menuIndex=null;menu.remove()}}});
root.addEventListener('pointerdown',()=>root.dataset.inputMode='pointer');root.addEventListener('keydown',e=>{if(e.key==='Tab')root.dataset.inputMode='keyboard'});const storageKey='typegrid-local-notes-v1';function formatNoteTime(iso){const parts=new Intl.DateTimeFormat('en-US',{month:'short',day:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true}).formatToParts(new Date(iso));const get=t=>parts.find(p=>p.type===t)?.value||'';return `${get('month')} ${get('day')}, ${get('year')}, ${get('hour')}:${get('minute')}:${get('second')} ${get('dayPeriod')}`}function timeLabel(iso){return iso?'Saved: '+formatNoteTime(iso):'Ready for your first keystroke'}function timeIsland(n){return `<div class="time-island"><button class="time-island-trigger" data-action="time-island" aria-expanded="false" aria-label="Show note timestamps"><span class="island-dot" aria-hidden="true"></span><span>Created: ${formatNoteTime(n.createdAt)}</span><span class="island-chevron" aria-hidden="true">⌄</span></button><div class="island-detail"><span class="saved-time" data-tooltip="${n.updatedAt||n.createdAt}">${timeLabel(n.updatedAt)}</span><small>Every keystroke · Local autosave · Device time</small></div></div>`}
function updateFindMatches(jumpToMatch=true){
  findMatches=[];
  currentMatchIdx=-1;
  const t=getBodyEl();
  if(!t||!findQuery){updateFindCountUI();return}
  const val=t.value;
  if(!val){updateFindCountUI();return}
  let flags='g';
  if(!findMatchCase)flags+='i';
  let escaped=findQuery.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  if(findWholeWord)escaped='\\b'+escaped+'\\b';
  try{
    const regex=new RegExp(escaped,flags);
    let m;
    while((m=regex.exec(val))!==null){
      findMatches.push({start:m.index,end:m.index+m[0].length});
      if(m.index===regex.lastIndex)regex.lastIndex++;
      if(findMatches.length>=20000)break;
    }
  }catch(_){}
  if(findMatches.length>0){
    const s=t.selectionStart||0;
    let closest=0;
    for(let i=0;i<findMatches.length;i++){
      if(findMatches[i].start>=s){closest=i;break}
    }
    currentMatchIdx=closest;
    if(jumpToMatch)highlightCurrentMatch(false);
  }
  updateFindCountUI();
}

function highlightCurrentMatch(stealFocus=true){
  if(currentMatchIdx<0||currentMatchIdx>=findMatches.length)return;
  const t=getBodyEl();
  if(!t)return;
  const m=findMatches[currentMatchIdx];
  if(stealFocus)t.focus();
  t.setSelectionRange(m.start,m.end);
  let lineNum=1,pos=-1;
  while((pos=t.value.indexOf('\n',pos+1))!==-1&&pos<m.start)lineNum++;
  t.scrollTop=Math.max(0,(lineNum-3)*24);
}

function findNext(){
  if(!findMatches.length){updateFindMatches(true);return}
  currentMatchIdx=(currentMatchIdx+1)%findMatches.length;
  highlightCurrentMatch(true);
  updateFindCountUI();
}

function findPrev(){
  if(!findMatches.length){updateFindMatches(true);return}
  currentMatchIdx=(currentMatchIdx-1+findMatches.length)%findMatches.length;
  highlightCurrentMatch(true);
  updateFindCountUI();
}

function replaceOne(){
  if(currentMatchIdx<0||currentMatchIdx>=findMatches.length)return;
  const t=getBodyEl();
  if(!t)return;
  const m=findMatches[currentMatchIdx];
  replaceRangePreserveUndo(t,m.start,m.end,replaceQuery);
  t.dispatchEvent(new Event('input',{bubbles:true}));
  updateFindMatches(true);
}

function replaceAllMatches(){
  if(!findQuery)return;
  const t=getBodyEl();
  if(!t)return;
  let flags='g';
  if(!findMatchCase)flags+='i';
  let escaped=findQuery.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  if(findWholeWord)escaped='\\b'+escaped+'\\b';
  try{
    const regex=new RegExp(escaped,flags);
    const nextVal=t.value.replace(regex,replaceQuery);
    if(nextVal!==t.value){
      replaceRangePreserveUndo(t,0,t.value.length,nextVal);
      t.dispatchEvent(new Event('input',{bubbles:true}));
      say('Replaced all matches');
    }
    updateFindMatches(false);
  }catch(_){}
}

function updateFindCountUI(){
  const c=root.querySelector('.find-count');
  if(!c)return;
  if(!findQuery)c.textContent='';
  else if(!findMatches.length)c.textContent='0 of 0';
  else c.textContent=(currentMatchIdx+1)+' of '+findMatches.length;
}

function findReplaceMarkup(){
  if(!findOpen)return '';
  return `<div class="find-replace-bar" role="search" aria-label="Find in note">
    <div class="find-row">
      <div class="find-input-wrap">
        <input class="find-input" placeholder="Find in note…" value="${esc(findQuery)}" aria-label="Find in note">
        <span class="find-count" aria-live="polite">${findQuery?(findMatches.length?(currentMatchIdx+1)+' of '+findMatches.length:'0 of 0'):''}</span>
      </div>
      <button class="find-btn" data-action="find-prev" title="Previous match (Shift+Enter)">▲</button>
      <button class="find-btn" data-action="find-next" title="Next match (Enter)">▼</button>
      <button class="find-btn ${findMatchCase?'active':''}" data-action="toggle-case" title="Match case (Aa)">Aa</button>
      <button class="find-btn ${findWholeWord?'active':''}" data-action="toggle-word" title="Whole word (\\b)">\\b</button>
      <button class="find-btn ${replaceOpen?'active':''}" data-action="toggle-replace" title="Replace mode">Replace</button>
      <button class="find-close" data-action="close-find" aria-label="Close find">×</button>
    </div>
    ${replaceOpen?`<div class="replace-row">
      <input class="replace-input" placeholder="Replace with…" value="${esc(replaceQuery)}" aria-label="Replace with">
      <button class="find-btn" data-action="replace-one">Replace</button>
      <button class="find-btn" data-action="replace-all">Replace all</button>
    </div>`:''}
  </div>`;
}

function showModal(html){
  const layer=root.querySelector('.modal-layer');
  if(!layer)return;
  layer.innerHTML=`<div class="tg-modal" role="dialog" aria-modal="true">${html}</div>`;
  layer.hidden=false;
}

function closeModal(){
  const layer=root.querySelector('.modal-layer');
  if(layer){
    layer.hidden=true;
    layer.innerHTML='';
  }
  getBodyEl()?.focus();
}

function openGoToLine(){
  const t=getBodyEl();
  if(!t)return;
  const val=t.value;
  const totalLines=computeBodyMetrics(val).lines;
  const sel=t.selectionStart||0;
  let cur=1,pos=-1;
  while((pos=val.indexOf('\n',pos+1))!==-1&&pos<sel)cur++;
  showModal(`
    <div class="tg-modal-head">
      <h3>Go to Line</h3>
      <button class="tg-modal-close" data-action="close-modal" aria-label="Close">×</button>
    </div>
    <p style="margin:0 0 10px;font-size:13px;color:var(--tg-muted)">Enter line number (1 – ${totalLines}):</p>
    <div class="goto-box">
      <input class="goto-input" type="number" min="1" max="${totalLines}" value="${cur}" autofocus>
      <button type="button" class="goto-submit" data-action="submit-goto">Go</button>
    </div>
  `);
  setTimeout(()=>{
    const inp=root.querySelector('.goto-input');
    inp?.focus();
    inp?.select();
  },25);
}

function executeGoToLine(valNum){
  closeModal();
  const t=getBodyEl();
  if(!t||isNaN(valNum))return;
  const val=t.value;
  const target=Math.max(1,valNum|0);
  let idx=0,line=1;
  while(line<target){
    const next=val.indexOf('\n',idx);
    if(next===-1)break;
    idx=next+1;
    line++;
  }
  t.focus();
  t.setSelectionRange(idx,idx);
  t.scrollTop=Math.max(0,(line-3)*24);
  updateStatusMetrics();
}

function showShortcutsModal(){
  showModal(`
    <div class="tg-modal-head">
      <h3>Keyboard Shortcuts</h3>
      <button class="tg-modal-close" data-action="close-modal" aria-label="Close">×</button>
    </div>
    <div class="shortcut-grid">
      <div class="shortcut-category">File</div>
      <span>New Note</span><kbd>Ctrl + N</kbd>
      <span>Open Any File</span><kbd>Ctrl + O</kbd>
      <span>Save Note / File</span><kbd>Ctrl + S</kbd>
      <span>Save As / Export File</span><kbd>Ctrl + Shift + S</kbd>
      <span>Print / Export PDF</span><kbd>Ctrl + P</kbd>
      <div class="shortcut-category">Editing &amp; Search</div>
      <span>Find in Note</span><kbd>Ctrl + F</kbd>
      <span>Find &amp; Replace</span><kbd>Ctrl + H</kbd>
      <span>Go to Line</span><kbd>Ctrl + G</kbd>
      <span>Undo</span><kbd>Ctrl + Z</kbd>
      <span>Redo</span><kbd>Ctrl + Y</kbd>
      <span>Duplicate Line</span><kbd>Ctrl + D</kbd>
      <span>Insert Date &amp; Time</span><kbd>F5</kbd>
      <span>Indent / Outdent</span><kbd>Tab / Shift + Tab</kbd>
      <div class="shortcut-category">View &amp; Display</div>
      <span>Minimal Mode (Hide Nav)</span><kbd>Ctrl + B</kbd>
      <span>Pin App Always on Top</span><kbd>Alt + P</kbd>
      <span>Split Side-by-Side</span><kbd>Ctrl + \\</kbd>
      <span>Toggle Word Wrap</span><kbd>Ctrl + W</kbd>
      <span>Toggle Theme (Light / Dark)</span><kbd>Ctrl + T</kbd>
      <span>Zoom In / Out / Reset</span><kbd>Ctrl + + / - / 0</kbd>
      <div class="shortcut-category">Navigation</div>
      <span>Next Match (in Find)</span><kbd>Enter / ▼</kbd>
      <span>Previous Match</span><kbd>Shift + Enter / ▲</kbd>
      <span>Close Dialog / Search</span><kbd>Escape</kbd>
    </div>
  `);
}

function toggleWordWrap(){
  isWordWrap=!isWordWrap;
  root.querySelectorAll('textarea.note-body').forEach(t=>{
    t.classList.toggle('word-wrap',isWordWrap);
    t.classList.toggle('no-wrap',!isWordWrap);
  });
  root.querySelectorAll('[data-action="toggle-wrap"]').forEach(btn=>btn.classList.toggle('active',isWordWrap));
  const wrapSel=root.querySelector('[data-setting="wrap"]');
  if(wrapSel)wrapSel.value=isWordWrap?'on':'off';
  say(isWordWrap?'Word wrap ON':'Word wrap OFF');
  scheduleSave();
}

function toggleFocusMode(){
  isFocusMode=!isFocusMode;
  root.classList.toggle('focus-mode',isFocusMode);
  root.querySelectorAll('[data-action="toggle-focus"]').forEach(btn=>btn.classList.toggle('active',isFocusMode));
  const focusSel=root.querySelector('[data-setting="focus"]');
  if(focusSel)focusSel.value=isFocusMode?'on':'off';
  say(isFocusMode?'Minimal Editor Mode: Nav bar hidden in editor (Ctrl+B)':'Standard Navigation visible');
  scheduleSave();
}

function toggleTheme(){
  const cur=root.style.colorScheme==='dark'?'dark':'light';
  const next=cur==='dark'?'light':'dark';
  root.style.colorScheme=next;
  const sel=root.querySelector('[data-setting="theme"]');
  if(sel)sel.value=next;
  if(window.TypeGridNative?.setTheme)window.TypeGridNative.setTheme(next);
  say('Switched to '+next+' theme');
  flushSave();
}

async function triggerOpenFile(){
  if(window.TypeGridNative && typeof window.TypeGridNative.openFileDialog === 'function'){
    try{
      const fileData = await window.TypeGridNative.openFileDialog();
      if(fileData){
        await loadFileIntoNote(fileData);
        return;
      }
      return;
    }catch(err){
      console.warn('Native open file failed, falling back:', err);
    }
  }
  const inp=document.getElementById('tg-file-importer');
  if(inp){inp.value='';inp.click()}
}

async function loadFileIntoNote(file){
  if(!file)return;
  try{
    if(typeof file==='object'&&file.error){
      say(file.error);
      return;
    }
    let text = '';
    let rawName = 'Untitled';
    let ext = '';
    let filePath = '';
    let eol = 'CRLF';
    let encoding = 'UTF-8';
    if(typeof file === 'object' && typeof file.content === 'string'){
      text = file.content;
      rawName = file.name || 'Untitled';
      ext = file.ext || '';
      filePath = file.path || '';
      eol = file.eol || (text.includes('\r\n') ? 'CRLF' : 'LF');
      encoding = file.encoding || 'UTF-8';
    }else if(typeof file === 'object' && typeof file.text === 'function'){
      if(file.path && window.TypeGridNative?.readFile){
        const res = await window.TypeGridNative.readFile(file.path);
        if(res)return await loadFileIntoNote(res);
      }
      if(file.size > 32 * 1024 * 1024){say('File is too large (> 32 MB).');return}
      const buf = new Uint8Array(await file.slice(0, 8192).arrayBuffer());
      for(let i=0;i<buf.length;i++){
        if(buf[i]===0){say('"'+ (file.name||'File') +'" appears to be a binary file and cannot be edited as plain text.');return}
      }
      text = await file.text();
      rawName = file.name || 'Untitled';
      filePath = file.path || '';
      const dotIdx = rawName.lastIndexOf('.');
      if(dotIdx > 0) ext = rawName.slice(dotIdx);
      eol = text.includes('\r\n') ? 'CRLF' : 'LF';
    }else if(typeof file === 'string'){
      text = file;
      rawName = 'Imported Note';
      eol = text.includes('\r\n') ? 'CRLF' : 'LF';
    }else{
      return;
    }

    const bodyText = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    let name = rawName;
    if(!ext && rawName.lastIndexOf('.') > 0){
      ext = rawName.slice(rawName.lastIndexOf('.'));
    }
    if(!name) name = 'Untitled';

    let tag = 'File';
    const lowExt = (ext || '').toLowerCase();
    const codeExts = ['.html','.htm','.css','.scss','.less','.js','.jsx','.ts','.tsx','.mjs','.cjs','.py','.pyw','.java','.c','.cpp','.cc','.cxx','.h','.hpp','.cs','.go','.rs','.php','.rb','.sh','.bash','.zsh','.bat','.cmd','.ps1','.sql','.lua','.pl','.r','.swift','.kt','.dart','.vue','.svelte'];
    const dataExts = ['.json','.json5','.jsonl','.xml','.svg','.csv','.tsv','.yaml','.yml','.toml'];
    const cfgExts = ['.ini','.cfg','.conf','.env','.properties','.reg','.inf','.gitignore','.gitattributes','.editorconfig','.dockerignore'];
    if(codeExts.includes(lowExt)) tag = 'Code';
    else if(dataExts.includes(lowExt)) tag = 'Data';
    else if(cfgExts.includes(lowExt)) tag = 'Config';
    else if(['.md','.markdown'].includes(lowExt)) tag = 'Markdown';
    else if(['.txt','.text','.log','.rtf','.nfo'].includes(lowExt)) tag = 'Text';
    else if(lowExt) tag = lowExt.slice(1).toUpperCase();

    setupComplete = true;
    const existingIdx = filePath ? notes.findIndex(item => item.filePath && item.filePath.toLowerCase() === filePath.toLowerCase()) : -1;
    if(existingIdx !== -1){
      notes[existingIdx].title = name;
      notes[existingIdx].fileName = rawName;
      notes[existingIdx].fileExt = ext;
      notes[existingIdx].eol = eol;
      notes[existingIdx].encoding = encoding;
      notes[existingIdx].body = bodyText;
      notes[existingIdx].tag = tag;
      notes[existingIdx].updatedAt = new Date().toISOString();
      chosen = existingIdx;
    }else{
      notes.unshift({
        title: name,
        fileName: rawName,
        filePath: filePath,
        fileExt: ext,
        eol: eol,
        encoding: encoding,
        body: bodyText,
        tag: tag,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      onNoteInsertedAtZero();
    }
    ensureTabOpen(chosen);
    screen = 'editor';
    render();
    flushSave();
    say('Opened "' + rawName + '"');
  }catch(err){
    console.error('Failed to load file into note:', err);
    say('Could not open file: ' + err.message);
  }
}

function updateStatusMetrics(){
  const t=getBodyEl();
  if(!t)return;
  const val=t.value;
  const sel=t.selectionStart||0;
  let ln=1,lastNl=-1,idx=-1;
  while((idx=val.indexOf('\n',idx+1))!==-1&&idx<sel){
    ln++;
    lastNl=idx;
  }
  const col=sel-lastNl;
  const m=computeBodyMetrics(val);
  const chars=val.length;

  const lnColEl=root.querySelector('.status-lncol');
  if(lnColEl)lnColEl.textContent='Ln '+ln+', Col '+col;
  const linesEl=root.querySelector('.status-lines');
  if(linesEl)linesEl.textContent=m.lines+' line'+(m.lines===1?'':'s');
  const charsEl=root.querySelector('.status-chars');
  if(charsEl)charsEl.textContent=chars.toLocaleString()+' chars';
  const wordsEl=root.querySelector('.status-words');
  if(wordsEl)wordsEl.textContent=m.words.toLocaleString()+' words';
  const selLen=Math.max(0,(t.selectionEnd||0)-(t.selectionStart||0));
  const selEl=root.querySelector('.status-selection');
  if(selEl){
    if(selLen>0){selEl.textContent=selLen.toLocaleString()+' selected';selEl.hidden=false}
    else selEl.hidden=true;
  }
}

function scheduleSave(delay=250){
  const savedLabel=root.querySelector('.saved');
  if(savedLabel){
    savedLabel.textContent='Saving…';
    savedLabel.dataset.state='saving';
  }
  const statusSaved=root.querySelector('.status-saved');
  if(statusSaved){
    statusSaved.textContent='Saving…';
    statusSaved.className='status-item status-saving';
  }
  if(saveDebounceTimer)clearTimeout(saveDebounceTimer);
  saveDebounceTimer=setTimeout(()=>{
    flushSave();
  },delay);
}

function flushSave(){
  if(saveDebounceTimer){
    clearTimeout(saveDebounceTimer);
    saveDebounceTimer=null;
  }
  const n=notes[getPaneIndex()];
  if(n){
    n.updatedAt=new Date().toISOString();
  }
  const stored=persistNotes();
  const savedLabel=root.querySelector('.saved');
  if(savedLabel){
    savedLabel.textContent=stored?'✓ Saved locally':'Local saving unavailable';
    savedLabel.dataset.state=stored?'saved':'error';
  }
  const statusSaved=root.querySelector('.status-saved');
  if(statusSaved){
    statusSaved.textContent=stored?'✓ Saved locally':'Storage error';
    statusSaved.className='status-item status-saved';
  }
  const stamp=root.querySelector('.saved-time');
  const islNote=notes[chosen];
  if(stamp&&islNote){
    stamp.textContent=stored?timeLabel(islNote.updatedAt):'Storage unavailable';
    stamp.setAttribute('data-tooltip',islNote.updatedAt);
  }
  return stored;
}

function persistNotes(){try{const data={activeProfile,profiles,workspaces,setupComplete,preferences:{editorFont,customFont,editorZoom,theme:root.style.colorScheme,editorSize,wordWrap:isWordWrap,focusMode:isFocusMode,noteSort,editorTabSize,openTabs,splitActive,splitChosen,alwaysOnTop:isAlwaysOnTop},selectedNote:chosen};const json=JSON.stringify(data);
if(window.TypeGridNative){
  if(typeof window.TypeGridNative.saveAsync==='function'){
    window.TypeGridNative.saveAsync(json).catch(()=>{});
    return true;
  }
  return !!window.TypeGridNative.save(json);
}
localStorage.setItem(storageKey,json);
return true;
}catch(e){return false}}
async function migrateLegacyAttachments(){
  if(!window.TypeGridNative?.migrateAttachments)return;
  const targets=[];
  for(const id of ['personal','work']){
    const w=workspaces[id];
    if(w){
      for(const n of [...(w.notes||[]),...(w.trash||[])]){
        if(Array.isArray(n.images)){
          for(const img of n.images){
            if(img?.url?.startsWith('data:image/'))targets.push({obj:img,key:'url'});
          }
        }
      }
    }
    if(profiles[id]?.photo?.startsWith('data:image/'))targets.push({obj:profiles[id],key:'photo'});
  }
  if(!targets.length)return;
  try{
    const urls=targets.map(t=>t.obj[t.key]);
    const migrated=await window.TypeGridNative.migrateAttachments(urls);
    let changed=false;
    for(let i=0;i<targets.length;i++){
      if(migrated[i]&&migrated[i]!==targets[i].obj[targets[i].key]){
        targets[i].obj[targets[i].key]=migrated[i];
        changed=true;
      }
    }
    if(changed){
      persistNotes();
      if(screen==='editor')syncAttachmentUI();
    }
  }catch(_){}
}
function restoreNotes(){try{const data=JSON.parse(window.TypeGridNative?window.TypeGridNative.load():localStorage.getItem(storageKey));if(!data?.workspaces?.personal||!data.workspaces.work)return;setupComplete=data.setupComplete===true;editorSize=data.preferences?.editorSize||15;root.style.colorScheme=data.preferences?.theme==='dark'?'dark':'light';if(window.TypeGridNative?.setTheme)window.TypeGridNative.setTheme(root.style.colorScheme);customFont=data.preferences?.customFont?.data?.startsWith('data:')?data.preferences.customFont:null;editorFont=data.preferences?.editorFont||'default';if(editorFont==='custom'&&!customFont)editorFont='default';editorZoom=Math.max(50,Math.min(200,data.preferences?.editorZoom||100));
if(typeof data.preferences?.wordWrap==='boolean')isWordWrap=data.preferences.wordWrap;
if(typeof data.preferences?.focusMode==='boolean')isFocusMode=data.preferences.focusMode;
if(['pinned','updated','created','title'].includes(data.preferences?.noteSort))noteSort=data.preferences.noteSort;
if(data.preferences?.editorTabSize===2||data.preferences?.editorTabSize===4)editorTabSize=data.preferences.editorTabSize;
if(Array.isArray(data.preferences?.openTabs))openTabs=data.preferences.openTabs;
if(typeof data.preferences?.splitActive==='boolean')splitActive=data.preferences.splitActive;
if(typeof data.preferences?.splitChosen==='number')splitChosen=data.preferences.splitChosen;
if(typeof data.preferences?.alwaysOnTop==='boolean')isAlwaysOnTop=data.preferences.alwaysOnTop;
root.classList.toggle('focus-mode',isFocusMode);
root.querySelector('[data-action="toggle-focus"]')?.classList.toggle('active',isFocusMode);
chosen=Math.max(0,data.selectedNote||0);for(const id of ['personal','work']){const w=data.workspaces[id];if(!Array.isArray(w.notes)||!Array.isArray(w.categories)||!Array.isArray(w.trash))return}for(const id of ['personal','work']){workspaces[id]=data.workspaces[id];for(const n of [...workspaces[id].notes,...workspaces[id].trash]){if(n.images)n.images=n.images.filter(f=>f.url);if((!n.body||!n.body.trim())&&n.richHTML)n.body=htmlToPlainText(n.richHTML)}if(data.profiles?.[id])profiles[id]={name:data.profiles[id].name||'Admin',preset:avatarPresets.some(a=>a.id===data.profiles[id].preset)?data.profiles[id].preset:'',photo:data.profiles[id].photo?.startsWith('data:')||data.profiles[id].photo?.startsWith('typegrid-media:')?data.profiles[id].photo:''}}activeProfile=data.activeProfile==='work'?'work':'personal';notes=workspaces[activeProfile].notes;categories=workspaces[activeProfile].categories;trash=workspaces[activeProfile].trash;ensureTabOpen(chosen);if(splitChosen!==null&&(splitChosen<0||splitChosen>=notes.length)){splitActive=false;splitChosen=null}}catch(e){}}
const avatarPresets=[{id:'boy-1',name:'Boy · Ocean',group:'Boys'},{id:'boy-2',name:'Boy · Sunset',group:'Boys'},{id:'boy-3',name:'Boy · Forest',group:'Boys'},{id:'boy-4',name:'Boy · Midnight',group:'Boys'},{id:'girl-1',name:'Girl · Lavender',group:'Girls'},{id:'girl-2',name:'Girl · Coral',group:'Girls'},{id:'girl-3',name:'Girl · Mint',group:'Girls'},{id:'girl-4',name:'Girl · Sky',group:'Girls'}];const suppliedAvatarImages={"boy-1": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCACMAIwDASIAAhEBAxEB/8QAHQAAAQUBAQEBAAAAAAAAAAAABgMEBQcIAgEJAP/EAEAQAAIBAgQDBgMGBAQFBQAAAAECAwQRAAUSIQYxQQcTIlFhcRQygQgjQpGhsVLB0fAVJDNiFkNy4fEXU4KSov/EABkBAAMBAQEAAAAAAAAAAAAAAAECAwAEBf/EACARAAICAwEAAwEBAAAAAAAAAAABAhEDEiExEyJBUSP/2gAMAwEAAhEDEQA/AM/63R2QSDc8mN1PsemG8zOrtfUjHmHNh+eO+8RZzHewPynnb0P9cLQ00ldMlPCjPKw8OgXFvUdMExEmaaF2CObtzic/MP2OJDhOKCszkl1dGiQyCAk6S1wARfcEYc1/CdekJIiUne6Rtcfkf5YhMszSbIMwhqZV1Rr4WJ3Ok87Hr7YKdgaPoH2J9osPEOVw5RXd3HmlOtlYAKKhQOdv4h18+fni37YwHkHEpoJ6XMsvqJLahIrxKBYjkQfP/uDjVfDXbhw/mmRQVFXM6ZmBpmpYoizah+ID+E8xc/tjjy4mncTpxZU1Ui0sfsVZWdsqbiiyhyOj1MoX/wDK3/fEJN2wZu0uhUo4SwuAIi36lsIscv4O80F+l3Y/Yote1XPWcq1RGrdAIE39r47Ha1nMIZpJIWVNyWpx/IjB+KQPngXjj9in6PtnmAVqnL4JUIvqidkNvrcYJKDtb4fqWVKpp6Fj1mTUn/2W/wCtsK4SX4MssX+h3bFCfaLzXhlsnfKKjLoK/OJx4b8qdT+JiN7+Q+vLB3x52o5Xw1w/8XQ1tNVVdTdaYROHF+rG3QeXU2GMiZ7nz5jVz1lTPK7OS7SSAXJ6kk4pixtu2TzZElqih87o/wDC8ymoldnMViul9D6eYI89v2xFTZy8uqN3NQLb6j3Uo+vJvrh9xDmYzjOKqsjcSrIwVUe6sirsCPQ88RVRd4+7mj73SNtZs6j/AGsOYx2HMhq7mS5SWVwviK7iRPO6/wA8dQV00cYWOocJ00MbH97Y6oI9M6MI4alQdjJdWH7b+oIOJB6WGNilo007FZ2AYfna/vjBDWly6fNsygoaFDNWVDhYgvO58/bGxuzjsKouHciV62EVGYzDVLKw3v6YA/s2cCQzNLxbXwqXe8dMCtvCDu31ONRTZvHEg0DkOuOXNkbdIpCK9Zn7jnsziiR5olAG9nA3U4zxxVwvKjVRiVFrotmivdZwPTlcjG0+Ia2Oqj7k2Nzc+2KP4u4f+Np1mgi1zRnkALlef6YEJtDONozJw/xIeH6qSBqeQ0srAGEEkxNffSPryxakdPLUMiwoSz/KOuEYuHYRmTVPwiGtkNlOjfflYefri2OEuFBRFXnVTUSlde19I52xaWRLwmsdkLkfBuc1ahnkmQEbLGzN+pNsSseRyQZ4uRVDSipmp++iMr2JcMCFv0BCt+eNMcMUtIuXRBIkDAWJtireK6jKso7Tcwz2tAeoooIoKaM2CqQtyx8z4tsRWVydDPGoqySynsfq5KVDX5qlOCLiKGLvGX3YkfpiG437OKnh7Jqqu/xKOqpIkJfXH3bgfS4P6Y5l7Zllka1RELf7sOKftRps3pp6GuRJ6WZdDqDfY9Mb/T022N8orbLskr8xyyOto5phExOyG4U3sRb++eIXNE4iy4kd45jXqp5fQjGgOyaky+gqs3yelBalUd8iybkeNgR+RXBDxnw7lUtBI706LJ0KjG+Zp0ZYk42Y3nqXqnM0s6szbEEkkYrXi/i6Co/yNC5aI/6kmmyuf4R1t64vzi3hFIS1XTIgaMkOoX5t+f8AXFR/8GUUWax1fd61DaxG1rKfI+Y364vHImI8bQP5JwPLmmiprlLI9mjiPhcjyY/2cXJw52aS1kCwinREYf6US7D3xMcF8M94ErJEvK3+kCL2H8X74v8A4PymnpUjGlV1m17YjPIyijRjXtT7EqvhekOa0tM60y7yNEu6X62HMemKnp/jhBH3TTzR22eJBIp9vL26Y+pmd8O0ea5XUUksQdJEKkNuDj53dp3Y/m/DfGNdS5VRGbL5LTRG9tIa+30th8WXbjFnGjYHDOYUmRZJSUVJLGsUEYUL5WG+O63itGSQLKZGG2ldsVdDxJSSRs4ZzIlrqFN2uf3wtLn8PwzTLFMZASFGmxNvP3xGiqiGU2bSVajT4QBuo6/XDcNGU1HkBgIn4v7p30QWTRzPPV/TDfMuM2VV+EF1MZ1Er1vYH6fzwBq4GdBBTtFHLpUuBcMQLi/OxxOUUkcUqlrD/wAYpqj4qr4JInDsURdOg20287YsTK88p80RTC1pChYoTuBe374LMkW5kedmCNVLAG24PI4pbtRnyvP+Jc3omzBKfOEqBJGkxIikUxJZL+e1/rgup8yeDSG8QAsBjNnbzPmNBxjJX06SCjqEjZ2FiCwUD9NP674OJfYTKvqSskUuWzPBUxNFKg+U+XmD1HriaoswybhRo8yz+cF9mhy+NvHJ6v8Awr6YpenrM44kjPw0ssjwx95pDkKQL8iORwN19XItY8U3ezb2kWV7sp8wx6e+OrW+HPRuPsk4yizbiGTNoQkcVYKiMxK19BurWv12GLD4hzo1ZZdQ0jnY7AYyL9nOZxmFfODI9PSqfESbO7gDkfQHF/1WZPM2keFSMcmRJSOnGm4idbGk8kp2szEW9DgdXhXLqJ0KwoA0q37w6id9h+eJerr4qSIyzuES/Xzte2BDOOOoQDHTwNIUcFXuLNbf9r4yGkiwcsSClnFyBbYemCajzn4cIFsyg9D54rbLM+pszZlgc6hfY+lr/viRjq1ZCySrbc3DcwDhTNcLYi4hjdQC9h64ha2pyqoqZGqo43e/hJHTn+5OAdc3mjVSspKnrzw2qcwqZnVu8HK3IC+CkI0yphUTSbs0tz0DBR+mPGeyN92p2/FIcMopFYAiMcvxSX649klNmH3QvfkCbHD0OhWoUlCoWG58gxJwzCNGJA+nUdgSemOJZL3DWYH1044MkbOVAkeMrsFN9/rjV0IUcH8IT8W1dVQ0s6x1UcIliWTdHANiCRuDy8xg2yfs34pyGrZnyqQmQCIGJlZSb6ud/IHngD4I/wARl4syeHK1kiq55RFquD4Duxt6KCfpjTfFXaHwzwy9JkWcZkYsxkRXjSNGdlPIaiORJ88JO06Rk+A7QcAZ/mThX+EpIwAWfve9YX8gu1/rgN+0Vk+WZbwflT0tJrGUzszqTpkkVlsSepubE3wW5p21LwVktBKcnkrZ6uQprD2XSOR2BN7EDlzOJrtBiyfjzglzVLNRVc1KaqFJlG507oT1v/Q4SLakmzSdxaMY5bxNw/RQtLGsNCba2VgQHFiNiNm5++Aniiqo87zf46ijcRSINbMR4yPxC3I2tzxxxXk83Dma1FHUA92rakA5hTyNuuGWR0Xx9YYIBdpdj3fykdT6Y9BV6chobsDyeqXh3MJKSkkmuySyCOxfSb2OnmeXT8sH2a53BRLOUOqVVI0WIs3S4PLc477O407NfgavMJUgpKyjLVJJAEABul77bAAfU4ge0PtHyvjeUQ0FDBGgYBcxqB3Qt6fiYfkPfHLKO0rRaGXWPQfzjOZ80kYORGNK3TULXHXn64gpkIsGUHe1tV8EVCOFlGmuqqiskYDxUCgKv1LYiuIqGkomWXL6sVNI5G0p0yxHyYciPUfW2Dq0H5FIRoK58sqxNFsbWaxwlFmdXTd4oeQCaPu23vqX64j2diS4aPbYkG5wj3iSBkLkm3hPnhaKkuubVcRQrJIqoAtr3Fg2ofrvhu2YVDO7F3Ysxb5iOZviOWUFG1M1l2a/l544EgUsGZjYmx53wQC2T5hoo6ZWUeGFyWK73VvX0xJx1oqJZoI3JdQpstvxC45DARBMIaxXVmK7gMB0IsQRhD4iop2kZGKvImlmU3DW5H3BGKOIiYZNM1RTwOzEPKdO55sOY9MNmopqrUO87pUAdlBsbrvsfPlgGfMaqNg0sneBJhOkl/lN/ELjoRtY4PYJ3mgimQMwbdT0+uA4m2rolwPxbU5ZV0eYiCpaWlnkg1RgXswIBBvawB/TF5wZZknFOa0jZ5QQtNTpb41yUIXncj8TcrYh+xPsxy+pylsxzhO+IkZ6akB0rYuSJHtuT5DyxM9stNnHANJLmcEZqsrmkDNKi3ZBe9j6b/W2Jzpul6BeWGGU8aZfmTVNFmtClGlB93Q1MVMSmn+JtR5kW8uu+JPIoKrPZpKSaWKajCnvG0+NfUA8r4yFRdpPEGcV5NFQ1Bp4kZ5Znu6qt+SqL/la+LK4H7Ts74aUPX6ULSFI6eeT7xB5tp+U8vDgPC14b5E30hO2HgCeTNGyr4bTVxt922k2cA816kaTy6Ygezjs5rzXVFHRR3zF5ULSlbLDGovqY/8AUdhzNsaF7RM1hzfh7I84rqJlWdiy6yY5gqi5KkbqTe1/64admvFOU0VFUKaSWJmm7wd2veswKjd3JuWuDv5csVjOWpKUUpUOIfs9UOerG2fZ/m1bMBdSsgiRG/iCjmfe5wNZ19n/AD3g0SVnDy5RnlPue5rqdYqlfaQCxPuMWjmnHqtSGHLY6mKViPv3smgX3sN7nHWT9oS5gJaCtdBXRJrUIbCVb87dCOo+o9Eufofr4Zuj7WJ8mr2yzOcrFDVqdJgkAgf6MfA35rhnxJnVbnTAySf5VbtFHIuhwDyv0Jt1HPHnbKr8acXUuRZdTrLVae8aTSCFW/U4DOIezjivg2iR3jl/wvn3+nvIowRYhxvZfzA8xi6onQ6oq1aynDoreIlCrrYqQdwRhSNWJIRBrU3BA3GAygq6/KKhKWthlhgmAMbi8kTtbwlH8rb2v0x1WcStTZesxvHVzF3XvASpF9K7jpa5xNwpnTGVoOhHL3bu5urczYW3x5S95MZxpUd3KyfOvTAZRcTvmYaMEq1qODS5uGcvdirdbgH12GICq4onknkdIro0kjLrAvYuxH74GoWwnM6rUshHhfYgbWPpf9sKd4rHS12HK4NmXDKqlSN2XSRb8LbW9j/dsd0VPPXOY4F1sOvK3o3l+xxUieVsAkVnC96v8aCzD/qGCngmrpZIYsuZdcrOfvATYA7XsPK/LELItNQSRoXFTVKfHJ8kUd+QJ21YcZfX02WpPUSTCKpBBZ0RRqtyv+f6Y1WaTLyTOc24VmoFoD8Zl5ZEaWIENGAebr+HYc+WNLV+TU+ccKVuXVksE1PmETqjSWZfEPDY+m1sfP2Xj1fhquaSKqKw6C8OsEyattXkQD+4xPU32mOLKDJBk9H3KLHGUhkqbsyoeh6Eb7X5YlkxSlTQcc1G7H2R8SQcLZjWZfeBqxGMU0euxDKSDYjnvv8A+cMRJHRZ0a2eZphrVoqU6Qhdjfcc235DFNIamerM0fevVa+8cEEnVe99vXFl5ZNnNRVII6Bp84DGKBk38BOrWegUA2vzPLzxaSpEzXnElF/xD2eTnNKhWzU0rSQU4NzDtcb+wPvjN+U58sLqtPVItTYXjQnXc9Ldcah7Ecvpazg+atqtVVm0jNDU9/4tBG1gPUHGcJ84yns/4qqDV5dDHWxzSJBUzhlcrqPyk+H2tiGHjcSuVcTJmqzXiARxRzwVkXfEIn+WKmQnkAbczhSbIKvhruM2zCtghlgu7wpdnKkEFS2wuQfXCdb200fw/eRvcnl94Df8sVDxTx/WcS1BVpnihX5fDYfUevniyTZELOzHPI8w7Tq7MKkqI6ldMJJBFgf7ONo5HPQz0xSWNGRlsQwBH5Y+b1LmMuV5pT5hShYZ4zuseySjrboD+hxpLgntpo5aQK9RolQWZDe49x0wuSF+DRdMS+0J2R5bSZJXZ3wsgoe6bvqigQfdFb3aSNfwkXJIGxF+RxkybvY0Md1MbeAD5o28hv8AKcbF4m7Q6PMad4O/ST4pDGEBDEgixuD0scZT4hyabIq+RUR/hXJEetT4h1HrgxuqYyfSFy15qKoXuJZKc3/05BcDmNvTc7G4xIilew7uKRU6dxGXQ+oIuB7YZ98rxmJl1RbnumPI+anp7cvbHcaRMgMdRBa3/NmMbX9R1PrgjNhahhqbtVyiOOI2sN5G9AP5nlherzBkhSOCNaeg/AsW8k3qT/M7e/LCUUU1dVJFBEaiaRwI1ABIY+nX67eeCWCWg4PRqiGRMxz5zcVOrXDSnl92Tszj/wBw+EfhBO+MxExBsqgyKmSrzunWWqID0+UFT4Nrh5hzHQ6OZ5tpGxDc3qarMa2bMJJlmqKhtTBgAGPKwIsOnLa3TDisqaitqXqaiR2nuWLEk2udz5+539cdw5ZW5vC7R0skg5GZALH36N788Fc9N6CkU8sE7xr4XkBUQzbK1+m+30xO8J5NXcQV6wUGTmaohYgrMhMd+uq+wO/THMuS5jNWR5a0Kd4xGoyi6hepv5e9/Q4tHsh4vk7OeITkuZJRSLVASwzyA6Cdxov52A/LAlKlwyQW8N9jWfVLww1rUtNEwF4qeHkPcjF/cOdnuVcN5S8Swhm0WaTfUbDz88F2QJT57lkNc1QI4pAe6EFl125nxdL4iJs+StzGbK6STVUQBvwhi/TkDvz3sccUpuXpdRSVjDsaqaYpxLQQPpkhqlYI58ekrYEj6YDO3F8p4czdKPNoo56DM0apUPpIRr2YFW2IJ3HvgL4pp+NOzDiubOqSCWjpKldT1CIGiO1ypVbjnyvbALxf2zLxgpbNcqgzepCBEM1ISsQ52UMNt8Wxwe2y8ElJa6v0Fc5yTIQtTNR1WmkUahocC/pp336bYAYCkuoshKjoTuo98d1ciVVY0kdOtHb5YlAAXClKxjk5b+Yx1kRpVQyIrCM98jDdPxe/r9MN8heRsxhhWrFNKLkSSLd0AH4fP+WJariWZCynSRvcDkfUfzGIapqJYKiCYojiJtQJGo36Eee/sffGMXtwNBlWX1UcQiNTWyMO+mqWLFdrgH15bX2vv5Ysvjvg6LP+Hw70cMUaWdY5IwSzAGxt+H98U/2M1VMk8BqBqnl1jvJCf9QkG638/wA740jW1gn4dZ3Uvp8LEH5fXEpcZkzC/EOVDLqySNG1Rk3B6rcXA/vfA+zShjolW3+42IxYnaVNBQ5pViJu8gkA0SRc7hzY+osbW9MVxUNH3n3tPIWts0R8LDzw9BTLDno7q0tM1131JfceY/7YRinDOdJAkIswPIj2/lhWUSQy6o7gDkRv4fL1HpzGEJhHWm4sk/keTe2CAe0FLT1dZFHLqUEgqFew9QD02/bBpBHFGuqOJVCjZC2q30GAnIK74bNI45pDErAoSdumwPpfGh+yfgX4yWPPK9QaNG10kTDaRh/zCPIHl5nfoMRm69HQR8G9i+XVWSR1ef08iZlU+MCJyjU8Z5L5XPM3HkOmKe+0V2eU3A03DtbQV1RLBVtLAyzgX1LpZQCLb7mx9MaySUraxIt64pP7U9B/iPZka51L/wCG1kUxtzCNdGI8vmGI45PdWM6oz0narxjQ5RBlsGcziihbUCt9Y57EjpuRcb4cf+oOYSZfSZhT5hPTZtl51QiB9LEfi35FSOp+uK7o63uygZg8b/K/n6HyOHU9OrKTCRdiboTs3nb1/v1x16L+E7Zr7s0+1VQVlHPR8aurR6AscvcXLG26uouDfzGKH7V+Jcpz/jXMBwb8S+UuwMZBaykgagqnkt72PlytiusprVoqiB5qN5qaFmLoiXcgjkT1AO/mMFuacWR1NJDT0uSw0KbyrJpAkIIIBNtyN73xJQ1lcUPtsusRj4ampoY6nNXjhQqzBS9mYDnY9T7YgVjcyeG6vzAJ5j3wlV1FVV1YnqppZKggeKQnxADa305YUp6nUbM1iNtx/dsVSfrEbX4fnm1XRwySg2v0wmeG6upyisrpHEcUY1Rh9hLY2J8rDcX9DiVo8vlzzMKTLaaMPXVcixQj+IsbAj0HP2GNL9qfZ7luS9j08VMjB8hoWCyRrqaVfx39ydV+hws56tIyVmaOA80koav4ZZCrJ94scm+hgb6lPUH+WNU5HxBDmeSieOVRHIv3i3+RxzBxivI6qZMxpShOuSUCOVRsGO2/p5jFmZx2gw0dO+V5U8IWRWjNRGpBKX3JPUk35cr4aSsUHe0PMIq3imtlohG0CMUZY7kE3O4Hl7YDR8AfF3lXCW30RDwjEpU09xqjZnHzW1eIeoPX++WIioJMhNwfVQRf3seeCENYKogNG93VeYJ3X1wjOtgSpJjve45r/TDaWV4pRIjWYHY+W2O6eZmlvYD7syWA2Hp7emCY/GobUnegSBWFmPT3xo3s87c6PTTZVnLJBIFCxSiwRgNtjy+mM510awzAILK1OJreRvy9sQVVUyOs0ZPgSzWHU+uElBSXQp0fR+hzKnr4llgmSRCL3U4ge0TJzxFwTn+Vj56mjkVD/vAuv6gYxhwb2kcR8N1tFDR17GnlcKYpbsoHp1H5411k+f1uZ5dG1QylmUE2W18c0oODHTswOJGRdUiDujs9hsD6jphzHOYAGFpIG5k729/5EYL+KuHaXL85rTTvMgFbMgFwQFDmw5YDaynWhqaQwEqtSCXT8N7X2HTHWnZM7Mswm7yllYMd9BexPs2PaadpJ+8idhMhGqN73B6fXHtPEr1cIYXR9LaTyB9MSM8ccc6v3SMyggFhfbywTHE87V8wd3Yz8tYtz9RjunEjS6ZUswG8i8iPPBbwXSU1TPXxz00EoXTYyRhjyPU4ZZ7lNPRRVE0GtCtcadVvsF2/Xfnhb7Ri3vs68IBsyqOJa5F0wBqeivyLHZ5B9PCP/li3u07iPKqHg7PaetqUXv6KaIKTzLIQP1IxXfFmbz8CcJRxZKscUdNCI0VluLAfv1xmXO+Kc2z6tWfMax6gyAnQ/wAi+w6YhpvLZj3SIhYGjVXhkZGtZrX8W2/v7Y5DhVCygCJj4WHy39D0OHjnTOi80kUEqdxhKcdxMVHiVmKsrbhh646RDqGpalYLJ4oybhwbfr0P6YXkg79tafCuPOVtDfUf0wxkjFJWPTpcwGLvNDbgG9re2+OJF7iRo1JKqdtW9sYx/9k=", "boy-2": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCACMAIwDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAABQYDBwIECAEA/8QAPRAAAgECBAMGAwYFAwQDAAAAAQIDBBEABRIhBjFBEyJRYXGBBzKRFEKhscHRFSMzUvAkYuEWcoKSQ3PC/8QAGgEAAwADAQAAAAAAAAAAAAAAAgMEAAEFBv/EACoRAAICAQQBAwQCAwEAAAAAAAECAAMRBBIhMUETImEFMlGhwdFxgfCR/9oADAMBAAIRAxEAPwChNbo7Isosd7E3U+/TGvMzK5B1Ix6ObD64z7REnMYuAflPOx8D++MjpYBWOnbZhup9sHAg4zTQO4RyC3OJ/vD8jgzwr8PM947klOU0c0cCAtI73MW3hfcHbp9cN3w6+FcnGtb9orLwZNCwLlTcTeS+HrjpzLMxp+FsopaXLacQUKBi6wqoBUMRpJO/LoOeFPaF4XuGE43N1OVcn4fpMj1CNJWrG+d5Qdfpbp/nPFicD8P0me1l84nrYqINp0U5VWf3a/4DF8/xXhrNZqky5bSsxRBpmQKQe9fe3mMa1DmOTZMxNBl9BA5N9entH+pwhryRjEYKRnOZvZV8LOBUqaJoMjNUrpIzNWO8pawW197dfDDpT8LZDQram4cyuG3K1Mg/MYRX4xafM6f+bNJpgkuAdI3ZMTPxJf8A+AC/V3OElmPZjwFHQjw2XUS7DK6C3/1RjHqZRlUkMofJ6BwWNwadCDsPLCJ/1GQP6MFvU4nhzqodWYULkX2IV7H02wOcQwpPQhTMPh9wnmDMZ+F6ZCfvwRmM/VbYX674GcM5hc0lZmdC55Dtu1UezfvjcTiNkYjsnVxzCylSPY43YuMDGQJJpV8pFDjBB2HRgFF8iVXn3wMznLIqtsvzCkr4YiLxyv2DkEA3GolT9cc+8T8G0ldNPHJHJR5hGSGeM8j522Ix2XW5vl+dyVkFXF2sZEZ1wOUYd09Dz5YRaz4T5Jm1cssOdSxRse8ksNnA8iNjh6X4+6IekH7ZxHmeU1eUuIp1dylgJUOnV4FTyPpzwKlzhpS0buajax1HspR78m98d/5r8K+EVyibItP2ySYdsRfXMb90sAd7Cw5Y5F+LXwhzXgKWSV4GrcnDFFmP9SEncAnwsRzw9LVfgRTVsvcqp2MgLJLK4XvFbWkTxuv64yhrpY41WOdwnTQxsfTnjPL4tM6OqQ1KjYGTuuvruNx4gg43npoY2KWjTTtpnYBh9bE+uGQY11DIrkhiSDcMOY9fP88MvBXDM3EtdqcEUMJBmkU7MPAHC8tP/FKmKKNP5rtYso2I8SMX/wAM5XT5JktPDAPmW8l/mLW/HCbrNi8dx+nq9Rueo55fVR5flUdBDGIIo1VU0CwthYfiKgp2aGeXVUAsBvqCqG/AnfwxHW5pqy6oNOWLCJWFhupLW+uEFryOzMr3BN9VufjiSpM5zKtQAAMSy6binLnlmczMt9AF0NzsemIn4xpAyhIJ2U8ybKL4Q0nhDSdqGvt8mn9cY/aKZr6qaSQcz/NC++y4aUikK+ZZFFm0OY18EkcukCBwVZuR1rz3wbJCKSxAsLkeOKbp8yp4KpWGVmyodjUNubjf/PHDFT8exQ9klRRdnTqw1kylgq33J8sKZG8CXUmk/cZbNHNBlNOs8zL9pI1anI0xA9PAeuNaDjONgzGZt5HAaxse8f0wgU/EtFmv2uaKsinWnk0xsxFgn3TY+4vbpjUpOIEiFSJEkWNZWcd0kWIBPp44kNJP3Tt1mpQAmMS4I86pc1RYZCsiMt9YPeXpcHmDfC/UzTUs00TTa0Q7ODcMDyI/zocV9w/nmdZ7m81JkNNLK0ygsxW1lHUk7KLHmTifMpqmhopaHMhWR1lFWzUkgp2HKwceRHea2GpU1c5t99GoYhB15h+bOYIKmcz1SKp0hSPIeXrjeouIHc/6av12/se9vY74q7XDLKzLK6gN3RNH5DmQTiGVwDdGhbw0kX/HfFIX8zmOAOpZ75vRLU1BqpUnrGhcRtJIQ6SW7pDg3XfzwXyus/j+QSUfEIFQ8umOYS2OrugXuPMHfFFySsFcRagHGk6WsD5HxHrh+4YzXtqFi7adEjjSx20AC2BsBUcQKVDPkygfiRwP/wBIZs4jVjlkzE09Sg76ddDf3D9MK8AruxQQmeaMDZ4kEin08PTpjqDjPJqXiLJamkl7y27jAXKPa4t+GOTc1oanKMwqKOaE9pE1iQCL+dsV02bxz3E30+meOpcnCVCIpHzAxpdmspCnlf8AfDt/EStGqrIQ0ZV/0OF6kgip4I4IyzaAFAWP98bZVwrWilsB19cIs9xzKafYMTyWtISVVdrSAgj3v4+WAQeFqtVMMkjF7LpW4U2vvb9cFJFYKb3G/hfAZ5NVSylpXhsJBbuWIOm/5YOsYMXc2RCwityjcEeI/DfEDaQN1k8gAPph1+HXBVNxrHmSVDz07xsFinL3BNjcBb2ax5/pj3M/hRX5bUNHWVcEcaHvTIrMpBNlNuhPh642bVBwYoVsRkRLy7L5szqDHRUss0scbSHSttIFtyeVsQVM0UlO4FySputsdMfDbg+k4ZyKvghBkzKqN52nUMyhVFlH+3vX5fexztmyvBnVfG1P2EkcpVolsALbXAsNja/LALaGJAjRVgDcY2cS/DijyvLaTiTheWQwiNJpIL6zoKg6getuo9bb4UKrM3q6CSW2mGpYRta5tYXIHqAAMZ/x7iLLckqcppFeSikDCPUveRW5pqvsDf6E4yy37CmTNRy0xlmDl3ATbVsbA9Ov4YwggAnmVaUMS9YOAR+5dvw0bLeH+Gop4amAmZe2qZ1IsGPQnoFG3sfHFYcS57Fn1FmmZrq7KvzhpoTawZBGUvv6DCS3DVRNXkR1lQctqLAdop2PQE3sfC5GGfP3SjyzLMtI7P7IjX0Je46G3ib7+d8CQNwx5hV6d6q3dxgAYH+4DplEikiGRtz3rW/LExF1JCk6ee3Pz3wK/i8dMhimlm7TRqVPl+njhVruJf5oSmWYADVpZhcHyF/qDvikCcwmOk0oDWZXKm2+1vpglSVohhaOIMARZtragbX/ACwmZRmqZrJdFJjj+azaSr+BHTnhhiYsGEaOBfu6nB3wqwR1JxG9M5usMPeZ5FZyfAtsPwthM4w4fy3Nc9nqexLBrC69fPGx27rISNQB8+VsRiplW41svkRfC1BU5Ee5DDBhntZHN2aW53sGC/liNjpdf5anUNPfkOIgRz7MAjmXe+MZHJB3iG99gTvhmIndPpUYqQFhDEdATgFX0zLPTMwN9RGzbkfXflywUke5OqzDnz07Y0axo9KsFd442DgKb8jvz8jglgPzLR+EqVdBmNVmmsCgpAsRRnuGlkYWC9AbAknoMORXiAcS5jmmb1sb8N9qABEy6Y473HdtfSL7k8yb7HGh8MUjzDgOoipqYvWU1bI7xEAhmKjQzHwA/LGcebZlw5GruoikUtpka+ykb7Dn1288R2+5zHV8KJuJwzSjiiTixKqotGGWmiAYGWMCxIa4NiSxIGxv5YnquG8s4zihesdr0pbs5oHAkjTmY3vuR1H54TP+voZ9FHSV1T9np4iAJWARFtuF2FhudrYYcvzLKMpoJKkVYNUi9zSwGvysTgWVhG1uoYEjiBOJvhy9Dl8uY0M6Tx06auzaMhig5m97EjniuWR2qGkLyspUWTtLKD1Nh5WxeNXxJTZ1w7PUU1i88ZjZF3bURbTYc/XpiharMaXLyGnMcbKtiHY/l7HDNKzkEN4l2vqrRVsr6MIZYyIklO8cbIh5O5PdP+Ee2Ms9MtVMjyPrBiUowB1FdwDfx238cCYsxStiE9OygMhAJUi4vtt64e24YizrJhBThv4lQxJKqsShlDA6k381uPp1wxyEbJhBW1OmKp2P3K/ny2CtpzBUJGTsb3FwfEH9cVvxXlcGUTRwy1DdqwLJI6+B5E/T/jFmIwuwZJCyt1Gy+N+o3xW/HkElTnS6EKrIgCqzXAPgf3HjilTPPsIc4Gp3XKpaqZTqqJCbXPyjYeu98MgBif5CAevO/njTy6iGXUNNTRGMJCgQ2P1xMSjkoZC39uAbkxqcCTk/MSrC+xG2MQbC2jUOhOIo2BuGLdzZv3xgxAYgkm3I+OBxCzGUbWstr9dH7nHpExXTZt7kAAfoMeU0sVTSxSg3SQc7YmMCra57p625YLEDPEH1EEzRgkMCdtzzxGIVMUkbLsy6WseR+uNuopFYE2Nxvblf6Y9gpJEDahcoLux3Cb/L5n9dvHGE4mdxr+GeaS5Nl84ppXSoaZW7BImYOAo2IAJtz89se8W8e5vXSSho6Nhfs43j3C8xuuC3w4yOXN6GoRM6lywGr1zSQ/1FVVAsD5k+m+JvihwVU8OVMDTZhPXwSlgJ5Y1SRRzbdbA8+o23xMWXecyqqljtU+f5lPNlslTTvJCRIzfNqXSAPLxxjSCT/TxrSVMkOo6qnkhPMgX59eW2GRa0gIaZAY49xI/ysLcgOot1OIqulaaCpzR5JaimgW7PIAqC5A0oo5+e+GhjnmW6jTVV1nb3LD4S4fzNcilzyUCOkZAIaRbDREOTHzP5YCZrwitXIrRvGZat7uGS6m4JJ9hhj+FfFPaityCuaOWnqo+0hZu8LgfIfEW3HpgvVZMaaqjDmQR2YpZzY8gR7ftiZmKMTG6Daw9C0cf9mKvDnBwkraqllkRnEClG7PZSSbAeHIYdY8opmqKetgmb7WoKPEW5794eTAjp5354DU4aKuMrOwhNR9nIvYkFVtc/9wA98F6R/sebukKr/qFEgvsqW2b/APJt5nE1rMxzmdytFrXaoxEj4m8ITQO2c0UDJE1mqEv8pP37Dx6/XxxT1Zw/JPX0tTIg/lMzAC3Lp+OOxmhappWVnSUlT3XUaW8iPA8sc98X8OHJc8kSKIrR1CianI3/AJZ5r5lTcW8LYp0eoJHpnuef+raMKfXXz3/cSCtrC2sMLA22xCqMHIEY1qbghcF63L5GQlQRJzIXfWP7hbr+fPnfGnBTds0b94uN2PQ4tBzONPI4JyGJ3189ha+PmidDZgB6sowQ7MIuq6+HPpgNJl9TmjtURVnYw30ott7Dr7m+N4mZkuUZi1JXNQTBFVmIs3JW8vI4ZVbbQdOnpt+eEx75iolVi1XBbUjXDFQdiD1Iw0QySTJGGdbkXYadrYJoAMIUsLVE8ccQ1SSG0YA3Hne30+vhjakWGSsXK6MjsoSWkmvYFgO8/ooFh74kBfKcsaTtLV1YpEbFTeOPqdup5D/jGMNEIKeLLmcxz1SdtUyqv9GnXvW+g1H2HXCfmGfxDfA1UuW5uqRTSxtmzFadL3ICjZj4F2Uj2Plh/wDinRzcU8FZdVRHtcxpKgJJFcWdX28bbbHfocU1/FWXN6fMY0MPYSo8SHfs0QgKtvJRY+/jjoFs8y2ehSGlKlqiRe5K1nB1Ana3T8sIuUqwYSimwkYz1Kx4W+E1dWgS5m2iG9+xQA+2Gz4gcPwZVwJmFNHGix9hsoTcbjfFn0CiSkQsAFXY26+d/DC78Q4YpuHamBg7mZdB0qW28z931wn1CzAmP254zzOZeFqSrrOIx9grZI56Jdcd17paxBLH0sLefri1MuzrOcyldcwo7Cnd1d4XBUnoFB8Ad/GwwpRpR8M59mNRSR9nr7hiLfLpG4Hlv+GJ14uTL8piaWRI2trdyQdTMb25+Jw58ueBOtRpq6QrWHkeYwT1qSU2ZRLFN2gmZg2i2lhYrzI6gYFyccUUdfSSSySNKo1OsCaliVl+UnmWG18VpnfGlTK1QYqgxiZy2kAAnYDc9OXLn6Y1OGqWPMJVkWsjikqNmkkVgmq/W3L1tgl0wxlom/6qdwSjBPz1OlOHOIRnKa6FxLCpsZCDYHw33vgZx/QrW5WYXaHXFULJHpbvkMDqVBzvcE268vDEnAmXVvD+XNDNBDPqBu1PKLk+NiBhF+I9LKub0+YJBMkbiwk0kaXDX59GHP2xPXVX6mUaa1Gs1BqZLqu/++YqQprqBQTOscwbVTzB9tR3Av8A2tzB6H1x48JXtG0BJENpY9NtJ6tboPEdOfI7Ea2BM6pI54wi1TOQdHISAEsnowGtP/NegxnDKuc0LzJKDmdGhZ2sAZ4h963VgNj4jFvzODFypu1k1G77fKNh18sA8xz18sqBTR01Y4VQSY4+6PIWv5YYHCGNpQFAk+4WP8vwHp1HuOmK2zmGJK5gammJtzeTS3v/AJytho5gk4h3Iqt2zJBq0utxvzI8D5YdaBAs6doqCNm1Ny2A3thFoK/7JWCoN5E5MTzW/PfDmZ1e+i5SwLH8R/nlgmEAGG6dUzOvmr65R9mpwHddQ5DZEB8zYfXHtVWtHlkklRJF9tzdu0cqTYU6tsB/3uP/AFjHjjCGH7SMvygN2Pbt29VIb/yxYm58ljBb3GB9VVyZtmFRVJCIqdrLErEjs41AVFsfBQL++FAcwszx3MisquXY7C3XDvxHNW5LW0dSCIJGQbkFlRrbn9PY4GcF5SMzz6nWRUMUDdq4U7XHL6nFq13Zzs6yQRzQBhZHF9xgbO5tDPeFONnzDJkhlzKEVrglUdRZT0UrzN9sGcxtVZZIuaVaUc8qG7TSrGOWxseY36dMI1dR5ZkkU+ZZbStT1aKZNSrr1Bd7EdRgpS8Z8O/EPh00WbiNJAbyU9Qw1Qm2zRsbEr1236YkdD2OpZXZ48xJ4ipKTNqNqPL6ujrszHaG1LOH1f3W5cr7eOKazGCvnqHnlUq/aGKmgJNoxy36g+J5jkLYIZ3IaGdly2ZWVJXMc17XQXs45HwPt5428vBMQqKjV2zCx1HvAX6+ZO58z5Ytpr2jMHWa2y7Ct+oCyXgnOs+rZKWnp3eGIKZG03C38bbX/HDZU/D+t4YoJZ5KN0iiI7SWVwNjsNtzbfF2/DnKYKXg2CaMXlrNVRIxFiWvYD2CgY2+LstGZZdPTbWqoGS56NzB+uN+qd0iavKytOBONzTGKgrZgIj3UmJvo8if7fyxakwpq6jqqSeVQKhCjXPM2sD9Djmem7emkeOeMRMjFWVj16jf3xYHDfxFkyenWkrZL0yi0cgAZk/2m/MfXCNZo8n1KhOt9I+rhcafUn/B/g/3F6CYZVWzQ1jmOHUYKnSDrTS20i/7kYBh7jrjPMIJ6KuFZEIo6iCQdrpF0ElrgjxR1IYeTWwS4ppqXNIajiCgqYJUc3nLuBqbYd0bb+R3PhgZQ1aVmWGKQ2NJGInOq+qmLd1vMxObf9r26YNG3DP/ALJtXpzRYV8dg/EhzjsphHWUwCRVV9UZb+nJ95fS+/0OKn4qyrM6zOJJaSJ3jKqDZuTdcWTLUPC0tNIgvezLq2VhyPoeXv5YqviHiyrjzaeOB6hIY+4vZWs1uu453uPbD0EjYw9JSldU1K1wPmS+6/54YN8MZpHNUCknKKgIbfbujmB7DAKUSwSaozYC9iN+74eY8uYxBKI603Fo5+dr7N5g4YRmBLSacJR11XIVM9axpwVNu7s8u/poT0Y4FwBGYusYvz0u5bALK+J3namy+tZohFF2ayFvmYkklr+N7ewwz5VQrPVRQdvoWZrBgLgePvheMQicy0Ph5A1Hkz1TRoHqWJWwsNPIfjvhrQltCre/zbj2H4nAHLqqKGmhpkGhIwFUfdIAwcyoifME02KXAPtv+dsJP5mxnqMNR9moaRWnjDAgRqgsS5ty9LXvjnLjrKsuynPewyxNCMmv7PI4kKEnZQbD2H446YqcmgzhI46iSZDGS6tDJobla18BOKOGsryaqSOjo4olUAO9tTO3PUzHcm/U4WrEN8SzNQp69/58CcyZlkVbFXCmqu1o5kTeNUB1Am4INjceYxLT5Xdo5Zi8trm80xtt1tsNsXdnuVRZ5lb0UhWOZO9Tzkf0m8L89J5EYrOhyCWfP6TJ5khSeSZUfU4cFTuSD6XxWjrjmQMHY8S8OCIDT8J5ZA4AYQL+Iv8ArjZzZNWWq1jeNh+364O00CQiyAKgACqOQAG2B2axg0VUg/sJHltf9MSZycygjic2fELLWy7iOSpEahK5BN6NyYfUX98KzlpDZiix9SeQ88W18Q6KPMMlSpYDtaKbVe3zI9gR9dOKEz/N2kzSPKKJO11OFkMYHzc7Hy8f+MXLZ7MSMVBrMmPNDHPmc1PQUUcbh27kdjYE83O/hzPht4YsCs4Oiy+kpZ6KJGqqRSJUA0iqjIIkQ+ZUkD28BZJydky9UDMkk/ORuRPkPAD/AJwP4w+IslL/AKKCpKtKu8ayswt4m5uPQYhbc7ALPV1aejTadn1XJb9fgCKnH9eaKofL6eQyyxsO0fq8YF42/wDUry5WxXmqhYlzLVxM51FY7kXwWrkeeR5+0eV275u3eHmD4fh6YC1BJkJuPMqpF/Wx54tAwJ5g9x1gqWAaN7uq8wTuvniGdbAlSTHe9xzH7Y1pZXikWRGsw5Hw2xJTys0pNgP5RkAtsD4enljcyYtOWKrL31BsGvYgYP5Lxa2Q1SQ1rrLTOumKq/sH+6354BV0awzAILA0/bW52N+XpgJV1MjLNHqsiANYdT54yZOlOG+Jo6yriWeqhMMi2R13F+hJ64snhqvVyJgxsy3DWvzP1tt544ko83q8lMctHKY1c96K/cPnbp7Y6U+F+d1ddC0UzKwESMDbdRYDSPLCnQTFYgzofK52lmQate9ttz+G/wCGB/Gc4kqqk7/Pta3j9caXD1Q7V1MjEMBIttW5G+NLiOqmd3753ZrgjV1874m2+6UbgVgGSpXcXO3iCML2X0l+KaqcKTIHjMQC7m+nceQsfTElVUtE/wAiNcdR+2PcvzeSkqV7OGG4BsSG2/HDGUkTenuFL7sZ4P7lxrONDv8AcBG52vz8bYE5rMfs7uD3XBFwCQNz12H441qPMJmoe0GhWZATpUD7w68+uAObVss6xO5uVY2vc+HjhYXmaLDEr/i6vCcPZs6trMSKwW9wSH0jlz3FtsVLw7kcOT9vmdbOgrprly2/ZA7kX8/H2wy/EDM6mhbOGicWhlLKpG27g/nincxz2vrqgCecvHJv2R+QegxSFyMTVFoqbfjJjVxHxm0itFlkmo8jOV2/8R1OEF5yxP2g3V2uJCbgt43PI+uNxjpmRRukiglTuMQzjsJio7ysSrBtww88MVQvUG697m3OczKGpalYLINUZNw4Nt/XofwxPJB27a0+yuPGU6G9xf8ALGjJGKSsenS5gMQk0NuAb2t6b4wlHYSNGpuoO2re2NxU/9k=", "boy-3": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCACMAIwDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABAMFBgcIAgAB/8QAPRAAAgECBAMGAwYFAwQDAAAAAQIDBBEABRIhBjFBBxMiUWFxMoGRFCNCobHRFVJiwfAIM3IWkuHxJGOy/8QAGwEAAQUBAQAAAAAAAAAAAAAAAAIDBAUGAQf/xAAzEQABAwIDBAYLAQEAAAAAAAABAAIDBBEhMUEFElGRBmFxgbHBExQVIiMyQqHR4fDxUv/aAAwDAQACEQMRAD8Az9rZJGQSLa97MbqfY9MDTMyuwOpG6hzYfXHfeIs5jFwD8J56T5H98dNpYBWOnbZgLr9MCE2maaF2COQW5xP+IfocNc8qSFlQtBIecb3KE/qp9Rf3w7V1OqrZvAG3BG8be3lhomp53kjhMLTu7BUVVLMxPILbmfTngQMUJVwsiIxlKlztdtmPoeR/I++Osvo6uvmFBBBPVVpJKwxqWZgfIqP1xcXBHYBVVyCr4pnenpiwYZfCfvSP62/D7C59Ri3aP+BcG0wocooIoI1FtNOltf8Aybmfc4YfOBgMVoaLo9NMA+Y7g+/LTv5KiMm7G+MsyjhNUsFFTMPgzCS8yj00XPybElpP9OtCVb7fxDVsP5YYgmn5sT+mLRk4llmWyxJGDzuThvqcyqKgr3jJt5m2GTM8q/h2FRRjFu92n8WCjNJ2EcOUm8NdmrON2BqFs3rsuPtT2IZPVC0WbZrDIvwkujgfLSMSmmqnWPTqFhy0sdjhbv5QdRdzvt4uWE+kfxUk7LoiLeiCrqq7FMwgRhRZxDUHnoqI2jJHoQSPyxCM74P4k4chkNXl8k1GN2ZPvEHr4eXvtjQhzSdhaw28+YwTBmqk2nHd/wBQ6f8AjCxO4ZqDP0epJB8O7T1G/j+Vj6R1mP3MpWxv3cjHb/i3MexwFVQMkiokhV2FwpbSbef/AJG3pjU/FPZbw3xgjyLGlFmJFxV0gAJ9WXk35H1xnLjngPPOB6qOLNIRNQsxENZECYpb9NXNG9GHzOJDJWuwWar9j1FH7x95vEefDw60xLLqREJczIo1KG0SC3lbY45lzhpdUbuagW31HupR8+TfPAa25owlJ20SEqyex6jClQxeMRTR96Quwc2cDzVhzGHFUoZ2Ml2SWVwviK2tIg66l/vjuGuljjCx1DhOmhjY+3O2Osvj0zo6pDUqORfwsPfcfUEHB8lLDGxT7tNO2mdlDD62J98CFK6gokhIYkg3DDmPf1/XHKyuwJFy3xXHJh5j/L49UtHUsPhVybFjsp9/LCcBnjqkpRC7yzMAEUaizHYWtz9xgQBfAI7KKarzquiy7L4Wlq520rEo1K59R098aV4K7Gqng6kNYMlqarNJFBaVFJEe3wxqxuB68z7bY67HeH8s7Pa6jrs2MZr6kFZqnTq7k28Kgj8I6nqTfoMXlnmW1/EEdPWZDxK9EYx4e50yQSm97t+nX2xQbR2lJFKI2ABvE38lqqKjOz3NfK0bx1N7Dqw14n+NRpl/E2YUsctNk9VJC4uHSOwYXt5+mGDO+Ec8p4mqKjJqingLAGSRLAMxAA59Ti0OyzNM0lzXN8ozGoLLl0egQWFo37wg2I+eOOIajMc37UKHIWqGbKI2gqnp7DT4F135X5gdeuIhrphK6MhtgL65Z81cmtlEhYbWAvrkq4g7P+J0JLZFWKeVlS/98DZZkWZZz3y0FDUVRgIEgiF9N/O/sfpjR1BNXPnucLPTyJRIIDTStbTIdJ129jbER4By7+FcYccUoXTGKiKRB00uGYf/AK/LDLdrSFjyQLgAjvI6+tNt2k8tcSBcAKr34M4lgjZmyKt0KL3Md9vYYRy/h3Pczg7+iyqapgDldca3AYcxfF/0NLPldZxBmFVXNPSTSiaKFAzGnVIwGAHmSL2H64A7P8xhzjLK/MKeExQVOZVEiIwsbEruR5nn88c9rS7hcGg2tjjrok+0pN0mw04qk67hXP6GBp58lqoYkF3dkJVR5nyGAcuynN84lK5dlslU8Z8XcqCFPqTsPri+ssknh4TlOUz/AMdqA0yo00mjUSxuniufDe1uuB+GqUZN2bxtTqY5/sMlQxAs3elSSfcGw9LDC/asgabtF72H+Z/3Ul+0nhpuBe9v4Zql67Ic9yWqimrqGopDO4VbqSCx6XBtc+WHfNcpr1yqpjz7h+p/hjAJMZogUsTbcX88Wjw7H/H+zKijzAvKanLyJGlN2JANmJ8xYG+PnCddT8dcDpBXfes8f2WrAO5YAb/MWOA7Ulbclo902P65FB2hIAbtFgbH+5rEXa32NZjwZGM9p6Spk4bqWBWWRfHTFuSk/iQ9G59D0Jqi5QBWtJEDcEdD5+hxv/tA4igzLiNslaKOXLKaM0sikAqXYeIEdRay/I4yJ2pdnjcFZwZqWNv4PVkmB+YjPMxt7dDyI9QcX9BUvmiDpRYnwWd2nst0cYq4xZpzA04d3goATE673Fr2mQWkX0PRh8r+mDYBX9zGIWqJowNnijWRflzt7dMNsi2FwQG9On+fTArGRWNorg73W++J6oVPp4kdmOlQWNwyjY+hGLN7IuFfv5M+qbNFSsUpQRezW8Tj2BsPUnyxXUeX1D1MUNMpnFQ6xoLXuxNhf5nnjSEdBHkGSUlBSRMVp4xHrXYn+Yn1Jufnhid9hYarQ9HqMTTmZ4wZ46cvwlsr4ky2jzl6nNMvNfRNE0Rphptvbxbnnt6c8TGg7VOH8joHpOHeHqmO5Mmg2WPWepIJJ5DFVSxMLk6lPtfA8TsuorLK0RvsFCYqpqOKZ28+/PBa6WljldvPvzU94K4zThvOM2zKupKipmzEXfu7KQxfUefTB8HaPl8XHFZxA+WVrialWmiiUpqVhbUT8h+eK9AhNOshEjSMxumq9h588OED0eVUpqDTNV5lJKsFLAjj/wCRIRcAHoALlieQBOA0EUjybYuw8Pwm5oIGh0smAtieof4pjl/ao+RZvmedZwa45VmEhSkpHe7BtXhSOPcsbA7KMR7Ou3jMKbPcyq8k4djo5amKKGRs0k1yBo9W/dRkAbNbxNfbliBZtnU0dfMUqBWZswKVGYobCMdYqcfgjHK43Y7k4jl21bhr9Rfn64uIej1I070zbm2V8PtmsFX7ZMzyKVu63K+p8h4qeQdrXHSy1c8efQQfapu/ZEy+IqGsAbBrkDwja+CuE+1zizhGnaBI8ozKjaZ5+6lp3pm1MbkB0JAHl4TbEKhp3CA93L7nH1UVm8KyseoCf3xMfsiie0sMQtyVaK6oH1lXJwt/qE4fMZyLLsknynOdTOlJXTqVeRiSSrj49+mx5bYeMh49quH8tbKM7y2praR9YWaEjUFcnUpBNjuT5EXxmji3hz+K5a7rSyGogGuNuRIG9gf09cSTsi7UZ8xkh4czypMlRINNDWufFLYf7T3/AB25Hra3O16eq2DBG0louDjmb81qNkbSgqT6vUts45HifI+KuzMe0qmXh3+AcO5XV01NHD9mEtQw1JHaxAsTvbqT1wPwHx3ScG5ZVUs1BVVDSyiQNEVAA0gdT6YY8zyR072oNQe7BBtq02/c4aqOnSUStdDptp1bknEH1CH0ZjtgcTjitT6nFuFls0PnmaJX53X5jFHPGKid5lXa6gm/TBNRlsPHvDGY5LWuykgdzORZ4pB8Lj2PP0JHXDRmEcaaQIWQAlSA4uDjrKqtqOqSWNJAincGQG/niWwbgAGikGNpZ6Mi4tbuWWsygqclzGpy/MYRT1lPK0TjT92WBsdunuPphtmaASMDO8LdUKk7+454u/8A1BZHFS5tRZ2kIamzFTDUC2yzINj81t/24pg08cniXMKcL0WdQWA8r4sWO3mgrzWupjSzuhOmXZorv7Mcuet4ygBBMVIj1DLy1EbKfe5G452xbucVDSVAjKI6oLeJrfW2K77Ez3zZzUSlS0SRxKw2YXLE/oMT2tkVJSWKPq/EB1xEmN3rZ7AiEdE13/RJ8vJN8kRO1oBfyDHHaxpDTlSEDdNTAkk/PCdUVnfwJ4B0vp/O2BVkiaXSFdoyNgpvv88NK5RcMI3J0hbXBL3wxz1xgSvr0sJO8ky2iUG3dqLGplHkWa0YPkhw9lxFuIDpSxJZsQSpZjluSwAxgxUMcrAn8cpMrH6viz2YwGQvOg8VlOllQ5lOyAfWcewfshCugjIdYjo5c7/LC9KhllB0uLciDbAjuhYBpLq3MDkDgzLhoJUpq/lLNYYuVhU5aSjAhAWH8zk4Vu7DxGQjy7ywH06YHYkW/wBoW6AEnHakWuI4/dmOBC6sbkd1Hfzdyf74pzP4XybP6tYj3YimEkbxn/bOzKR1FjyPpi3Xc/zRj2GKs4v+84inVG0yhEANtj4cNvFwlxkg4LT2Q5yeNuBsvzMMO8njHfBbC0inS4+oJ+YwEMrqKBGmOy8lIa+r0xEuwivK8G5xRzwvppqxiFA2syK2x9wTiYzVn2hBFCyaGsFSZrEH3xm5W7jy3gvWKGcz00cpzIF+3VNqU0uZzy6rbLqbewsOX64AEbUFV4oibHbrcjkcOg7yKTvS8Sul9SI258xbCaympkMzHWl7hbbAH3w2pV0B2j5e+d9llezLaahC1kbWvsjWYW8tJbGUqhUWSwRV26EEH2v0xuSWjFXkeY0LIixz07oEH9SEfTGK5KIyEMtNNICPigIKk4lU5wIWO6TRASxyDUW5f6tC9jsWjJs9a12M6E7bg6DbExkM7jT4rnla39hiI9j1Siz51TDxK6xyg25jxA3HzGJnLAqsQwst+duWGZfnKvtjEOoY7dfiU21UU7RhrMCRzJtfHynTTtp3t4rHkfrgmelQg+EEjfy+e2EqeOUbqpYnYG9xhtWa80euRQQwBNj1xXndO9PSFmAaOFICDvZox3ZH1TFqQwSMUZge75GxxBOJqefLOI5gI2jpcwLTwhTt3gt3iehPxjzu3lix2dIGyFp1WX6U0rpKdkzfoOPYf2AmWTLx3etAGJ5jR+mHCiEpjUdzcgbm2O4w7J4w1x1Jx4IoO4Q2/mbF2sEiWE687KP+S48urou//Eb/AFOE152AgUf8L4LSJW2uL89l54EIaUTBSTrGjc+3yGKcznVmOY1FUwJWSQst7gi3Lfzt0xYvFeYxxQvQxtaRhaRrbKv8ptyJxBxSS1dTHBTIz1tQyxRpquJWOwAP74ae4DNOxtJNhmVdXYtTTxcF5lVqt2q6shSwuSEVVJuOfXB5pKnWWKgLcldhfEhynLf+kOHcvyqkXvPs0IErW8LMd3b5knDfL38t9CbeQxm5Hb7y7ivVqKAwU7IjmAOeqZBK1KzlU7wyqVDOtxhWmaqlMKU8arUA7MB+dseq4qiJDcuqk8iL2ODMiMgmFQJLS20kFdjhClJ24Zp6mOqqxUyM+kW3+EHqB8sY3ZmMs1pBYSMN30nn1GNt1U0mW5LWVb6SkMEspa4uQEJufpjDCVT6FLoWLC92ABxJp9VlOk7h8Idvkr07Ns3GX8aQQlgsVarQG+wDW1L+a/ni4K0GKdoyoVOYuMZsasagq45oLpNA4kTVsVYG438r40clenEGRUGaU7BUnjDkWvpPVfkbjHJ243T3RupDonQHMG/cf34odzGF0kg35en5YQjqIUcBYbE87Of749JHIy2772up39Mfe5jhhnnqqpIIqQa3mksioPMkjEdaW9sSiKzOKalEcTx1NRWOpdKSkszsF5sSSFRBfdmIHviuuOON6eagNFVUdBTObNFM9cZJEYHZxoS1wfInqN74eaWrvnGa5hK7RZZm0C0SQyA96Ej3WoK9AWZvDsbC9sRPiXh2HO6ezSxxVEdwrndQfI/0n/zi6ioGtiD3D3uVlgNpdIZ5J3wwkCPLIG/HO/2SXDnE9PmkfcSVUTVi8yo0pL/UgIv8umJC2ocy3yXFH/w6akzeCkmjMcveoGQm4YFgLqeo9cSbiWnruHpw9HW1CZfMxCBZT92f5ef088SmSmxJGSzzmC9gVY0lQsCGSaXu41HxyAKLe+I3m/HPgenyxRI4+Oe26+qqdz7/AK4rWpqamqYGeV5WB2ZnY2+v/vHoJpO8AZuRsGXmPb9sBnbouiLipdTTxtCJGZ/F4u8Bu1+vv+uH3hfNaXhquGbyJQTzqpEfePIojvzbwqRqI29AT54iio6UCVIILlyuocmFr39Pnh1yrLZqin+31kn2KlTcyEEGQe1v/eGXfE9whPxSugcJWGxGWR8VdmW9o6V+WzVlTlqJl8ZHe1dHUd6sAv8AGylVbSLblb25nbD/AJnRiJe/gCGFgCPvCb36i2xFt74zlXZxLJ3NHl0Zipw20KgD7R6XA2v+fXF28E5y1VQ0vD1aIhXUdIoikjBMc8SgKSt9wykgMvqCNjiFV0rWND4hhqtfsPbUlS8wVThvH5dL8RhgknYsra7abkXLdfbC1M+hR3Zv0uBe2Oq+lNLOVecp1XUOeFMuo2qCpjZpELAMVTliuWpQfaNnbZV2a11mCT1umkiLC+7nxbWN/CG6YzKaRzvHDIqHl9niLofUFbge3TFo9vXEUNXnNJw5CEkpssQvMl9zK4HI+arb/u6YqeKOFkUx1EFv/tn7t/mDzPribC2zVgtvVImqy1uTcO/X8dyk084lIWW40ndreID++LK7IeJhQVzcP1rh6OsbXSyA+FZbbrvy1AcvMeuK9ltLqJYst76uqH9vfCTQNDaSGRkINwwPI9PY4W9ocLFV9FVupJmzN0+41C07WcPwa3maWOGnUanZ7AJ63PIYgXFeeaBlU2SxHMqKlkkcySDu4JJNFkKMdpCp1HkQCRvhny3jReIKZTmZetzqn3WKpA+zRgbCRYl2d/MtexxzNXTyymprJCxkcRmWVjsTyG4sB7bYlUlCGbsznY6W81Y7W6RessdTQMs04EnM9gH5Uape0WD7WaTMqWoo5y1gXN9R9fX64kVNXU1dG70s0Mlr6hvz8iOYwNn/AA/SZ5StFUCFJRsstwdJ9R1HpioytVleZCmkkaGVX7lZQSo2NufS35jExz3MzxCzQa12WCs0Gj4gBppikdZTtsp2liYdQeo/I4ac5nq6DLp6LNoPt1A40Cqh8JU9NS9CD15euIrmeYZlTVQGYBmlgNlqU8MqeVyOY8jhxr+Ks0oFo6uJlngqYe8dGUbeIjSAB8Ow2N+vmcJMguuhllGU1xD8Txcth4l/ceh+RwVSQtVzRpF940hsgjGrUfIjn8j9cGIKfNKhKmkjjy9GsZtbfc2PVRz1f0i/yw4U+e0eWJLFkCLFUvtLVVCgyP7D8I9MIDW5pdzkpHQZMmS0X2nOJY3fZlpVYEX6bfiP5D1wyV2avnM7PMgES/DGu2geYI6+uE8xq56qly0zuWleMyeJVupDFedrm9rm5PytgaCWRJBsAT1H+bYC8AIDdV9NTVZYGajk8bA3YbSgen7jfDvwPxZnNJmFHNFDV1zUFQr6mPiVDtIhZiAQyE2F+dsfMryJc7qwG8MUZDyHVp+XoT5jE6YU1DS2BghgjHIvZQOt8LawvFnZFDZTE8PZ8wNwrLps2yjjZWShq1SriW7008ZjqIj/AFId7eouPXHXEGb0vZ5wvU5jMY5Kr4IUGxnlPwqB8rn0BxUdTPRPBFVzBBFCO9jnWRklhHmjCzKfbn5YrvjLjHMOLZ4Is1qZamipgUpJJAAxB/E+kAFztvYch64rJ6ERkFrrg81rIulJfC4OZaTQjLt4jsxTBmFVNmVTUVdTI0tTPI0ssh5s5Nyfr054bmMuo6JVt/U1iMLTPNSm8uqROQnU3YD18x74HqGjEn3lPIWts0R8LDzx1Zokk3KsaSm06pqU3A+JL7r/AJ5YGjnBY6LKx2K9D8sLTd5DJqjJAF9JG/h8vUenMYHmEVabiyT/AMp5N6jAuJGSVoHSaF+6kQ3U32B9D/Y4kEea0vEOV1lFKghr2hJCMxIkIF9SfTliNGUxsUluAOum5HuOowNNFEoVlKL3h1RnURGxH8rfhOHY5SzsSHMDk98P8VSUU8cVc6NTSKE75uhHIn5bHrsMK8bU0ZrKepV17uqXu3jAushHI387H8sQuqlGXt3MiSMrKO8icgsoO9weRGCYc/FVkdRl9SWmp4CJKdyPHHY7ofLYm3rt1xLZIHtsmyyxuFOKWlh4gyeGJmhjqqZdHeFTqNuWrzBH98RTM0lpUy1UKxyQRSRmMekrcj749kOdvldVFIZNcD2Uty1D18iMEZ/F9olieJka/ekLfZvvGJt64644X/tFwDGye8m4tdYVStpkqV5XCjV+lj+WB8+4hy+qTRl+XQwyN/uVDwrrX0A6e/0xE4p2p21KGKD4kO5X9x+mJtw5QUr0jZ9XKphprmJGF+8I6+ov9Tz5YUCTgggDFNzCIU+WmXSzikJQA8j3j/F6Dy9sBJG5l1cpDuBfp6YUzSZ55svmJUSPTs5C7DeRzt9cLZU8c05aobTDCNcht0HT0JNhhAF0q6kEVcnD+URlkiavqvEFYX0+RI8h+uI9V5hJnmYQQ5lOsGV0wWRw3wyBbXLW5kny88er6wV8xMmkzN8O+1ugBxGM1qUjZoZQzIpO6jxRsP8APfCZJw3AIbHfEp/zziX/AKiqmgEfcUqHaG1me3KS9/y6YZXjNOCHs8L7XI2Pv5H1wyRVGkhpb6Ga6yoPhP8AnTD7S1gH3U2k3GxG4YeY/wAuMQ3OLjcp0AAWCGZGpyxhuyfijYXK/vgQGgN27yrhLblIgdOHOemAW8JLKBqCg+JfUHy/L2w1TkmQm4J6lQRf3seeErqmsFSQGje7qvME7r64QnQAEqSY73uOa/tgeaV4pVdGIYHY+W2O6eZmlJsB90ZAANh6e3pgQvjTliqy+NQba72Iw2ZipopFW4enc6lkXf3uMOtfGsMwEY0qacTW8jfl7YY6qpkZZoy1kUBrDqfXAhI1FEJAkyMDGeoa6n2PTCQpAFBRyJV/ENj/AJ+uOyxpSksXhMhsyj4T8sESOVWF121kqV6fTAhCrUPEG1qrQ8m8Ow9x0wYcwZEp7IHgRNBN782J3+uxGEqpe4YSRkhvCfr09sIzRLTTUjw3QVBIdB8PIm4HTlhYlcNVzdCJMoknRkLWJuVuCxHXSep98SfNuNIM0y2ny7LKWSljpnUtE5CtsNht1vv64ikMamqgBF0k0sUPIH0w5zRxxzCTuo3ZQQNa328sL9O9c3AvktU1cacXKPBH3asm/UncfPHVOZ3kKTBr2uXU3BA62wXSxxrLKTEjFGVbkfED54TroxT1NUiXtDIqKTzIIvv6+uGy9xzK7YIKtn7iTuZtIB5Ofht09sNtTQEPqLEK4uDfVb2PUemO6ipkmQFyCqOVC22+mOVc0sqxx/7Um5RtwPbCV1Jml0DXG1ujC1w3yPP25457wKoWYDu2Phe/hv79D74NY6Z0Xmkihip3GEZx3ExUeJWJVlbcMPXAhdw1TUrKsnijJuHvb8/wn8sLyQCdtafZXHnKdDfMftgCSMUlY9PHcwGISaG3A3At7b45lXuJGjU3VTtq3tgQv//Z", "boy-4": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCACMAIwDASIAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAABgQFBwgAAQkDAv/EAD8QAAIBAwEFBgMFBgYCAwEAAAECAwQFEQAGEiExQQcTIlFhcTKBkQgUFUKhIyRSYrHBFjNygtHhQ5JTsvHw/8QAGQEAAgMBAAAAAAAAAAAAAAAAAwQAAQIF/8QAIhEAAgICAgIDAQEAAAAAAAAAAAECEQMhEjEEQRNCUTJh/9oADAMBAAIRAxEAPwC5ms1mta550Des1mgTartGp7VJJRWzu6mvGQ0jcYoj5cPiPoOHmemtRi5OkZlJRVsMa+5UlrpzUVtTFTwj80jYz6DzPtoCu3avBGWS1UbT9O+qMovyUcT88ajivrau71DVNbPJPMernin+kcgPQaTbhH/PQ6Zh46X9C0vIb/ke7jt3tHXtg3JoFPJKdRGrD3HH9dDdRUy1blqieWRxzMzlj88693XIIwcHUfbSbexwVT2609zUVcZIlqpMmKLHNQB8bZPIEAdT00ZRjHpAW5S7YY9yQT3YweqcwR6aaLhtVZLRNu1d0pqeqHDdDbz/ADC5P11H81xr7srRV10qJU/NFBJ3KcfMJg49ydCO1tPb7FbY5EoIzFNOqyiNyjEYJJBB58OupyL4lhLV2pRxlRbtqljb+D714T8n4fLno6tXbVU0cHe3KSgq6VPinEixHH+oeH9NVcoI6i3bGGhh3x+OShYxMgLFG4An2RSdNW3VygqLklOtLSLJRwoipHGFM0jHw5A+Lgucn++htRk6aCLlFWmXv2T7Xtjts6paK23ul/Em5UckgEjf6ejfI6Odcq6+hipoKX75M9TXSAyF0YgRDoAQeJz15Dpq1/2fO0nbM7NVFZfmkumzsVVFQUjzH95VicMRIfjReWG48OegZMairTD48jk+NFpdZpNQ19NcqZKmllWWF8gMvQjgQfIg9NKNBCm9ZrWs46hDeta3qOe03a97dTmz0LkVc65qJEPGKM9B6t+g9xrUYuTpGZSUVbG/brb4zyS2m0zFIuKzVSH4z1RT0Hm3XkNR2IscGAwORHTSTvYqSneWZ0SnQEszkKqAdSemvWkoLttBII4FmttsIDGokQrPKp5bin4ARyJ8RHHA4EurjiiJPllkLACpAbIIHA6++h4epH99R/tFc5bVdJ6OxV0i2kEBnzvyCQLhirvklWI6dcnlpii2zrLLT3GlillnuNcqtRmZjII3GRI5J6KN1sdT76kcikSWJxF/aLtoKb71a6Ko7lKdc3CrVsNGuP8AJU9HIPiI4qCAOJ4RlbrrH+HSV4g7uJadTHCo4qpZtwfMDPDTLtoWprdTUS953tRIXd2bLTEcSx6kljk+um+pdxbroEJCw1UMIK9FRCBxHqOmr7ItBFsfPJLVXSqeXvWlCuzPyHPljp6a3XVi7VyWimpsGOSpczIwwyqg4gjpkH9dDVvuYW03YMR306pEJFAyck5PkeAOn7ZAJaLVW3icF/DuQkfmA5AZ48WwMap6IiU6erobnf5rhwp7ds/R93Ghx/msuWx57q4Hz1AVXdnq7nUVcqKJqt2ZFbluE4Az0JHD/wDdG18Bt9hhtkm8Z6sNNWSDhhOcjZ6ZyFHuNB9jpJbvf6dHi7yHf7zwjiirxC/LAGqgq2ak7HKqBp6mURnKxIsfcE5AwOPHy1fPZDZSmoeyiz2uGM/uKxTOsZwzMuGY+5DE6oXc5+5ukxeMsjVG6FA4g5xxI5ctdFdmK+OlttrnJxRXCmjZH6I+OGfcY0t5XSQx4um2NVFcWtN5C0Mimjht+/3KnwPh+Gflnjz46kK3XCC50q1EBO6eBU81PUH11GN3tctLtPdBbYQytRRvJTlwpyZCTuA8OmSPXh5aTWTa8WWuMtQwgh+GoimO42PMA8yOnny66Tg3HT6H8ijkXJdkxazXnDNHUQxzQuskUih0dTkMp4gjXpo4qIL1dYrJaqu4TDKU6Ft3+JuQX5nA1WyqrKi4V9RXTyF6mZzJLx/MfL06ew1J/a9eDvUFnjfBP7zKPPmEH/2P01GIRZPFndYcm/505ghS5fonnnb4/g33yOSa0zy0y5qKfdqEjxkO0bB93HrjGnLbXbOqqbfQXejK/cdo6dJ3kHDuyqbrpnPDkuT/AM6+kyrcQA46dDoXp6MVOxG1GzjZMuzlX9+pVPA/dJhkqPQZ/TVZ49SJgl3EFrpRvSVj0zGOQxBSHhYOp3lDc+vA4PTI4aBNvoWewSSRvNE0bDLJwIUnjy9cH5aK1n+82e3zOrNLBvUM3HjmPihPuhU/LTPe4Iai3zxSI4V1KMQ4HMYB99YjoJLZGFzu0FyaxrUg97FgySAeEuGH9QufnpujuU8Zq4aiQCKq/aB8cC4ORnHXmM+upd2F+zXtNtDSLcdopqfZ3Z3gxqrgQjyDzWMkbvuxHoNfPa3D2d7D2OHZjYyne73Qsktde5338JjgidDknJ3QAMdTyL8sW+K2D+N1yeiGjIFkWGQbglbO8Dy/m8j/AF1KVNUUVU1BT00i/hNuiFTK+D8Q4IpHnnLY9tRsjU8sXh3EDDeCufA3sfynRBspCKY1tRUvKtroyryx8G3peG4Aeo4jh541p7MIetr6lkoo1mwJ698NGeka8Qn1IJ9c6bbBEbbbq+vjDSSSYhgXGck/144+ms7Q3ke7UFGIJXHdDwD4gzNw9uWi+itq2u3U9O7NvQLhmCbxLdT9dX0iewCq6aW3qYUYLUhQzktnGTkgHqOPXzGp+7NftR22z7MUeze19HOIqBRFDXwJv/s/4ZEPl0IP/OoG2mqIRWOtHODM+BKd0DLDoDyzjhjQlMXnUxmNg6f/ABkZPsD/AE1mUFNVI1Gbg7ReeLt32Khq5bhFeVqKSWEQxiaOQPlDlgpxngHXn59caYto/tV7I0cLRW2hqrjWY8CyoI48+5Gf01UuohDWqzUzN41pmmMm7h072QkAjyKKv11qhtUNT3jV3erbqfBllUgEZ5LGeOXbGAPcngDoS8eC2wjzy6RfH7OPbTUdoC11jvkdPS3qOM3Glp4AQn3NnKhQSclgRvHl4ZF1P2NctOz/ALQqzYrtNs+1eAaeKqVZI4uQpmHdtEB5CPgP9IOupUciSxrJG4eNwGVhyZSMg/MaHlhxeguKfJbK77Z1hu2111nDEqsvdIp4ZRBujB9wTppVWGGU56HPX3Gk6zGZ2Mg/aMS5wep45B0oQkEHPE8m6H307FUqEZO3Z7Aq43WBGPPmNNJeOy7bWauqMfcLpG9nrSeRSQEoT894fTTqRnjyI+o1EPa12kUtudtn/CrIySvOV3iJVIdUQdDyyx5b2ADxxU1yi0XB1JM+2oGsd+vNjro2dV3pgN7BaSnbDgeW9ExP+3Xzb+0Celq6x7baqCiraOoaGOZ0E0kQAGGQMN1SykHewT6jTht1dFqn2a22hXehrYY6mcA/mj/Zzr65jbUdXajazbZ1NMrRmKqiwrE/E0fwt84yv00skn2MybXQ93m+XO+1b1V0rKqulB+OplaTGegB4D5DQDthBJHV0taiYypjL44qehHtn9NE8siLIu/J4H4N5Kf+NPdv7K9pdv6Jaa02mpdDKpWtlzHBGCcElzwIwTwGSdbTUewbTl0QPUp9ymCEq1Oxz3sa8GHtoqpi1RLYrJA4ajjmWSYK3hklJyxz03eWn7tx2BpuzLbGCyU9QaiGKhp3kkxhmlwQzlfUjOOYBGgax1ot9xWqhKd4uWBxlGOOePPjokXyVow04umSa1nT/ElXe6wQpFAgSLvZPCMDixPpk4+uhLaXbR6wvT0KCKi+FpkyGf8Auo/rppu9/ud1WOOon/ZpyVFwrerAc/fTzbNgK65WA3jvVjbJ3KdRvNIo58eXy1baXZaTfQJQwyOdyINKjY4qu8R5ZUc/caIBs9FBUJBemMc5C9wEb4ySAFPXOSOHL21uEQ2VpTTxkznwFc4aPyI9/ppJS1dVW7Qx11Se8Wgjkq8YxxjQsoI9X3Rn11Gyj0rYjcr3dbnN31LZaGcUoqkTKuFG4kKk8C7KuRnkMseA0thgqtpI1jalFJQQHdjh44jJ5kZ4sx4ZY8/TgA6dpFxpLXYdndhbJWJWWezIKqvlVSq1FykUd63n4PgBPkfLQMt3qWjam76SIkcOPHH9xqo21ZctOh5vNJTWtRHTSO8o4PJwY+obH9vnrox9nPaKbbPsb2YrZHD1VLAaGcg5y0LFAfmoU/PXObZ21z3Ni1RvR00eA0oOd4eQzzH9P01ZvsN7WaXYvZKstNLvGnSvd0MeN05SPOOPnn550PNG1o3ilUthH3Xdjzjzn1XSiM44Ngg9eja8Y23CQQQAcEH8vpr3VACMDMZPEeXtpgXBTa3bqOwd7S0KJU3GNd52kbEVKMZBlPXzCjieuBqsO1VziurzOoaoknkaSatlHGWRjnAH5FyeA0W3uO5bQXu6UMZCQw1s80tVvcv2rcW9hwwfLQvLQwPfLbDTFpYJKuKJqgIFWVi65GBwI9dZbNpFiP8ABpsGw1bstKXmNsp4LxSl+JaNl3KlB7HPyxqPzQ092isVRXyyQwWmphpKyWMgyd2riMuuRj/LeNuPkdWW24pvu0NFdQO7FK708rsm8pppf2cnDqFJVsfynVaZ7ZU2+73awVJdiySQSEcneLwN9Y2RvYaRwz5xsez4+EqLP3vZfsu7MLXJIlXaqS8puyRz3CUVFQcEHATDboPouhLa37ZmztJvUmzlpqLi4G739Ue4iX2QZb+mqT1clRBI61kcqzxuYmqCd/JU4wTz6a8Lg8RqnC/s97BjbJKMhHAk81Pvoq8dfZ2Bed/VUS52uWy41lvtt/vlwiuF8u1ZLUzyRkYCuo3UTBxuqIwMdMkdNRdDAve+CMnf4MDwP/fz093Opul52ZoO8mMtDQKI1gzwibLMMfNnyc9R5DQ7a6h5plUspQHxd62GX0JPT34eujY00qAzduwht9AWQeAyNyRTwK8eWfP0Opz2Qtpo9mEhuolDrI7srjcbpy8vbnqLdk6czX6gZkZO7fvHA4gqgLf2GOepapVqHij3F36iJEaOKQ5TOAePkcEkevDQs79BcK9iS77C7N3WsJqrfHLUNg7u84Ayc9CMfLTVP2d0ltWqmsyN98VMJFPLvoWVg4UE8QN5UzkngMaKKOqnuEMbSK0U5O6Ic5ycsM49eHr+uvenqoYI6gJOs01MCrKsgLEk44kemAD1+egqUl7DOMX6IVoOyy6VE5iuFRDTuT4gBvvk9eBxx9zoSkssVJeKmgrZImhpJmQk5AbB5gj4fbU49qO1kmztqhWi3oqy4ZWOo3fDHjG8N4cmI5eXHy1Xe4XGZ2/bI8RfxjvvGjnqcjj/AF0zilKSti+SMYukPV42mevSSgpcQ0gAVox4GbHT0Hl59dfFhmqlpJRCXZe8OSMg5wOeOumShp5rzXU9JTJ+9SHAjc5UDmSH8sccHHLVrOy/swe5bNM1CGkhhnMRkHN23FJY+uTrcmooxFNvRJ21tuNn2qulMBuoJmkjP8jeIfLj+mhraC9/4ftUtUih5mIigiP5pW+Eew4k+gOpf7XrKRNQ3eNfCw+7zEdCMlD9N4fIart2k71ObJPI+7SrLJGWxkK7KN0n5Bh6Z1McrgmVkjU6Is2kmYkWqKQsJ5N+sqVwGZ2OSW4eufoNM9ZGReLfHQ0rNUJNEyQocrTRKwYKR1Y8WJPAaWVUq0+0tdNKpfuHBQhDvMxHAY69T8teGzdxn/xClbCF++EvuyxqSXB+IFeOSFzxI6akumXHtFubrctotsNmnqKK3wJZJYTud5FlpVYEE5LKcYI4gdT5arltrco/v1ruryp9+QKtaqtvESwDupcjn44mVuPVT5au7bpYTb4lXdCRIsW70AAwP0xoQ7ROy2ybc2aeA2+kgugVjT1ccSo6sQRxYDiD1B4a5GHOoOmtHaz+M8itPZQXbaie3bR1ckR3YaoCYuuCD0O8vlkc/XTJLEe6geNjvR+BlxjHUEeXA9PLRrttbq6ltdE1dG8F2tMzUVXC43SjL4fcjwqQeobQjDIskcsTLunG8McOI/6z5a60Xas40lTaCjYa3jaKeqsokWM1ULsFPIso3hjyOVP10JQ0m5I4eIM0TEEAYcYPlz+mnzZG4GzbS26s3t0RzLlxwwM8c/LOlW0ljkptv7xaoXRVSrk7qRm3QqnxDHyPLrq090Z9BFYu4tlNFd6N1miSQxsgIygZRwOeYOWHIfDnR/s/c6O6zs9LHxHEheJyeA4/pw/vqKpKOS0mOSOqWUHgzQHd3x1HX9dPNvvotiUtzmiMNTV70EfcEqUp1OGb/UzeEHyV/PIHOFhITolqnrKVqUpHUxtPLIY5IwVJ3s8UHPljBxz49OaKSio6WQ91Tp3kxI3pPH42OTjJwCTxPoNDB2ps9rEtUKhJ5pWLBuHehiBkLkYA5csD302HtItZeQVlJIsp4KQQ+6x6k8N0keh0HhINziNvazdQtntlAJF3qiUzKCMhYkyoOOm8zMflqKJBJDCVGBE3DBG9Gx9j8J0V7aXb8cuzTLGixxosUVPvZKoOQB8+JPDnpBYo6akf8SqzvwRMBHTkcZG6kjyH6n20zjVRF5u5D7s5RRbG2sV1Qki19WAEiYZ7lTxC558cZI49NX4+zFZ/wHsdsslRCnf3V5biwAyMSOd3H+0KfnqhFopq7tX20tGz0EYxcqladIj/AONSfFJnzC7xPTh011It1BT2q30lBSJuUlJEkEK/woihVH0A0LO9JBcC22Jr9aIr9aaq3zHdWdMK38DDirfIgaq9tns3LdLRdbJUJ3daoKqD+WVTlT9R9Dq2Wo37TtlTUR/jdIhMsKgVKqOJQcn916+ntrOCfF0/ZeaHJWvRQu2y0cVDUvVDfmVyxiOe8Vl4YA5gg50HyCSnXepZSG395RvYPLGA3nqxm2XZLRbR1Etwt0woLo5334Zhmb+IgcVPqPmDqF9qNib9Yo5Xu1ukjiUhDWRFXjcnlkj4voDpqhWy03Yp2jnbnZECdWjulAEpK2NubEDwSD0YD6gjUk3uvvNvporpb0jq6dQO/pmbdYAcCVPI8fPHvqjnZHtxLsLtrQzVEq/hdYRSVjNyCMfC3putg4PTODq8dLfqe3IY6s/ujLkSc1U8iCfLXH8nFwnpaZ3PEzfJDb2iPttNmtku22xTzwSrT3HdMAroBmSOVTgRSJ+bDcMHBA5HVTp+y/ae21W0kdVbiF2ZRZLg7OAojb4Smfj3lywHkOmrfbQ9kVp2grDedjr42zd2m4yy0S70NT5b8eQDg9Rx0M19kruzfs228r9tr7JfLzfEk7wLGMFUQpHucjjdGcHAHHyJO8Obgqi7/wAM5sCyO5Kv9XRTOmaSNgQrSQrjlzUfPgR6H5aetqLvFe72K2OZX3qeCOSVOKmRIwpyf9o5/LQ5B3r93Kh7xiASrfm/70qhhWWQyUshil/MjDgfQ66iW7OPeh5oo7jOvdpSzyIRn/LJBHn66JK2zVletsjEKiOC3wKxklC7rEuxwevFjpij2guxjEL1kiBRjGBy8s4071tzqxBZ5BPJl6PDFTgErLIuffAGo7sh5psTVSOVevpVibmDvMR9Bj56F7jSC1zyUMNVFXuF8SL8QHULnn0PA8MaebhVz1kTZqZeXHxEj5j+40N1xdyu+qtGD8QG82fMHrj5H31ZR6RQfiFKKqONohFhMPnB9Bnic+WvM1H3hgjArIvBV8/bz9ufvrx7zvz3VQCD8YIyM/zLn/8ARo+7Jey65dr219NYVRhQIBNW3FBwggB4k/zn4VHU8eQOo2krZaVukWI+xh2ZMq1/aBcISDIHorZvjiRnE0o+m4D6Pq3+kNmtFFYLTRWq20609BQwrBBEvJEUYA9ffqeOlukJy5Ox2EeKo3rRGRgjIPQ63rNZNEM7c7GGwztXUUZ/C5W4qoz92Y9P9B6eXLy1Srtt2oa57Zz0TTO9BbgsMSxtlRJgGRgOROTjzG7w104liSeJ4pUV43UqyMMhgeYI6jVMu2/7KU9uNXfNhaU1dubMk1mJLPB1Jh6sv8vxDpkcmsWb6yFsmHfKJUWohYBg8v7KQEb+SQc9D5/11Y7s4+0BRU1ottnvtRLBWQxCJpaiPvaWfHDeDr4lJUDIIIzk9dV3rsW5mp5I5CMYlhkxvJ7Hr7HlppSTdLyENJBjB4eJRnhnyPr/AF1vJijkVMziyyxO4nQOhrLHVUiVtE5tscnEVVvkWSlc+pXKf+yqdQr9oPb10jXZ+iukdwq5Y1+9TrjdjhzkRLgkbzEAtx5ADhk6gzZ3aW5WCoE1uuVTSl+UtPKULehAOM++viqp1nV5Ym3nkYsyk53zzJ88+f6556Dj8XjLk2HyeW5w4pUfNLAtQm8igOeJXkCf7HXwfDJlwQyni+OP+4f318W+XuJwDvd2eDA8Snr6jP005UqfjFTBTR/50jhFcH4STjJxzXzP102Jiu2001zlKRKh7td55WOEiX+Jm5Bf/wCwTpRdHjqqqGGlJ7mlhWCJj4TIASS+Om8zMcHoRpJcq5WdaOhYpb4Gyijh37Dh3rY5senRRgDrlPBPk+Jt0j04f9HVd7LMkYklGBWQHGeWmStilBaKVlTPFd74W/t8+WiSRlmIRgven4cn4vY6Kuznsa2m7Xbo1FaqUw2iF8VN1qARDTMOgP8A5G/lXj54Go2krZEm9IFOz7Yq8doV9ptm7NTST1kp3mjc+CBRzmL/AJUHU/IZONdKuyfsstPZLspDZrb+2qZCJa2tZcPVTYwWPko5KvQepJ1nZZ2TbPdklg/DLJCXqJsNV18wHf1bjqxHAAdFHAe+STvSeTJy0uhrHj47fZms1ms0IKZrWt6zUIZrNZrNQhEHar9nDYrtVeStq6VrZfmHC50ICu56d4nwye5wfXVQNvPsmbf7FmSooaQX6ijyRVWvJk3f5oT4h643h666O63okcso6ByxxkcdpIKigq3pqqneNvhkikjKMp8mQ8RraytTHeHjgbHE8ce/9iNdb7/spYdp4u7vdlt1yXGP3ymSQj2JGR9dRxUfZQ7J7s0kibNGgZjk/cKuaJf/AF3iv6aMvIXtAngfpnNeRjJMHhOX57jHn7Npz2XniG0NvkDd2FnVZI24bpbw59Oeflq/sn2JuzAS74N9AzkJ9/yB9V05U/2PuyuiYTy2qurHVd395rpCMeXhI1p5o0ZWKVnOx4yJe6lzFPEShIxwYcCCPcaO9h+yTbjbuZRatnKySA8DXSL3NPjzLvgH2GTrodZey3YmwVb1du2VtENYx3mqDTLJKx8y75OfXRh0A6DgB5aG/I/EbWD9ZV/s8+x3abcYqzbatW7Trx/DqTeSmB8nfgz+w3R76svb7fSWqigoaClhpKOnXciggQIka+QUcBpT01mgym5dhoxUejNZrWt6yaM1rGt60TqEP//Z", "girl-1": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCACMAIwDASIAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAAAAEGBwgDBAUCCf/EADwQAAEDAwMCBAMFBwQBBQAAAAECAwQABREGEiExQQcTUWEicYEIFDJCkRUWI1JiocEkcoKxkhdT0eHw/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAEDAgQF/8QAHxEBAQEBAAMBAAMBAAAAAAAAAAERAgMSITEEE0FR/9oADAMBAAIRAxEAPwCc6KOlFczqFFFc27X2HZw0l9Tjkl8kMxWEFx54jrtSOvuTgDuRQHS6UZ71DGvvGS3WePIgT7kxapC+C1EfXImtgEEg+UkobPY/ESM9qZzHj3b4cZaY18uCo7rK0FE7Kn2HcZQ624pIKkEgpKVA44IODT9az7RZZSwhKlqUEoSMkk4AHqa0oV7ttzecZhXCLJeaG5aGXUrKRnGeO2aiyHfn9fxm7kidHXbVnLbTeHAke6T8IV7rCj6BNdf7xe2MeTqB9KAMJ3xWFhI9PwA1qcUakujpUaovmrmFY/aNpfB/CX4C05+qHP8AFcNXidfH3zGi3LTMiSDt8uHHffWD7gOYH1IpelHtEy9qWoziWfxDvxSq4ajTaIiucQ4jQeUn2yV7f/In2qQbZb02uCzFS/JkBsYL0l0uOrPcqUeppG26KKKRiiiigCjGaSkJoD1RQaKAKgLxU1DItRviYFwXBZU8lq4XdIHnukjKIMfJ42pwVK6Jzk8mp9qr/wBpCDc3tRxVGOW7DFhrfSUJADrpUN+PVZJQPlzWuZ9Z6/FeJT8Zp+R/pi0haifJTkkKzndk/m9+O9bUBozrlCjxUMtSVuICEPLJQpZ5SnngZOB6c1ihRlvQpcxxCnmGFoZbQRyXFHOB34SlRx8q8xm0XO2zHmC4JENxDilFWFDcSnI9MK2jFXQPOyzLppieu8WGSY0dw7nYqhwj4glSFJ7lKjtx1HHqDUvXz98NSxYbCra3BWWQt8hza0hSuoKj1wnrj1I561X6TqKROkvSXh5L8twOLbbOAt0JwtxPoVZ6epPXAx2o+vrsu1Srch5xb09a0vuqUSrarblKcnjO3B7hIwO5KalWI0zeoMawR0okmTHQ00fMXkKXuIClnd0GVD6Ypo+JGq7JYZyIqrGmRJCA598QQzsQRwQpIJUPc5HWowf1GE24wUrJQ5F8tat2ANyknPvwkAD3psTbq69JZdcluvRm0JbIWonCR0Az+HHYdOo70xek+6N1g55fnWqfJaaQnc6I6AXWAPzOxR/DkN+q2tix6ZqatOa1FwkxrddG2Y8+S0Xor8dzfEuDY5K2FnuByUK+Ie45qi1svUixXdifBU602hYWghWNp4ynPY+h7jGanWPcXJFoenMrCdOS1NPPLTlP7JnLJ8ma1jO1BWAHEjgEq7E1PrlrnpaPNFYYYf8AukcSVNrkhtPmqbGEqXj4iPbOcVmzUlR86Q0tJQBSZxXrpXkjPakHqloFFaBKjfxz0w/qbw7uKIgSZcIploBTkqCDlSRjnJHp6VJHaijcKzfihGp7aqF4baVlKQl5Nzlyn1qSrJy3hA6Yzxz681xdFToT16dt91fS3CukR6G68VdAU5QvPqFoR15qxfj54Uso0a9OsDbjaI0lUlcIOfwWw4MLLafy7lYJA7nPFVTgZUoMOndhQUW3fxJ9FINW5uxDqZWSQ6l1DbchJLWxKUPepxzn65pz6Vsjj7rrspSjGjx1y3XsZLUZAypRPcqOG0DqSr5VzbPY5t3m/cocZc15xJUlpGBv6dc9OvbqcDvT6tF1Xo+a5bXDeY09x9Lshl2MxID77K8tgoIyW0L4KQSMgccCjq5Mh8TbtNLV9oXpZ2DCuTYTdJLYky2hwY27lDX+5KeSD0zjtTjs3hq9J8NtS6ikBSAypKYxKOSG8LdV8gFJH1NTHoTwNk61vQ1Vf57V2jySZBR5akJXJ3Dh1CucJzkpHXoeDXN8ZdeM2wq0palOptbTDsRMeE0N8rzVDzHHHVAhO5SSdqASRyVAHFS/s2znlaeLJeulfJFskWZUNuWgJEyOiS0R+B1tYyDjsc5H0qy32b7ZGv2itUWuWkOwnnhEKFDP8NaCSP1WcVFHi5p13T6LTEkWy2QnI7CmTHt4Vn4EtrKlrUola8OkZ4wU4xjip98CtPyrRo7Tk+Otp2Jc4RVLSrhQX5i1NrHqdqigj2BHTFavW86nOc6w9vDiTIk6Is33pwuPsNKjKdPPmeUtTYV9QgH606KxsR2orLbDDSGmWkhKG0J2pSB2AHSstTUFJS9qMZoMY4pMnsKWkJoD1RRRTBMUdaOtFINS529m62+VBfBLMhstqx157j3HX6VV7Q/hS7ZfFHUkC4iPGW1bXHoDj7e5spWdi3GwRg9Qn+jzOxGatZ09zUJa81zOn36yI0hbGZV+T533GQ9lQWyr4HVlHA8lRTtBV+IgkAAbqf3LIXyWWq5+FF6atOsrZ+0mnlxF7mJBik+aG1JwXG8c7kEBYxzlNXFtnhxC1BclXP8AeS33VYWh9UmOylS1uD8LiwFFsrwAc7QCQCUk1R+VAOlPEA229F6AmHch5zsNe1bOFglbSuxAOR8hX0R0Ksm2x0t6mt16jhOUvx4rbLr2fzOBCsBXrhIyfSs+e5ljf8b7spwIjiywPLgx1OqCshA6lROSo/XJOKZkvw8t+qrXbN816M/b97SHI4QvYQs5HxAjIIwflyOKcupbra4TbMe4RpMxxw+Y3HjRlvLO0j4sJ/DgkckgVkhXS22/TpnqaXa7ZFbU4sS2/K8pI5KiMng9c85zXNNjruX5VMvtNQRC8R7Taoi3Q1BtzKEuOK3KWt5aytaj3UonknrUofZmvj9x0I5bXySLW+W2iRjCFZOPord+tV78SNYf+oPilNvsbzEw3n224wXwfIbACcjtkAq9s1Zb7PmkZWmNDJkT2lMTbq4ZRZV1bbP4AR2OOcds125nElefu92xLFJS5o6VhsUdaKKAKT9KWj9KAWk60UUAdKWkpRQCYps2bTzFv1Zf7lsy9LbjNtq8vAbZQgjy0npjcFEgdCflTnpKZKm/aq01Dh6kst3jo2yLq0tuSg42ulraEqHorCsZ9hW9oXxHhaPYbvVliNsSi2Ey7dKSsxXMcKUy6jKmCeuxaSkHIGO/B+1jqFuZrG02tCVgWyKSp8AKSHHSDtI/2pH61DGng9c7m0nzVsIjgvPKQ4ryw0kfEc5BT0Ax71Sce3MlT97x1cX0079pbQd8ZQ3PmuWmYvhUeW2VpJ6fC4gKSsfofauD4t6nlX2zOwWGX/PuDZRbLU2gl9QPCpTyR+EAH4EngEgn4vw0/wBMXxpevbBc5oYjwY1xZecacBIabCwSSrkqAABzk9K+hbDMUuOTWG2SuSlJU+gDLqfy5UOowePnUr4ueLsV/u67mVXXwT8E3mJ37waijeWwyf8AQQ3B8RP/ALiu+McAHr1ParJUUhp26UmClxR0o6UjFFL0pKAKMDvR0o4oBaKKKYJRRUc678ZrDolS4jav2neQcfco6vwH+teCEfLr7USb+Fbh83C7wLUyp6bMYjtJBUVOrCRgDJqvPiL9p1FueVD0qwl5YBxMfRuaJ7EDuBUHam1PedT3GUu4OpYafUT92QtThBJyMAZKjwPSuBcICoSm2luJ85adxaWkJyM+mSUn54qk8f8A1Lru/wCNa53K43ebLuc6UuTLmL82RIUdwcUf5k9vQY6CnKza1aZ0TKkq4mXgpQgJ/K31wPTOCabUOPKeeDcJp1x1PJZSjcof2pw/uvqKVCCHITyWWdy0tLcSME9dqc5zx0qjBrqbS7jaE9clB4HzB7H+1Sx4Z+Neo9BtiArFzsrZwmI+shTA/oPVI/pOR8qYFosaLhKCZTj0ZpIVvdSkZ3jokA80+LVoKDNjOOIXLSoDDT7qkjPuAO3zyKM39E2fiy2nPHXSN9ZaVIluWt5wcJmowjPs4MpP6ipKacQ62hxtaVoWApKknIIPQg1QifAn6dUtpZ2heU72/wADw+XTPseRVo/ALWn706MRBeCUzbLtiKAOStvblCz6ZGR/xqXXGfYrz3vypXoxRRWFBR0oooBDSYzS4o+tIFooo6UwbHiBqz9yNJz72ltDr0cJSy24TtW4pQCQcc47/IVR1TLt1uMiQ68kJkurecJxyVEk+x5J9/nU7faX1WpyfbNPR3doij75IKTjC1AhsE9uNx54+IVX517zgtC8NLPJITwr3Kf8jiq8T5qHd247Em72eyx0xrW2uXcFA5O/A+hI5+QFNWO5Eui8yH3GpYVjDgI3n06cemOlEpxxpCPgS4ofn65+R7/I4PvWk681KcShwZC08Zzzj0zzkelbZSjoi0z4L0oSWENx3UJKC4U5UR6YOfofpTyBUgHIHH8p/wDqoTtd7uNrZW0matuFtwHhg7c9AAfzemMVvwdYz7Kg7ZjrsMjKUymvPKPksEE/UU9CTZl6toh3JYUwZcPc2UOYyXNuQkDqc5A469K11a1hptSHIgD09xJSI3QtrHB39NgSeucdKi2RfH3ktLjlp5xTrklx77sEr3L28IJyQAEjpjmtN2XLn5KJi1pOCtlf4V+6v5j7nJ96W0JHt+sYt6jGBfIrQ3fCXkctE+p7oPoafHgyHNGeJUaEmSh233xlcdJ3gq3JG9AVj5EA991QZFZU0EPblJdOQhHTIHBKvbPGO+DXQts1633BqZGP3eUytLjbjQ27VJ5BHp8qV+zDly6+hXWjpTc0Hqb98dJWu8qaLTkls+YjsFpJSrHtkHHtTjqC4ooooMGk+lBFFIF6VrzpjNuhyJklYRHjtqdcUeyUjJP6Cs9Q79ofU67bpNuxxXMS7sr4wDghhBBV+p2p/WnJtwrcmqz6uvj+pr/cb08Sl+a6p0JJwUpPCUg9wEgDHtTcYaBLrrn8Ntob1LWn4Ee+Pn2HJ9O9dBSVLS0hW3e6opSCOuOOc9Oc8+1Jd4qRi3BIUhrCgjdguqxkrSroeuAOw+Zroc5vywvzHW0q2MuA7StWRj3P+RWOIhQT5Dqid3xFpw5+qT617lluKgMvFa21Y3BScLaJ7kf5HNcsSkhe5xe5jolxPY54I9/0oI5C+qK0ltbMZ6KOpW3yrPXcoc59/akctqWENy2pAbhPAlLbuVLBBwpIA/Fg9+Bgj5VrxJhBCHSFBY4UOix6/wD7mvb8QBO5n4kHnZnkD2Pp/b5UsPWZuFHdAXElpB/kdQWx8weQPrgfKs33VqB/qZzCjIUopbZ3FCV46rWRzjsMfi55wOeUxKMVW7JU3nkngp+f/wA10H3xOSySvBZR5aTjgJySEn2yTjt6YoyhuOSvv62leSyz5SNiQ3nGMk85J7k9/wBKxZWhzIykp6jvj/NajaVofSGwd/dCeT9BW+W32lN+c0tlak5R5qCnI9Rn/qmS8XhPAftvhvpqPISUv/c0rUk9U7iVAfooV68TNYvaF0q5dYzMZ6SX2mG0SnChrK1clShyAEhR/StzQN/Gp9G2W68Bx+OnzQBgBxPwrH/kDUG/ag1yFhjRLcB9ZcS3OcfShSgognYkBPbI5J9h71CTa6Lc5b9o+1Vb1y/u93shQEnC3rdI84I/4rSkkfKpN0/4x6N1Nco9ut91UZknIaQ9HcaCyBnaFKG3PtnJ7VSnTUJVsjzJV1gKbfcGyOt9JGAR8RxnoOT/AG71v2y6pn3ODBQkssJfDiShWFfAPhUD2xxg+vPeqekqc7s/X0BpKj/wq1rN1VbpUO5tk3K27EuSEjCJCVA7V47K+E7h0zyOuBIGQKlfnxWXQBmqV+L+pnNX6+mvxlqcjMLEKEU85CTjI/3LKj+lWz8Rbg/ZdB6kuERe2TFgurbUeysYz/eqWaYaSLrOVzmEwt1rn820YJ9cZqnjifkv+ObNSh66Jh8rCFpYS4n82OFE/Xca4N2dU1KUh0YaW4pxvnKMKPT24x+ld2IyGrhLwVEsNOrSSec+WeT+tNye6fJS1hJRkpwR0x/1/wBVRJjVBclzGfMUpSVYB3nnGex7ivEyzLhZWyoKaX0I5BHoR3rZtqfu8xDaFHyz8QQTkJOM8V1XlkWx0HlO3of9xoM22EtlJS9htk9Mc5P9Pofc9PetnzhHUThflE5SSrp9cdffgH0rFMbEYt7fiC1FKkq5CgCRyPpSIBNxVGKipnyfM2nscgf5pkHlLDpcby4O6QMKA+XQ0RXcEOx15b7pHVPr9PY1kU0kXpcQcNtFO0jg10mITH7QQ4WwVlaUH+rPcjuRSB0aW1nFt22O/CYYaVwZEdHxf8s5J/WsWs5CJeoUeW4FpMZspWOUkHJBrn20EzYbhUSQ9tAP4Rg9dvStzV6iNRSAk7Upw2kDokBA4FM0p6I8Xo3hh4bCG44xOvMuQ65CgpWf4CeAoun8qdySQByoHtUW3HUF/v8AqeVKuMou3GVhbzoBQpBIwlsJBwAkHAHZVcO1EStQWpt1CFoCwvBTnO0EgH1GQK9QZshmJLlectUh1wkuKPKdxAOD2/Ef1+VZkkun7WwaplFLqoEYsqjsANrUjkKPBV07ZwM/0CuCy+A+ylxJSUqSUYPYEdD3FbISBLXH6oCsA9+nWtVIS44llaQptzOUnsR3HoabKyfgXq9aPE6banfgblNORk+iijC0H58OCrScd6oL4ZT5EfxPbcQs72pkZxJPqt5CVf2Uf1q/5aAJGTxUfJPq3jvx/9k=", "girl-2": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCACMAIwDASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAABgcEBQgDAAIB/8QAQxAAAQMCBAQEAwQHBgUFAAAAAQIDBAURAAYSIRMxQVEHImFxFDKBQpGhsQgVFiNSYsEkcoKi0fAmQ4Oy4TM0kqPD/8QAGgEAAgMBAQAAAAAAAAAAAAAAAwQBAgUABv/EAC0RAAICAQQBAgMJAQEAAAAAAAECABEDBBIhMUETUSJhcQUUIzKBobHB0ZHw/9oADAMBAAIRAxEAPwDZmPY9j2M+aE9j2PY9jp09j2PYE82+I+XsmLRHqEtTtTcF2qbDbL8t0dw2ncD+ZVk+uOnAXwIWY/LjvhCS/FjOWY3Hk0uNScrwkL0cWorTLlnbfyJUG0HfqV2OKacrNb8qKhfihWuK+VLPBMZlsJA6BKLbkgW588VLqOCY2mhzsL219ZpXHsZk/bjxCyS5xFZgj5hjNLSFxqqylC3AogWQ62AQd+oI9MPnJecoOdqP8dEQ4w80ssSoj1uLGeHNCrbdQQRsoEEc8WHIsQWbT5MJrIKhFj2OMqUzCjuyJDiW2GklS1q5AYXmcPGzLWUoKnH3nzKKwhtgsK1LNxew6bd7D8scBcASB3GTgfzVnjL+SmI79eqkeC1IUUtl1QGq3M+wuMJqd+lflkwJ7KIlRiVPh2jXZDqdStgeYG3O3I8sI6exTPGrxJzZT5tYqMefHpiIuX28whS9LqgOItwi3DJUbiw0gLHYAEGM+ZQuPE3JRcw0nMkP4yj1OHUYmrTxojyXEA9rg7HGC/0x5vB8bEsaULCqZDJSFlCxcr3B5H2OPjO3jczR5FMPh3RI2WcyQ2lQa1JpjieA6pPlKEabtuIBGpLh829hyJwsM51CRnF9usPfHVF1kpbVIkOLeUEg6rcZRuoi59LdsFxoVNwWRwwqO7w3b42WIYFyRTVEahv/AO6OD0rSQm/O3bAN4Vn/AIWjqCipCaO4sHqdMnVgwkuJ1jluOowk/wCYzST8gmgPCrxEi+JmT4tZYCGpSSWJkdJvwXk21D2IIUPQjBtjDH6Lmf0Ze8RP1O+8EQcwILCrmyfiEAqbUexI1J9bjGss6eKmW8kx2/i5qJVQkEpjU6GtLj76vQXslI6qUQB3wxkTa1CJ423j5w1JABJ2AFz6DC2zL45ZTy+JDcZybXZbBstiixlSglXYuDyA/wCLCXznnOt5vQ87X6nBhUNJuaY06pMRvsH3gQp9X8gsn064V9U8VKLQ2EopkR+W42qy2Gzw4ZHK6WgL9rHSPW+KAFvyi5ofdVxjdqG2/LzCvP8A+k14hZlDtNypl6RQo7xKPiiguSEe7qgG2z7XI74XEWg/qFtyo57zU8RJs8umQ5SiuSvn51p8zg9N/wC9ivn+KHiDXtSIEOTFhfZZgRyhX3m5tgBqWWq89xJkyn1USVEqW7JYUCok32Nt8NInHIAmbndFP4LE/pX9xs0v9IRqm19gRKQmLl0jhupAGtA6OBHJNuoubj1w64GaWqw1x3dCGpSUllp5rSHG+it9iTe+19rYxCptSXOE8kokp3KSRq/Dn+fpg0yhmmrj4ekF9cinoB0tKWdLSeZtba3pimTTq3Ij2g+03xfhPyPE0lVIrYqMZMd0xxGSqQprUS0FHZGpB/xWtY7XxDgeI0vKubKYuDVWaRHrYESqyXIwkmNwvMhfDJAJ85TqPNJuL2GAFGYkUxCQy24pNtS1SHNQChyIv0AHK9rDpgUkeJTrMya9GQFMy2Vx3lOtpUp3UpJJF9kmyEgG1wOVtscmKobXaoMhU+ZpXOHivAnS5ELMdci1Km0qnF0waI4ttFXma0hs6h5gkA6igKsCDcm2Mh1GuVCdVVuyNnH1eVh1SlhG9wE7bW5AG+JE2poltLblKUFKBKIzQK1pHYqOyPbc999sS6NB+CgPT5EN12MRYtMoPmHZSwSbe5AOCKoWYjMWlXUJ8t6QHUrQo2upCrJWhX8QIA/EAjvgfqFYkvSmnXlumW2NDUhRsooII03B5bkX9cGdSdYWhDy6M4yyBdIRuoDvpBFh74FVwv1uH3abTKjJTGQpbriG9QaSPtKCRsBtzvi4IlaPQletLtQKGm0qebUbNtI3Ugna1uvvz74NZWVqllukR2JU2KnjgSVR1rKuESPtcglW3I398Bcd56I58ZT5DrbwGlRB0rF+e45X7jBVliA/W5K4q6c5LfXqJOt3UkjmVBKunO4B9RiTIE+qXnBqmSY6oyXoy2ULbLsV1SkuA8kKbOxR3tvYmwvbGh6XW263TIc9sAoebuCleoGxIuD1G18ZSrFHcpUstOnhb/N8wAvzBGyh6jBNR/EfMeXKZHhNwY8iOQpxlS0kkJUom3Pbe5+uAZsW6iIzp82yw3UJZMuhoeEu70pxa9m7AEC/W6Dv63+hx907O7mX25KKTRacy9JvdxQLjnpbuB2xYUbKNGjPpFSnuzXVKsIkZJCT6E/MfoBgtzDJ/ZvL8p+nUIQVaQ20+WgkpUohIO+5O+L7V6PMt97yKdyUv0Ai7yxliu+IVaTHbcWhplVnVLTZtk9QE8tR6i3vfD/pHhLkzLccNykJkSrbqUSVX7ADfEXJMWHBy7BapzikoDYC1JVYuLO6yo87k3vgb8TM2SaM03T6fqaddSNam9lKudk7f73GOPsIA7mNnkyyzBlygRta6XVn6NJ+W/FTzPZJN9+2FdX/AAxzTLjzZ9TrqI9HjNlSpk0Fla7dm91b9L254NKBTaVl9pn9dOKk5gn6dCXBrRG1EFIHdRH2re225rc5ViNnfM5y7T5K1UqK8GVlLupHEsbkE8h0vyABPXAfUN0vU1U0CIm7Lyx4C35+cSSMrzJOV5lfeRpgRpTcVD9rF1Sr+b0tZIJ7qGC7LFGNEpkSdUEcVVQSVpdTsptHJN/U3CuxBG+CaXT052ntZbpKXUeH1BKVSpCN0rUB51J99yBva6ldhg0zAukVSkz31w2otNhwm2IztwHD5joGn7A0gkJVvbc2xY5T0ZfBoVBLqeh/0+SPl4ihqbqFwXuMq6Si6lcrD0+tvxwA2Lb6CpyyPsKG4v0v+ffBy43DkSlNypDkemagpZWAXFi10JHQKPO3QG6uxGZzDbHGejpVJZbVqdAR+7atuAD1+v8AXB1mVqTb/Sd2Zk74NMBhKm4aydYQNIkk/aWrmeewJt6XvicnL8lqnTqiSxHixU6VEIt5yPK3cc1H1N/TF/4O5cR4g5mTEluyVRmUcZ5MfdxLYICylsbqIBBsOhJ3tYvyTlSmZi8UHMrQ4yotFy5QG5VDgusqaS9IW5+8eUlQBUoEW1Edj0wHJm2mpOLDvFxD+Ghy/NrTULMwWhp4qaZW8+tLIfPyJeIN0oJ2vzFxe4Bxqbw6i0jPmUpUCipYokRha6fOpzbR+IiubhYve11C4CyDtcjflnTMvhXVBU8zSFz2ERac4otQpKiJLyHXh5QgDcanTc9FAW2IuxP0e6ZWqZ+2dbEpv4mmRJNLqcMqJU7KZSVMPJI23AKT1uCeuA56ZdwMZ05ZG2ERcZgpNJzl4pVhmmOIS0qQmKi6glKUJUWEAeyQhX19MRFP0WnxIklcpyFMWhtn4xoXQ09o5rSNyklK0EjdJbBHO2AGWuRSMwu8M+ZkpUhZ8qylaQsah2Uld/r3x3biiqtzGdZCHCtY3F1KF1j0vzGG1WgIg5JYkyllSZJqb8OYhPELukFA1IXqNri3e43HO98FURTiPiIrsCNJehvLjrU+4QoFJtb1HUHbY9xgTiynI7rB8rjd0pbWL6kgG/Ppjo5VpapUp4VbgGQ8p1SF7G5O98SRcgNU0Xl6o0yh01D5SW5VvPq0g/Tt92F/nzNUnMjq2mnSptKgSkLuQBy+uBJuap9Gl9alW2C7nY+oxEeBaWFIIBHJacSFkEwloGfKhQwUMuaFHmq/lV7g4Pck1CNVq8mq1Bxbyot3wFgFXE6E3I2Aufuwl3H0PqHFAQsm2sC4V74ZuWqFoyW5GfZZeStDj60Pq0Nosb3UvmlITbpimQCo7oFJy7vbmU2ac4FrNMyt01TjcJtHwdNlcMhDTirpLiriwCQpVj/d7YC28wNUahy4nE0SZbyohcSscRhlNitXqpw2BN7WSQMV2YXXJklQa4JYTsVsNFF036lW6k+9vpioaiOxmw83YBJuRa6Ljf8A89xjggqRl1TFifr+/f8Ak1D4ZPQavl0JahSolOZcCY7a0F9UhVrqdKUjSfNyJB5dLYHfE6dIMCOeC+4qsalBfwxS55T5UDudKUX7XV3OLHwj8SU1aMmjPzagiotp4iBIAlLeSBvoUAAAP4bEgb3OB7MLsqbm5MR6oLZjR3XoceTKBbSy1YlwkADc6gD6W5XwuAd5ubeTKp0i7Dd8f+/iLcU4oZnqkuEtw2viNTHmS5qUkEn0354+pVTckxG4aTwoltAbaPkbRcE27qJCSonsANsTMyUd2gVGUQ+JFNkAhLzZGoII2KkAnbuP9MUVPkpjfGt6Gi495Srnffe3Y7c+f34bHM83kQoxVhU1r4C+FbYZyNmSHIpKHaet+dJfjPKXKdQ+2Upiup+UBNgeffYEnDk8RsgSs0PUyuUGoJpmb6MVGFMWnU24hXzsOgbqbV+B3wMfo0yIM3wqpEhhhtqYzxIkpSBbiKbUbKUBtcpKd+ZxXL8ZarQKo+3NajzaM7LLUeYo8NxtRXpUy4APsKIAUN9JBINicZb72yGvE18OJfTHzqSpda8UKyhtlnI2WYVVbSU/rqTU0PsMmxBWhATrPsTbvjOFBzvWvA7NmacvTXGK3BmIU3NdiO2Q4pSDpcCyLocGs3SrnfpscaLcm1VNPq6qHBW7HltvSEKXLvwZAH/pcNQuBcdDa99gDhQteG9Mzp4P5anRoz0+Ww45PnpadS1KlPq2eGtSVAOAjYKBGwGC4gKIYcGUzo1jaTYiKr9Sp9SrzcqAy60wiEygsrQUqjOBGgoV3SVC6SNgFAdMcI0gwnmib2uVJP8AEL2++354sswwqY3NrKIkWTT2WVIXTaU4sSH2BcBbbhT8gIBVvyNttzgahPsyXEU95ZQlRshwkDQSdlAk2II2PQjtzDy9TKfuzOyWVRla9RJA8qxzv6j/AH/XFLJQXHlLDZurcm4UD7E4JpNGm0uU5FlcNxSDpCmVhd9trJ5kenTviEuG+wtSTFeSSb+VokH8PzxaUjKXkBSiVQKoy6/1acSEkntzwMToEqnyfhZjRZeJsATsfY4krupY4bq7H5XEj8x1+mPVebLqjEdmUQrgA2WPNqHLnzx3MmUimCzLSp1nioZcu4jdJ2O6VDsbWuMaYym/S8602Q9FkLkQZDCONDcShKUOC6ShQAO1kp/PGbalJU6hpfJ5DYSXk/xA2BuO6bXv1wyvCtU6jxVVBKXUpkuf2hEeyC62OR/vcyD15dcCyqWFjuaH2dqlw5KcfCZXZvyzVsmVBNSlU6nLoIWgSIcAKCGyd0E6vnFx1GnUNxsMV1JlRcvVuFU6tGjVDKtRWtUWWpouIjvEjUtSCd3U2spKt7WKbjbGi3KfTHnYVQQ2mUxKSYri3lFwLbc5X1X+1YW/mIwks25eV4fLqD8GI7Usg1BxKZcdW6WiD9lRuRY7JdHtfkcBRt3BmpqdOcR9RTx371/o9/bsRrsBpLyEU6S8/FfKVMzw6Ayypf2PKLG5NwBsL2JGwwD5+g06mh/jpTV5NSdtqdQAtqQkC6mgmwPlA1X2HMk7pwFUfNyshBpsOTal4d1N0oS8mwcYVzU2R9hQvuNtQF04Pq7EhzE0WUxNYcbfS460lq6kIjrSBwgon5CDz2IOrobYgIVMIdQufGRXPt/nuPYxMVR1yuuzuK8xFZgpIDAIC3DyCQB0I678xiBl3LcrMlajUynslcmUqylLuEoAtqWogfKBe+1+g3Iwa1GjP5wqkhMENyuHZr4kR0tNsgbALdFyvSBskXPK5wXZXqtF8H3kriVh12tLaKHFkJcDoJFgUG/lBG3qb3wwSdvw9zz+RVGSiePMbXhbQK14OpkxW4tWq2VpIS89LEXQpiRyJQ0CVqbKQne1wRj5zEchZjqFQfXV+FGnkGZBQ2txDqxyWUaCW3Bt5hY7b4GKV+k5OS07+vaY8X213bVFUlvy35LTuAR3Fxi8T+lDl9zyyolYaJ+1obUFfULwn6eS9xHM0Uz4goVWoSc34t5FyhTI8F7MSpkpAJsiK4XnlkklWkJABJJwqC/mfOVRq03wygVui5fqqj8fInFDEbXeynWid0G176STz5YZLn6SGRVrDzoliS0bpTJg3V6lKtxf6jC5z949Uery2UpbmzYa90tqIabYbG1rWI4ijclRSQgWCRe6hdQ3hZTLkRuS4/Tv+58zsrxmKbFyvlhUdEMzVPVfMLt0pWppF18ME6ltNg3JJsVKSOZwj0UJ+tOVJ5jS5BiXWpx1WlRF7J0DY61dEgfcBgtzh4rnMlLNHptIao0NdkuBEhb4eaSdSWtRtpRquogfMrc3tgbp+YIVGNPMyM8ULcUt0c/Jfkk91dTz07d8MY1IHMQzurEBepSR1LbdKEpVo0lDerY69Nrgna99+2+JSSamkPu1VsO/KoOuKSoEdDc/ltgkrtKaXlqlzEuxmnXEqfZbC9V0hwhQv7KBHcJxBhZeYqEJiQiQsBSbFKmgopIJFr23xcmBUXNu+Jfhb4XZxhuSKLXsu0KtfMl5iS2GHvRxsKt/iSAR64y1mjJtRys/w5bkGbHvZMqnTW5CD23Sbj2UBju/n6IyrSaQ6VDneZb/APPH03nyEvUpNEc22uZvI9j+72/LAk9ReKh2GJvMCZrGtClhJcFj50Cyh/eGGRlyt0xiiRUtckN2UQve4wMVrOEOqtpYeo7zKkbocEu62z3Hk3GBKUDK0lOlMjo8yLBf94D89jgosjkVAMADwbhtWPGAwP7JCiifS3XP7Qyt0ht033CVJ3B6mx3ti7R4+05+EiHVqHOMK1+EFtrS+n7KFnbyje+2+1+t1TRMuVPMNY/V9Pi/ETZQAUhlOwF/nUr5U+4vfD/geFGS/D+jLqWbHmps9tIUttxRLKVdAU7A/wBfXFWRYzj1ubGNqtxELRqTWa/DkQaLGdMWZI4zmkWYRpvpG/UA2uOgwd/s9CyzTWP2lqip3ASEIgx/K0gDklR5kDte2PjMfjKZQch0mGqHDb8qGwhLeoew+UenPCyn1d6qva5ayVX2F9k+2LVcW3H3hZW/EObPQIVI0w4ifKhtpIR5eyQOX1/DF1kHw4VmCZFlVSR8K3KUdL6/K++kAklsq5J5DVzJO1huVs3BlqSFtx3VJXyWhsm4vy5csOjIlSqNCoUyRV323+K0W2zJsrgC/K/awHtyGIewOIzo1Rsn4g4gxmCmsUepOxm0cNCNQSW9raVFN7etr/U4G5jSVJUVJsD/AMxA8pHqMTqzU1VOSX2ySynyNKV9oAnzH1JJ58sQ0z0mO2klTMplagsj7QPce9/vxYdQGUqXJXqVD0V5IAB1tKOny7225g9PY4jy6Y5S4TUiQf30pakxmUm9kg2WtQ7avKO5uegveofREqKX0JQ2Urv5dm3CAbKt0O4J6HtiKuQ45WFCahCY7TeocRXlFkEJCSL38x5DniYOUsVhLTEz92ph8tkaVAEHdPL6E4/ZjLjDWgLCk2Q2UkXbVdNxseR6fTEpiyVOBAUDcr4a+dhe9vp05YvJtCfYo7VdjNtvx2lfDymXBextsFDnZQGx7jvbHSYOwnJ01MWI2txJijhssqRewUoJIHcE2FjcYLIOUZr7SlNhTLaVqQAkkJVpNiRt3BH0wOymmgwl6IXF09ShdlavPHXztcbjfcEbG3Q7YZGWsw040hliXDS+9Gu1xLIuocwTcjzWIuRzNzzJwPISBxCYlVj8U7SMn0t1Nl5wp2pJ5/CvXA+7HJnJFOQQoZ1pYTaxHwz2/wCGHFlPKFDqNQq6XqTAWgVFxlIXHSrQDqSAOwBUk/TEinZXoAlyEOUOmlJKVhKoyLDlccv5lfcMLHOR5/iNjTAi6H7xITMnwAwUMZkp859SgluM2w6CpR9SLJAFyT2BxT0TKE3M9SMSkG8Vs6Xnlg6bA7qUrl9Dawt15u6LlelTc6Vh9qHFiwqcxHjIQw0lAUtTKFuKNh6p/wBk4o81eKdOywTRaHGQ4W76g2kNttr7hIHmV67nDCMSIpkADEAdSwXV8veC+XjEp4SupyBZThIDryyOQJ+Uep+gGM+5lzlPzlLLlVcdZdbUQ0ySUtoPt3/m645Zjq82svuSpim3ys3Nx5QOwvy+v34pUqLhQ26grQsaUFSSL26b8iBggFQU6hZ1hl5NnBsk9D6enty9sS4KYKZBXUVqLbf/ACQm5X6HsPr7YYvhj4eozAiS/PKlwIqTcG4cdukKCAeiLHc81chYc7bxDpvwTbsCn0qFCTGpipri2oyC+8NRCUJVbyABBJPM3AxQ5Be2GXEa3GBS/EFLbSQzTFLaR5QlblgkW/gSALel/rinqFdqNdbUp55CITakgNsjQ0gnkNPfbkeWJs+NS4mW6MunNIfqE1pL77q1XWVEqHDCeSQnSLjmSRjvEixodFkxFxwqpS3G3NKtw2Dv9VEBI9AVd8WFdzmZq23xKltxYS20uxKkEkE39jj6jlLxUpaUkot83Pb1xIfpUh9Ls5ltYhMrDKXiDZa7b2PXqr0GOcchLp7KPP8A39cSDBET5mQHWoXHB4odVYIJ8xFtzbrzBv6jFS1IkR2ENMlSlqClhsqGsJ5HSO+DiuobXQqe8gAhfHQeZ0KuhQV77/hgRrJbQpgaErQqylKIuobDSB3PU8jv1tiZE6OMuMfDyENAOtaboUTZYWm4Bv3BItidTau5TJinS3x6dOBaeaX8rqDzSey07Gx3uARcYt6AiJmajzYUpIRUEQHdLuqwWpo621C/8o0+4wFreKSUvXCXbaHkn5k9le3LESZaymlwKk6ht25SnglRAUHv4bjrcEE9cTFKlUV12JwKeshQUSQFDcAggm5sQQfriwhNfFCdI0JlT5YKG0pSLp3ASB3GlJJ7b3tbH7UqKGJzrs6jVWcZemS09EbK0lCkjY22BCtQt7YGWF0YVUNWJo/JTiFyas82op4lQccBvys60r/XFy+2E1JLoASJDRJHYnVYfS4wNZSSmnu1WOFlSGpzzYUrmbKSLn7sEkpaXY8NwAhXY87aGyPxOEGHM016idzJml6EMx07iNMVJctxRLi9BAACEEAjloSnCjboiH1LVJqkJpxzzBKXC44pXsm9z+ONd1CFEkh4TIMV8pWLcZpLliAodRyuRipokZiNX6mIrLALfwwSWW0oSfK7YgDlfY4ZTPQqoo+mtruZup3hpVKuQmM1NfadNuMpox2vYqXueY5JJ3wyqD4PQaDSxJmFuXJcbUsMBJ4CFC9ib7rI252HYYbTehxYspSkhRCL9fl3/wApx0loaXSG1ouUqSsAE8th/rirZmPEumnVYPeHjAL2ZVHTq4rICSPlu0gYv61lKDWf7W8HG5MNr90+0rStNwm4PRSSeaTcYoMiq01HMdybl5n8G0m+DGoS7J+by6lEhPUCwH9T9MCa7hlA2zP3izkCn5MkwahSoyGm5LK0aUghAkAgagN9N0qJsNrpwKyKeHqvTUSFiMmXDZUHVHUQXTbXpB7E2HoMMHxzzoKgtOVqdD+KcafS/IftqLJSkEhI9Aoaj0vbvhfVulSYzlLEt+NKhRCqMzOjuglaEjiBJTz8uu1zy2B5YbxklRcRyqAxqcsyVSS40xS3ZLHw8a5bZjJ0tt3FrnuSBb2A7460fIFSqcFuourbhxHtaY5dNuMUpUoqHZIKbXPUgC+J0KlxqVJak1VlCZS0/EK4oBBK06klIO1tzy/hHtgvqeZ8s02myYr770+YIoQhtlwIZYUtpOtN79VfNa9yN7cscWI4UTlQH4nMTQkF2IppQKCCFg+trH+mLDL1HNfM+E6GVS1pRwy+Da5NhboLmwvvzGJjMB3NFVebhxmmS8VOaQTw2kW3N7cht9TtiO5NhwoNPZgofRmFLzjDqdigC6h5h3F0kHpb2wRj4glHNnqVuX3P1HPnsyEq1xkOsKYcsqy+V0kHfcWxwmU40wSmHXGXksL0Ejko7Ai/uf8AKcUqUhEeEtxS+LMVxhI3IQCSkH3uCT39MXfxbSVMRgB8O4AtKjup25I1K9djsOQPXfFpSW+TahBp9WZbqjsxinvpKHFtL0nSf4trlHQ6TfnfrjQkBCXYjSm/kI8ujlbp+GM7v0xUSjRnChTzC7vRtKxdkhyyhv8AZIvy9MGdIpmZqnSoTseoMwmENJbQhxSipYHJRsdr/wBMLZVDcxvCxX4SI1qa/wAOTXwDZRqT49hcYvm3ddOja/lHCue2ptH+mBVi4qtfsTvUHh+KcXlNdU5S/Mb2EYf/AFf+MLmNqZbyJAWxINt1Db32xUUELFczDw0/vkOMpbF7DZLwH9MTJh0NIUnYgJ/LEbLPmrteUT5g6wb/AOF3HCcfEtVMhtpCEEeQEC3vb8cdm7PMcE2ASXLjtsLHH1UGksyQ0i4Skbd+h/rjmwn5l3OoB3f/AA4iTB3KVmK7mBkm4D7Qv/0wMFDqQ5VW45HkDZ9rlJJ/7hgZys2k5kzCkjb4lr/sGL119aKkux3BCb+hW2PyxYyF6i7zRkeZAkVWu05+OrjRHlutvgjyrAKxcDmFJ1A7c7HocLHxJodTpNVp7z76XXJKQ84WxpSFrUpJ0j6J3xoSuPrcyxUdVvNT3r/iMQMx0Cn5hRFizo4WhGtKVJJSoApFxft/oMXTJtIuCyYgwIEpswPwqp4eMLcQopkU3Uh4NgpZUkJKST08222M+UCEuTNREkNpZlOOJaDzgJS0CPmI9O3tgoivS5r7mX3p8o0ll1wJY1i3X07i/vhn1jJlLzJQ4smUhxuXHjEofYVoVtpsDtY8zz74Kp9Pj3gGHq/EPElUPJdPyhTSmyHeOyhL7z4CuIlS/MLckixH/wAcKnOWUHD4jOx4q2I8IqbiPyUNhLbK1pOkqtskqKRf137YrIGd63Xa7SMsypdoTUxEMPNJCHlNX06SobWsojl2xoSFlOjxKPVKSzCQmG+6tDoJJU76qUd77DFbKGzCUuQUB1M41nwsrdKfDcZlC32xdbKXgpagdgbG10mxt1G4wFpK2JLbEpBSEOhA1ckqCuX8pB6HGtE5Zp9IlKhx21FDjoStazdarjv6X27Yz34jR007PcppokpL2lWvcrss7nudueC48hbgwOXEFFiFuVaA1VoVJEt591pDbi+CSAnZ0iw2uL9ffDKkpQw3EbbSEpSykWAFuZ+7ATktsMsUtKLhIjSNv+qcHclIWljULkN2/wAxwu5sxnGAFuf/2Q==", "girl-3": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCACMAIwDASIAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAABgQFBwgBAgMJAP/EAEIQAAEDAgQEAwQHBQcEAwAAAAECAwQFEQAGEiEHMUFREyJhCBRxgRUjMkJSYpEWM3KhsRckgoPB0fFDU5LhJWPw/8QAGgEAAgMBAQAAAAAAAAAAAAAAAwQBAgUABv/EADERAAEEAAQEAwcFAQEAAAAAAAEAAgMRBBIhMQUTQXEiYbEyQlGBkdHwFCOhweEVM//aAAwDAQACEQMRAD8AYfC2Ava423x9oWFAayD0N8bHTfytuAD8RAIOMFetOkp376ueMxe+XB0vJSPrFlI+6FHbHJt9QVchVztY3N8KFgkEKJvbY9x+uGn32TNqApGX4T9UrBSXFN3ShmMgfacdcJ0oQOpJGJAJ2VJZWRNzPNBK5c1qKyt991LLKB5lrVZI+JOElEjZn4gPOMZMoE2qtpNlzXbx4af85Wx+A3xInBDhPlnPtSqFVzDK/a9umOBvxUJLdIRI5lplBsqRpFiparIuQAFc8H3Hvj7C4OUhqi5fixX8wrSEMsKTpjQk2vdQGxVYghsW2IJsCAbhuuUalY0/E3OFx6D49ft6qBM6ZLPDXwf29zipqZLb1NUfL8dCnlDv4zqk2T+bTbtfAEMy8Om1X/YmqVlwc/pavOrWT30tJQn9L/HAbOzHMzNVJNSrs5yVVag74r0qUQoXP4bDaw2A5AcgMJ3UNRJa2oz6nGB98iylHr8RhpsYG6xpcTJIbcb76o5/bylsE/Q3DLKS0LUNKVNynXLnax+vJJ6bYxJ4lUGUYwk8L8vgJGh33eZMYXrBOqxDpAty0kHlhjy1EZqWbKCy82kh2W0hSmyQHAVDZVv67HucDWhwPzLlplKl6jcBIUbm1rbX+G2LZQg5ipUp2cMkPrUgQs3ZbUoCy4U9uoMj/LcCFfoo4NoGWs11WN73lqfFzhE0Fz3dKVwZ+juGXLJct1KFKxBTFKhyaa48uc0zMCv3Kt0ubdR0PqMEPD7iNWuHVVbcp7yH4fiBbtPkqJYePcHm2vstNlDuRtijowdkzDjJYjo4j8+GyP4eZI6p7lNlNyIFVQfrIM5tTTyD8Fbn5Yc1uqBuNV/niwpjZQ9pHIrU5MOPNksp8JceoeV+I7a+gvI87Z7OJukjcpVuMVhVDnUM1Q0aVMrVMo61oqVKloT9MUbQbKK0jZ9oEfvEXFtyE4VyXstuDig0E3XqEqkLcVa7hA6cxvjq0yNAIJVfuMJIVYaqsZqVDkB+O55krTy/59MOCXFaU3Iv8SMUWuCCLC08Mp5BWk8/98bHxRyKyO4/5xgqNxugfE41SpVvK9HA7KBNscpS5Rc5pSjGpLihshP6n/bGmpsbpCyOowlEeVmGsxsv0tYYkvtqflTHP3cGKn7by/gNgBuSQBuRiQLKFNK2Jhe5NUifKrs9+k0lbCHY41SJWxS2L20jl5sKplBnqy5+zcOsMU+mFRckx48UWmrPJT6rlTgHRJOkdBffC6oSI8KuMRMs0aSaXEiJYskJS+4kLUQ+4q41OKUVEp5AEAcsdnaTDrSVmZTJDbyQErU+C24driykq3G/fbEl5afDsgR4ZuJbc7bd8LIA8hX8+aJeHGes15WykxQqG/SKZAgOOsNt/RxeUVhXncUtSxqKlEncbbDpiMeKmVp1aYm5gqlUfnyWGAG0JjpbTfVudiTdSlFSibkk/AY3pspuJnyLQ2o8RCabGeCnmr+LICglSVOi9lKAVp1W30g8734Z+a+ms/5Yi6igKQguMpWQHEpcKibcuSe2LAuD7vzSpgw5w5/b8QOXc77X/KU/2D02FTm3pFalBboSnwS2g+a1yki3Tf8ATDIOH8dnOcrLjkiQuK3GTJbWpKfEIKU2+VyR8sTNUEyKlVcvENlDDLrzsve19TWlNufIn0wPZopjcPiHS6ihJtKprzaxz3QtP+iv5Yq2d/U9EzNwzD+HKyqcPmPw/wAIZpfDduiViPMp9XkNz4ikSWkvNIWBudJUnqLgj5YBoXDyrSM1VGlJcbQ1G0uuyNF29C906B+I7jT0scTQksOT5ElDaly0MIZUlNk2TdSk+m9zvhBlaWuXWK+ia14D7chsKaS4FWR4Y0XNt77/AKnHNneLNqJeF4VzmNy1qdr1FHT81QdJ4QwXW1MRqopEphICgoJISTyJSNxfDNljhy9UH6jHqC/Afp8gMKQjSpKrp1ahcg2IP/GDaFRPEzFmd7/5GLKflFaH2dSELYIGix5Eg6tsOWU4z8KtVdL7kiXoeZ861EqUkt7A4nnPAItVbw7Dve0mOhZG/f8AnRIuGTNYyTIdrtAzI7T1PJcbfjuspeaLaFH7YVzA03B5jvhFnGm1uXm+HnWLVks1hU1tTk6BH93cb8RenWNJIP2gN+Yte++HvL8VD+Wnw8rwmNEoOOatJSguLCt+4BxzzNNVS4VJiRoa3mnpcZh13y6WUBxNhz1E3SOlrHFeY7Purnh+G5IJZ0B67prn5OzDLzHNqdGaizJr0dyfJpsaOmMJIbU2lXhNpNvFOvVZNr2Nhc2x1otSjVSntzIriFMu9ibpPUEdCO2H2uiQzDcditTfFXCmNMvQUkutSSELYNxYps60nzdMC0p52q0l/PjMUxZ7Doj5qpzaQgB2+kTkJGwClEBwDYKN+StrN8bbO6A55weIMYH7eny2/vdPpTq/H8hjktBCrLS5q9Lb4TtuBaEqSNSVgEEWIIPzxnzdG3COhCMUWmlEya1BiPS1izLSSpVyo4do0VzK2WkQn1kVyu6KhVVfeabPmjxvQJSQ4odSpP4cNtJpjFezZSoEpJepUQLqdS8lgphlOrRv1UoBP+IY7V6qPSHKhWqglzW8pch5R2Gom9h+oA+WLbCvikjUs5J9lnr/AIEE5mzJIoNXbchKStx1lKXEOpulQ1KKbG+x59cSTwbyxUOLlNrU9VRiUpilOJbcS3FLzi9SCvy6lAJO1vMDiAqrIkVRyTPWd1kAptyHRNuoAxYH2S8yRoOXeKEOU+ppDMNudcXUpKAhxBKRzvcpsO5GDviAZdarFdxKYzERuIaVBNcrDmTM91Z+K0iVIivOxS88SvxADpUo2Avcpvta3K22EKOIE+o5np9UEOIqoRmyzHbQCpJ1EgKG9yd//WBmQ7JU48l0FTzhJu6d9RN7k/i9epxN/s8cN6VVkSM4ZvnMU/LNIf0F6cAhLj1r6Ek8zyJFj8Dgr2taLISceKn9hrtLv5/FSjkDg9m3iLCj5grlSbo8tnT7k1GaUpjZYJLqdf1hIBFgbC/M8gdzPZ6zBUJjcp/NlJLrYUlOmkuAaVAXH7/lsMH2W+NnDivvt0+lZqpoeFkNsvFUfV2CfECQfliRO3qLj1wk671FJ9mKl1IeTarvG9mWdHdlThm1kVV4oRrTT1eAWUpICVILl9QUbhQI2JFj03gezEtEupVCXmpSKo+htEd6DEKG0Wvq8Rta1BwKGkc0kaRY4sLj7FbXGeU+8d7+ar0z7PmZVPBEjNdJRHB3WxTnS5b0SpzSD8ziCeKWWcx8FaxLWgpq9LqDyVmc+hWpDgFtCgkgAaQCP5csX7wHcRuHdN4jZflUyYjS8tBDb6RcoPQnvY74swgHUaKX4rEOpwebGy874+f5zVDegsxYWl9t1pesquoLJJIN7bajYHtjjJ4n1JESJGfhxnlsLbWp9zUlSlIUFJ1WPW1ieRw05tyzOyZmSpUOelTM6E6WloVsF9iO4I3Hx64GXVvOgt7nTvYc7eh7+mHeUw60kf8AoYkaZztSthwvp9a4xZVmVCHLoEKVFdWHoj6Hy4dKQdV0nSQb/LrgA4W5jVHVLqy4SD48l1MmCVam32XEgONEnmlQJ+Gx6YLPY/za9TYeeqc7KK4bFNcnaCpKQ2pCFXOm172AFwbWsCL2xFPDVxxDU2Kq5XpbeFjt1B/oMLujDc1eS0sHjJMRK1kxsEFGLsBOVMwzcua1v03w0T6PKtYvwXN0X/Og3Qr1Scdwb72WP4RsfXnhVmNRm5FTU0oJm5QlCRsfMYEhQQ8n4IdKF/5isIQ86ANLiwk7j4YG7XxLUwpLc0Lt2+nT7Imy2t36JzhVllfizJcejs2OkhtsF523zDQ2wFZ1kKVGVHbGyRqV5ySVEEj9ACfiU4L6Q4U8NsrlYQTMkVCesqNubyWgf0aOIvzhPc1x0pCUqfQXyUi9tahYf+KEjBGi30knShmEdIfeJP1KGg6HGW2V6QCSoDv8+nI4OOC1dcy7xAitB1xLVYbNOdQLBYDhGg36pCwg3G4AwBtuh94+KAlw7ahyItbDRMcciutR3lEeGq7ar7b9j06YbIsELzYNEFb1iOmPOkQVKS6PeVstqaudKtZCRY72PQ9et8XkzNk/hVw/oGV4OfErktUiE2zFhOqWiMl0gF1/QkgKWtV9SiTbYbAi9UKllyNHrPDqqQkOrgT24AmPOuAhcoPHxUj+GwBHS4PUE3v4+cJf7XMnvU2IqIzV47vixX5KVaQfvIJSdgobb3wCV2rdUeJuhNKvNfR7OucI6mYfvdBmOJUpLkFC1N3BA3QrUgje+1tu2ElJb4r8Iy6rJOZ4mb8sRbqXGZdEgNIGxuws62wBb7JsLi1+WI0ncE6vlODUqXmXLlUTVJDjaaTMiPIWyFBV1hSSQSFJIsocjzB3tIXC/gzm+kT2qpR1uN5kiykusIfcCIrjKb+IhzSk7lWwBsNr9QccaA3vuoFk7V2VpeD3FB3ifQ5UqXRX6TPhOpafZcuUKKgSFIJANrDr1wV5uzZS8kZfm1ysvlmBETqUUjUpR6JSOpPIYbcvUpVKqIkte8MtVEKL8FxetEZ3SFEIPbUFDbbfbthv4r0J3N9Eh5YbcLLdXkhEh3Tq0MIBWsgciqwAAO1z6WwroXeSa1DfNV/d9p/iFxGmrpnDXJaUuqB+ufSZLiPU/ZbRb818dJXBnjxnWO45m7iGzTWnBf3NEpem3M3SyEoFgD1PLDtm/IvFec0zScnSqflXJzKAliNT9YcWm+xdWlOpS9gSU2FzzPPEKZs4UcaHx7zOaq9Q0NXK2X1q2FhYpJBJ+ROx7YYbl92gl3ZvesoQ4u5PrOT6+xBqeYxmNKGQ21NRrWUITcBCtRJ8vTfYYjiapu4bdcQCn7Dw+ySOh7fA/wAsSQeGGY4FCr9TzDCrVNl0htC2WH2FJS4pagCfEJsAEkHa9+WIyksuqcdLi9Ws3UTtfruOnxwww6Ul3DVGuQ85Ky7RM8pDjbL9VpaIjeo2JWtwJIHdOlSie22HDIJXqLy21J8QuNbjkUhB/wBcR25TnG4CXQ2hyIHdNzbyqKb225bfLbEj5FWh6BDYNwtkPqsfUoA//emBzaNPmtHhQzTi+g/sKWckttTcwtUqUCIVbadpMgKtYpfQUA/JZQr5YBctGQqjssyWh71EKorw7LbUUkfyw8Q5hhvNyUqWlyMtLl+xSdQI37jCHPjwy7xGzpEZaWlhyquymwgXGl4JdFv/ADws0WCAt6V7YcQ17tiCPpqEX6FL4dZGZQPM7Tn0A25Ey3r9e2Inrcr3+uy1W+qijw0gCw0pGkD5q/riVHZQj8L8vvpVdynu1GDr0/YIdS4PnZ3bEPvMlMZwG2tditSdwtX/AK3J9Tg8bfESsXFygYWOLr9kxrjrJVboPMoCxT6Ef64bX9a4qEvJBb5BzmB8+nz/AJYdXFOoSoFWqw+rdB3Qe1+3ocJKkFOJuQEpto8RItruBe4G2GFkIl4fUt7NL/0HHCET6bFl1KDc/WPutpS4lkAmyr+Gq3WxO+wx6d0CsM5hoVLq8ZQUxUIrUpB9FoCv9ceRzSVU5bMliS42tCgW3GlEFtQ3BBG6fiNsXN4Mcb3qVwYjU9DaZdXp6lQ4iwLoCAbha/gCNuu3S+FsS3TMncEx0r+WwalWr8aHLkuxCpl1+MELcbICi3qvpJ7E2NsKG0JaQENoShA5JSLD9BiNOBzMl3KkyqznXHptUnOOuOuG6l6bJBPzCsSb8OeFAnJo+XIWXdLGOLzbPjtPOaQ42FBBV0va9vlhllZvoMCvxaXIrkJNRmt/UQvHT4igCbrCb3IuLX/KcC2f88ZPRUomV6pmGJBqL395u65pS22Adyq4sT058t9sSAUIkBSV19cfYSUyY1UadDmMvJfZksodQ6gWS4FJBCh6G98K8QpUWe0M9Ej8KcxvVBJXEairCGwq3iPrBbbHyKyr4gY80W9XhpBWVlI5Ocx0Iv1xcT2us7JqzzGUWHVojU5s1GaQLpJ+y0k/FR27DftitHEOrUCpu0KDQm5TVNpdPTFD8uxW8vUVLWQnZHmUQBzsLk4dgBDe6SnILuyHENa2RGQg6lq8QEbbBJuLdxv+uDfh/FKI8laGiFlSCgkdLHcDpvfALEWlCUpUSUISTrvdNykiwPMXtyxJ2QIi3ab4i21NqSpKbE3Gyb8/8VsdOfDS0OEMHNDu/wCeqI/d3y08VeYKSb7C17YDuPC3EcU6xoUkFUeCpY12Oow2L3xIvu+pOlGkqUNIF9zfAvxNpKq9xQzo62hKm4lQEFJI/wCyy02f5pOAwmiSVo8TY6TIxu+qfp7fvWUM500XCqbUItaQhKtvCdBYdIPUBRaOIzYadlvoYQkLdUSlCdQSQroLnEtMyYsDMVPkVJ21IqbblFqS7/u2JA0hw/wL0r9NOIhq9Km0OrVClTkhM2nvriuDlZaCQb9uVweRBBGGInW3RY2Pi5WIIdt/R1SqflmqMga6bKWejjbfm+dsD9Qp9RixkqVFfCEbaS0obXvci1xviS8pZtcn6KXUJBRLAsy44P3w7G3M+vX44TVzNVcy7MMeSiM63zZkeGUJWPWx2OB82TNlIFp12AwZhE7ZHZT5XR86pRplfKc3NE/Q3rYgpVqeeOxR6Acio9vniVqRWYLdUVRKVHQ3TYLGtbwPlUq9rA9epKupwFZh4m1SXAXCTDbiKd8q3mnVFSkkck35X7/LCXJeZYeX1ykymH1vSggDw7C4F+h73xEjHvaS4dgiYLE4XCytjidYPtOIrsAPVemXD+m/Q+SaDEVstERC19PMsaz/ADVgkxSzLfF/Nr8YLbrVbjNIACEzQgXHSwN9vjg6TxE4o/QMmqRIlSqENtNvEZpyFrN9rp2F7dxcDCnWkebh76MxeKOvUf0pMzbw34bzZNQfqNGpqKzNV4vvDai1ID33XELSbtruQdQtc874DaJwP4UUVxUiuOPV2oBw3l12QVq02CUoIFk6RfkfnitFAiZ5z3WatKiUHNNeiJ+pmtfSfu7viA6k+IoJHIjZNvgdscs7ZRzm1TYEuoZIrdNWUoZcqEqqOylyFGyUhKSbJ6+UA7E35Xw0GHbMsR7gDoL/ADsvReN4PuzPu3h+7BADXhW0aQLDTba1h0wnqL0tthaYTbRfKTZ182ab/MoDzKt+Ec+454r97K+S84Zbg1J+uy1M0kp8GNTVO69Ll7qc03s3t05m9/jPGZcwwcq0KfWKk+liFCaLri1dAP6n0wBzadQ1RWuttnRUl9p1mLlaOzT2y9IqtVfVNnyXbeIpsGyVLtskrXuE8kpaSkciTWRBdYUgqF0LQSnfY39O3wxInETNs3POa6hmB5RYkSlWbbKtSA0NkI7XCefQknbAUyp1ctqL4YQlTgNgLaAOZt2tfbGgxuVtFIPdmdYWzRTCpzjBa0uSiklKhcCyjf1BsP54nbL8RMGkx2krQtZGta0C4K1bm3pv+gxCjK0IqjjSFJSnxFoCHTYJCjY2J5bX/W+JmolQjPtOMtLUlTNrsrSErbSehHpyvyIsRhedb3BiDZO+3qUZZQjNys0Uv3lRENh33qQSNg0yC6u/+FBwF5clmfDk1WS46iRV5b9QcDdikl1wqvc+hGH6syvorIVWdbsJ+YnBQIXmsdK7LkuD+FsJTf8A+zCFmO1EYajt+GpppCUIOo8gLDAdm91pMOfElw2aK+Z1XWpQ2qpBkRXGkhDyChW+49f1wNZ5hyq9l+Fmiwdq8At0euoRzUtKbR5J9HG06DfbW3+YYLddzfypPZOkf0wiVKTRaiqqe6Km06QwqFVoF7e+RFWuB2WggKSropIPTF4n5TSW4phedHnbuPT/AD7qM6NRnMwSRHZKPCG61rNvC9fj2t1w/ZyqS5cRug0tlM91kp1uC6zcdAbW1dzt2wX1uPRciRIzUaQZVMns+9Q5baVFUxkm2sgclA+VQ+6QR2wASc/qZQpilwmoaFg6XCAs/wAQTyP88Wt8j7DdtkFjMNhcNkMur/arU18AOncoAmRJlHqC4clkNSDZSWXiCg33FjyxItEei5SyPGrBp8cVGQshPjpsq6lEAX6WA6WwrnMR+IeWC637umrxBYpOwUr8Nj91VtuxxKPCPICM153yjT3oyHKTl5AqUsKGpJU2EpZQenmcN7dkKxz5MwDXb9VEOE/S8zExG25fCfMmvqEF8HeL7GUuIQZz/So/0e8EtF2RF3pyiQUu6SLgbjVe+xBHLf0BebYq1OW2l1LkaUzZLjatSVIUnYpI5ixuLc8Ud4h5AY4a8dW5ea0eNkPM0qSTUXiVJbbfQrWy4bGxQtQIP4dJHI2e8o8UKv7M+ZxkvMrj9Z4fPAP0ue19Y7GYWbpUi322x95A5HdOxsYfGHAFiy/1EjnEzOJ7oj/a6iZKzLKpXEKOimZojXQzVAXGo85rfQ4FotzFgQb2tzG4DPmzjBT6y9CoHDtC63m6SlEZmUwFPpa1J82lxW9x35Dck2BxaSFIyvxKoUebG+isw0d3ztrLaJDYv6EHSe4IB742jUXK+Q4UqdHp1HoMNKSX5DbDcZOn8ygB+mKBw6jVdkPQ6JDw2yq9kXJFNpU+YJU9pCnpspSrhx5RKlqueg5A9kjlio3tD8ZTxIqMihUJS3cq0hQU++3cCS5q0hdx9wE2T3O/bDxxj491HilUU5F4fokmny3PAckISUu1A/hSDuhrqSbEgb2HPrmzh5SOF3DbLtKqH1zlYrUb6Ulsq0KdCQrUlBtshAOx73Nt8FY3KcztyhvdmGVuwVXXmVIKkhSnW1C5TbzH4dD8RhCzLWlDjbLWt9flS0q2pKBsdN+ZOJb4wcJKhw5qKAtapNHlqUYVQSiwURzQtI+y4nrbmNxtyiaUpYcbUtKFJQbhVgpWroQetufQ/HDQIcLCVIINFbTC1MnPNsJKZGspSk7hVuovzvblgxypErVXqVGpEVrxZc90MwCom6V33T4o3CbXJCuQBO1jgIjSf72p54FK2z4oNtyL8xfp37YmSm06XkqiOU1Klt5vzVHKlEXCqNTFjcq/C++k2A5pb9V4pJVapjDOkbIOXuU7VapRswZlbXT3vHy9lxpVLprytveXL3kSv8xd7flCR0x2C1fdLdvV2xxwisNwIjMWMyEsMoDaUlROwxsG3Fi+jV63thFxsr1+Hi5TMp1O57p2MZzl7uscrF1y2MFoAXvHT0tqvj6yL3X4RVzuq5vjOtST5VoSPytjEIyZbU2BCfoldLjuUJb3jhxganqNJO3vDXUoOwW3yUOxAOIyzplx/J9RVHqbaFJkth6nyYa/EjS2T9l5pX3wf1B2NjcYmCSQpBQt9ZSRYg2A5dcMaYzdNpb1ImwRXMovuF5VM16HoTh5vRHbHw1907pVyUOoYjlrQrB4hw06yQj5IO4XZUr1az7T6XRHGXXnEqclOKUSyhofaCiOfMAAb6iAMXb4NU+bleiVQTIHhTHZqm1JWCkkNgJsDyO5VijuZMhSqBAVXsrzXq7ltkgvSowKJdOvuBIaB1NEfi3QeaVYOuEvtd5iykpqnZtL+Zcr7I8V3zTYqeQIUf3gH4V79lYmWLOczVnw4x0cRw7tibV6M0ZWpPETLMui1yEXIMpPcFSFfdcbUOShe4PyIsSMeffFfLeY+FjjmRq2v3+jsqMqjSVp+wgmxUyo8knktomwO4ttf0JydX6RmmhRqzl+pNz6LNT4jDiDfSfvJN9wQeaTuDfA7xj4WweLGTJNIfQ2ipM3ep8lX/RftYXP4VfZV6G/MDAo35DR2USMzixuvNWkVSpUpwyaNUJdPlL+2Yj62iv5pI3w6MOZq4jViFSxJq1bqS1aWWXn1vEepClEADnq2A74402c5kivuNVais1GPHcLE2lzkkKQUKspOoeZKkm9lJPruDbF3+C9a4Z1KntjIqKdBmTQnx4jirS0q/CvUSpQH5SRhp78oukqxmY1a68EOB8Th9ED8tTcvMchu0qYkXSwg7+E0T0PVXNVr8gBgL9sNiXUVZWpNOYU57rGl1F1Df3GkaEFXwGo4tPGjIitBtF+5J5qPc4j+vUJUriixU3Y/jRG6A5FtYEAqkalgg9CgfDCjZDnzFNujGTKFBnCDP0LjXHqHDrODBUqZTgtCxsoPseXxWz91ZQUq/ibV0VbEV1/2Us2peqMKjTI1SqEMlfujv1CpbVyA6yo+RY6KSSlSFAggixLTwomzYXFigzaNCelPxJ3ilqOkq/upUUrJPIJDajckgC3PFjuJntDxotQm0Lh6lir1XxD4lXcSDCpq7WKkn/qrPYeXvq5YO7Mx3g2QY284AEWVWvLeUP7MxGnZpp3i5rX56TleYAosqCre+Sh91oEXQ2d1kAnyjd5p0Z5K5kudOM2qzni/LmPXLjzp3Kie3bGYVPVGkypkuY7UazNWXZk+UdTr6zzJPQdgNuWO7hLJB1I0K7G22AySFy9FgMAMOM7/a9Fsojc+TsRbHE2SeY/wnbGxv8AaOnbY2PPGutSdkrsOxOBrST+lajYAoTttpb54wpLqtyp5QPW1sLCjSgedR2vzt/TDet0qKgQD8STjly4uoUg73sN7KF8cW3LulaWkFNvveUJPfbHSUAGSbAkY0eTpWhIICVpFwEj/bHLkgegqZqrdXpc92jVxgWROp6ihwj8KxyWn0Ve4wy1eBRK2pS80Zddh1DrX8ptpa8T8z0FVmye5bKL4fnARp8yj0545vI8NBWkkKG4OLtkLUliOHwz6kUfJPHAus1ThrmNTmVM0UTNGW5iwJ9G94+j5o6BxEeRpAdT+VSgobdiL4x1iVHbfbSotuJCgSnoR19ceclRpkKeG1S4rT6lDcuJuf1xrSqIaMC7R6rWaUb30wag60kH+EG2JcQ82s53DJIh4SCPp91JHtkcLHadXIefKTG1x6mpMWpNIG4fA+rdHYqSCk+qR3xBPDaZmOg15uZSctSqzHWQmVSnIDrjUlHpZJKFjmFpIKTyPMGSI2Zs5pkJQOIGbfCJ+waiSB+ovh1dcrdUZUahnDNEtAH7p2qOhBBHIhJGDNflbRSP6J73+EgK29DzzRKVlKDUa5VXKOw43qTHzC4GJjA/7bgUdSyOQVYlQsd+eI0zr7TeUnY86m5bp9TzDJlMqjrkxUmMwlKgR++UL9T9lPrfFeGsrUaM+XhT2nJHV5+7qz8SonDi8hCHGEpQkJJG1th8sL+ELUj4Y8/+jq7f79k3K+kqnTTS1phUbLiudHpAU009bl4zpJceP8Sj6WwpaQxGjpZYSwy03sG2W9h+mOjyT4jqNWyTcWSBb9BhMsfWEFSjcdTjnOLt1owYaOAVGFlZB8xdXt002vhOlxpaygJJC/s379sZeBZKShRFzY2xzcJQtSQpVufPFUddWwUhWps+Q2J7jGpSpBIS0VJ6HGWtklW5J53JxnxD2H6nHLl//9k=", "girl-4": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wAARCACMAIwDASIAAhEBAxEB/8QAHAAAAAcBAQAAAAAAAAAAAAAAAAIDBAUGBwEI/8QAPxAAAgEDAgQDBQUFBwQDAAAAAQIDBAURACEGEjFBE1FhBxQicYEVMkKRsQhSYqHBFiNygtHw8RckY+EzU5L/xAAZAQACAwEAAAAAAAAAAAAAAAACBAABAwX/xAAiEQACAgIDAQACAwAAAAAAAAAAAQIRAyESMUEEIqEyUYH/2gAMAwEAAhEDEQA/APRqoqgKowo7aMemgdc665B2ADQzj567nXNhvqEAB3Osu9sNFV3C3TClVv8AtYVmLDt8RyT8go1qJ3Hrql8d1U1FZKyqemUSCB4ucPscg9O/01a0ymeLrhQUUt3jpaW5SbARNSy07eJzL1KyZ6Hz16h9mtlThqwrcLi0dLCyggueUBSepz+Q1j134Crai62yS2ACKSNJJohIOZXJ+GTPLkg43B2zpL2ie1XjSz3WOy10FvgEEaurinBZsjHMMkjsRtg7dtbTTzJRgwIVgk5TRaLLZaTio3C/3UfaNbWVtQyvMzFVhWRljVADsoUDS18snC1ltc9fW0EMMNOuWYB2PoAM7knA0w9ml5p4eG0WsqcTySvOTyELlsZxjpv+urDfZrPe7XU0NVJDLHKhBVg2CcfCdt9jg7b7ba3SrQo3y2ZHxDcKSqpLXUcL2A1lNOXjnPgyOyyAjEZAPwnBBz3ztrTbXU1Mnsp4ioq2dpPs24eDTq7czQqVUhM98MxxrOrxwpXpabHSWK5w0T0gZqxYHljR5mIJlGd22GN/LSFfxfT2Wsudsqaeo8auqoZ5aiOQDxYwyllKnbJ5Mg9iTqskOSSQWHJwk2/6PaHDayLYqHxfvmJWOduoH/OpTVf4L4jt/FnDlFdLT4ooJQURZ05XUoeUgj0I+WrBpPrTHE01aBoddDIxvoA51RAa6NFzoZ1CBtc/XXTrmcfPVkAPLXcjXBodOmqLO/rqqceWx7nbYYUAb4myp6N8PQ6tY0lUIGUEgHlzsRsRjfU6IYnYKeNRSVcq0yuD4D5fllRkZVAI7jP8iD30x9sHs6m46tlJW0MSNeqHK+G+wmjJ3Xm7EHcH56ae0iiqqG/tUQUdVKzctTG8SkBuVUYknuAUI9Meo1sdE8VWkFTEQ0c4WRceTYP9dDyeNqSN1xyxcJHl7g000dBRR3J5IqVeaKSWLBMTAlcnOQQCMHV+q/Z9cmpRV2WanvEBXmMcJCzAeYGSG+h1ntBNEHrwWXatqR1AxiZ9SNnvVTY673i11Zikzlog3Mj/ADXP8xg6fmpv8oM5mN41cci/07KtRG7RyQ+HIhwySAqynyIIyNUJ+E7txxx01uoKInMixPM6kwx/CWbLeYG/L39NeiYJ6D2q2Z5J2924hplK8zbmJv3X7lD1B8jkdxqB9ktFdLNx3X2ysp5I2M0pKuMgRtEuXVuhB5FAYeo741mvo09U0aS+apLdxfpuPCNhoOGOGrZabZGUo6aFVTmOWYncsT5kkk/PUzjPXQRBGioowFGBox0v2brWgh9ToaB/novfbUIG0NtDbSLMWPwqSPPUJY5/XQxjQG2hqEBjJ1zvrp1wahDo0Sb7hC/e7ep0fXOUE7jOqLK/ePeauge30cQdeURzPzbAnA5R5nWW8PXKu4c4YtSTf31taHkDsGbwGVip5sfEY9s7br6jppvEF9ey0wpKCNJLq6NOFYZSnjB3mkA/CDsBtzNgDuRTOGKSas4Hpl8SN6lZJnWR41ZT/fPnK9O521Uuth4ncnRRbb7YYKYPFRcM0RpoXkjDCSMluVyCwATcEgn6jTn/AKxcJXKZ6Piyx/Z8QICPW04Ee/dXXDD54Gmlu9q17RqmnpLVboo6GZ6V4+ZlYchIycDbIAOMd9Hr/bjSUVIV4hssVTH+ONOSclc9o5AC301o8L7UP2Cs66c/0XDhXhLhekvC8S2asr5KWpg8JFiqFmhCc3NkHHN18ycZOrpclSikpLxTfHBRnMhA+MwNtIPXGz4/g89RNqmt8lopzRWuGC3zx8yRwU5hZMjIAUbd+mpm2GOFPDU81NKej74buD8/L/XSjk3LkxtQjx4pFqBDKCrBgRkMOhHnrnpqB4dmNG0lllJzSjnpST/8lPnYfND8B9OU99T2dMJ2KNU6YCN9D0Ghnb00MahQAM/TRchdgpI0bIGRob9ttWUG0NDOh11RDmN99DqdDqdQ9w4mo6Kr+z4EnuF1xtQUKeLMPVt+WMerlRq6sjdEx06ajL7eVslIjiI1FdUuIaSkU4eplP3VHkO5boqgk9NIJbL7cWButeLJTnrSWxBPU79mnccqn0RD/i0+4M4Os8NbPxFS0sjNIhgpaqrkaaokjzh5C7kn4iMADA5R0+LV1XYN30V+8WKpsvBd6kaZam+VkElTWVQGA7qhIVR2jXHKq+W/UnVc9n7e78H2aKQhmEKc7dizAMT9STrY6i1pdKStp5BkSRtEPqpB/XWH8ECSTh+GhlBWSNDCR5PH8P5/Docm4muDUhpxFwDw/c6urqqu00klwYcoqGQhiOwYgjI0jw7aafhemipbZY7ZAE3DuS7cx6tnlzj5nVlqanxkgaQf3jAxuP4l/wDWmNQ3hQyvkDAAU+bE4GgTbVM34pO0h1ZOI47hcp7e8ircadeeSm8TmPKT99D1K/p31ZUjWQsVO/4lPU/789Uj2bcKU3EF44lrayMgLUQUkM0LcsiEfEzK46N8Q/Q51ar5ZLrwnVQrVSiqt87iOGtRAhDnokoz8LHsw+FjtsdjJ466Bhmt0x5dKOouFGr0NQKa50xL01QycwR8YIYd1YbEfXsNefvaL+0VxVYL7U8NUtBR0tdTrh6p4jzSkrnCoxIQ5IAPxA9Rtr0Tb6yOdPCePw6lRnY7OvnrHP2lvZW/EnDD8TW2Hmu9shKToq58el2Jz6p1HoTqfPkjGfGfQP1Y5Shyh2i4+xOf2gcTcGpdL9eLRK00rLSrUUr+O4UkNzFGC4yCAQCcDOr/AE9ynjqYqS5Uy0tRNnwJYpPEgqcdQj4B5h1KMAfmN9Vv2HtNJ7LuDwRmSS2ItOuNlLE8z/6a0u5Wukrre9jFK1Tsrnlfk93I+6/P+FwdxjJ28uu8/wCTFYNqK2Q5HM3XYaNy5/51GWyerjqa603Mq1xt5UNKmAtRGw+CUDtnBBHZlPpqUAwNtAaLYbXCQASSAB1JOANAnfGoC9p9v1icOI5SmkUTXSbm5RDS/wD183ZpSOUDry858tRbKboPZad+PJRLLcJaDh+TPu8FO5iqbio6yF+scR/CFwzD4iQCBrRLXZrZw7RCltdBT0dOOkcKBQx8ye59TvrMb/xpw3aaNAL1QR3GncSQRU8glYMvRQqZwNsY8jp9V+2u0vGpt9nvVc7AEhacQxgkdOaRht9NHT8QFr1kxcUkuMlFQxyYnuJaKY9GijHxSOD2ONh6sNW6qlprbQszNFT0sEfViFSNQMDfsANYj/1C4ia71Fwo7FbqR5IRDH77UtMYxnLHlQKMseXO/wCHUHfKvifieojluvEciwxkMlNQ06RRK3n8XMSfUnbtjRLG2U5o3GzcRW650vNSmYqtV7uHkhZPEkK8/wAOd8cvnjWZXThqSw8QTVlHVNFbbjUyDJjDiKoJyVOdwH3I/iBHcaprWqakikqILlc5K2PmmjllrZDiTlxzYzjOw3x21tHC0UXG/s+opa0HnuVKFqlXHMkynDMvkyupI+Q0OTHSDxZKdlEr7TNNGWiCvKJBKexYjYjHqNcmoolyZ4mZXZUgp0BLyNjZQBuWJJ6amraKiI1FJWkGuo38GfAwGOMhx6MuD9SO2pHh+2RXa8XIt4clRTRxCNZNwsbBuYjyJYb/AE0rFNviPTmox5IjLDS1PC3DZo+aKlu9ZI9Q6wlXMBaTfOxGyqo9T+erPbL7RcV0M/D1/jjSqq4jGQPhSpX96Mno42PL1BAIyNMvsvxrrURgKQkiU6Bdgcbn9f5aNcuF0rfEjliUqWycsMZHQ+h9dMqhF29lToI6mirqi2XBy1ytsvhmbGPEHVX+TKQfnkdtW2nnWdOSRVJIwQRsw77f01UeIrNc7PVQ3uevlqooESnmWUczJCTlHLdTys2N8nlY77amaSoEirg/e3BB6HSuWFPQ9hnyjsW4QReF5/7PwIoMcYjs68vwJDzEsp9Yy247ry+urrJIaaNKChJapkJZ5WOW3+9Ix8/99hqkXOKS408axSCGtgYSwTAfdkG2/wDCQSrDuCdWbh25mrtBnggIuZcxVccnWCUdVPmBkEeYIPfWmOfJb7F82Pi7XRDcaxRcPrZ7jBGZJKd2Ws/e92cfExHflZVfHkG08XlZQwIYMMgjcEamWsxYiSpYSS86yEH4g3ofPPTyxqm1lDeeFahrbb+Hqq72xPipZoZlUxRHpE3NuSpyAf3eXWr2Yp12ZQL7xFfYYqqp4iqoYamNZBBbgsEagjOAwBcjfqTnSCcN21pHkqYGq3kbnkarlaZmbAHMeYnJwAM+g0vTUS2usuVpCkLbquSBB/4yeeMj/I6/lp8oK9fz00kvBd36KU9FT0qYp4Io4/3Y0C/ppyu3qD30nG3L8v00tjuOncasoMF5fl+mjgAbEbaKpx16eejfd+WoQKVxt2079mN/udhe+WoD3q301UKhKdW5JUSTclG/xK2VO2/Uab9djprw9UJa/aPbfFx7veKaSifJwOdf7xD8/hI+uhmrRcXTNL4nmpLnR/2ntDmSSjTwq+ALiQw9fiXqGQ5I81LYztqO4NnWovtZVQSZQ0SLIQdss+VH5Kfz09rrXNbquOsoZTFKPhEqjOR+646MPQ7H0OnPs8sCWqnuM/KB41a3hwrusYUABQe6glsZ6beWlXFXyG1N8eBOWqnAnEh7FpCT5n/nUslD4sxkkH93nIQ9z6+nppK3wFGAbfv/AL+v6ak2PKpPkM6gJAVcEFX9rGpjE1M8EkckZ/EpHKR9QNZRZHajqKu1TSl56OUwl+7YAKN/mQqfnnWyS02LfVAD4pFJ/Iba858a1UvCHtitskjEW7iykMSk9FqoDlcfNWI/LUceSCxz4SNPikLgMNnXr6HRzW1NrrRdbehkn5AlXSjpURjoR/Gu5Xz3U9RiPpakPGkw6EYYae53BB37HSm4u0PNKSpll+2PtGlpq2nnE1K684eH4SQe+PTfbqN9OFuE5UFamRlIyCCDqgVFwn4cnFZCw+zJpl96pyPhR2IUSg/hBJAb6Njrq7QGIhuWoSmYNh4pAEZG7ggkaajJSViE4OLpmIX+w1vD/EMNRcZPErr5TGqqgjFo4p0bHhx/wrE8a578hPfRkbmH8/nq8e16jeS2wXQIw+za5HyB+Bx4T7/Jgf8ALqiIfp5+nrpqDuItNUxddtu2lkPKcdv00kNxv19NKDRgivTfse2jKex1HpdqX7VNr581qwCpMYU/DGW5QSem5zt6HT7p8tQoUxjbUFxNUS0FNS3aDPvFpqoqxfUIwLD6jI1NFsrg6Qq4RU00sRGQ6ld9Qs3iSghq6dZqMq9NOgdUJ2KsMgqfkRtppw1UQUtrp2lPK8k0xAOBg+I2dtU/2XcTqeDLfDcJ1WOhZqJpZGA5DGcLnPYry6mrdd+HBTeHW11AXpaycxM8g2zISCMbEHI/LSjVaGFstdExBqGbO0hRR8v+dKVNYlPEGYZZ9lQfi/8AWmtLcqKtR2pauCWNMsxicNyjuTjpqMeZqqdpm2BGFX91ew/rqgiShufM/LMiqjbZB2Hz1g37UPDddX8M22qtEfiXKx1CVcGPvAvKseB+YP01tDfdOdxqk+04NUWe/wBG27i0lR6Ph2U/QgaOOpJgy3Fog7HWS+7qaqIQzgmKeMHISVTysPowP0xqwxN+HO46eo1QqWvmiNoq6qROW+UdPOzL933owqWx/jAOPVPXVqpqspyqx6fdP9DpbJCmPYp8kOOIIUqbDdIX6PSyg/8A4OtD4eiS78PWirqY4J6iSjhLvJGGJbkBPX56z67EPaaojo8RGfQ7f11YfZvckreDLTJFUuOSFYmApw2GRQpBJ7grjRYfTP6fCQvtnj4w4eqrfLVe7SVUMkDELzKc7ZAJznoeusJozWUtVW2m6cn2zbCq1Bj+7OhHwTp5BhjI88630wUqUsbNVxRSsoYI8eeTPTIB21kftJs9ztN3g4teGKroIqI0te9G+X5A+Vl5DvhQTnf10zjlToSyK1ZGocYBO3Y+X/rSoPbofXoNIBo3ijmilWWnlUMki9N9HUn7p6jW5ieRJb9d+HuP4Ky/z1VXLb6/MkckzZbDH4F9DnIHqNsa9gxSiRFOGHMAcN1HofXUW9nt01e9bJb6R61gqmZ4VZyF+7uRnbtqQyBvvg9fMaKTsqMaFSSNu3nojmZwI6aJpamTKxRqASzYJ7+QBPyGuluxO/p+umNxqTQRCuVkWWkzJHzkhS2CMbEHJBOMHIOhfWg0anZeFLHbGDmzs7sAxYMrlmwOZixIJJx6dh21Yj7mE8OKyJjylZQP66oEVVfQiNEPEjdQysk4wQRkdUP6648t+lB5yIx/FUnP5Ko/XSN2NUTt7j9x8Kqimp6aaJnZYUUsJQVwY855jkgYA6HfGp+hqErKSGpTZJ0V1+RGdZ/c+HqinoHmrKkc5eJOWPI5uaRVIJJLEbnbOD5a0cKqfCoAVdgBsANFF2imqF6OHx6pFP3E+NvkOn8/01nPHNUskt5diMSRKhz5FT/Q60pD7rbJJjs8/wB3/D2/lk/XXmD9ojj5eCoK2OJJJLhXYggVV5guIxzOR5DmG3ckeutMa5SM8j4xsdexa50vGfsltcdwg8ZbQDa6xcguio2YpVY9CqshB67Nq5V9puvDsDS1DC52hBn3qBMTxj/yRjr/AIl/LXhr2ee0/iL2Z1clRbpM0FYV8aCaPmil2xuOxwSNsa9l+xr2uWvj+KsjaN4LjCieJSF+YlOgZSPvoNl8xtkb6PNhabfgODPpL0tFvgreILbDTpDUQUVQ+GrSvKBF1Ph53Zz0GBgE5Ow1oNNSe7U0NPSxiCmgQRxwx9EUDYevz7nOiR11O55jOvOBj42wwHyO41x7jIrEQUzSIPxElcn5Y1hGKXQxObl2ISme4Oz2+nPuLMQZpScyHyRFGT9TrjcEVtRTVECzrTU9TG0bwsTIHDAg5Uk42Pnq6RotOiJEoWOMciqOgGqf7UbjVUtit1JTzPCt1r4qKeSMlXETBiwVvwk4xnrgnGOurugErdGA1tNJwCRbIa6mv1HQjw5ZqNH8VFGxDKAyM48lfO3TTf8AtpbVl8MtKFXpIUIA9N9/5a2algho6aKnp4Y4aeIBUjjHKqjyAGjvHG27RIx/iXP66FfW/UbP4l4zHzxjZzkCqJcDI5EZjny2GntPeRWBfd7ddJy4ziKjcj55xj+etGukvu1vnMKohIA+EY6kA9PQ6dFyqBRso2AB2A1H9T8Ra+JeszuKK8yyJGLJUwK2/jVLoioPNgCTj0xnToW+3UFP7xeUerm5nXxmLKkXblVQfhyO5JJ89WapYyRNzMSFyQM6jYbvMY4qYxwmIxAsGTPPnffPXWc80pdmsMEIbRVrXxjwnVxSrbrX7xDTsUEsfwbg4wCzA7Yx9NSlHxBAauB6eGrp4uYZ561RHnI+9zMQRjy31MPSUShJFt9ECAWwIFxn8tR97uH2bHHJT0lGkmx5hAAf5aG14guLfb/RauKLrTXKO201BW08kktZBl43DhSJU8v97avkcXvM6xDo5OfRe/8Ap9dYlwRcp7xLUS1Phk09ypYkCoBsZASSepP11vVpUAVMuPjB5R8gM/qdbRVIVyL8hC7zc88cK/dQdP8Af015I/a44e8W00t0wQ8Vaq846hXjZf1RdeqZGLVEjE5OB+mf1OsJ/arVV9ngbAJMiE5GejqR+p1ti1NC+VXFnh1hJ7qsSSHw0cuVxkEkAHr12HTtp9w3xLcOE71RXagnanqqaQPFMm6k91OexGxB6g76QY8syr1SRAxU7jSTKIqkKPiRyysrbhhjvro0IdHou4/tccW00yK1hsQRwHSfEpDqR1wW2P6agbj7eeP+JKk1tNxLFbI8cnu1PGEVcb9Dkk4I3zrKfdo0sU43K00yiNWOQFcZK/LIyPLUDKvu8jxqcqp25t8Dy1msUF0g3km/T//Z"};function presetPortrait(preset){return `<img class="user-avatar supplied-avatar" src="${suppliedAvatarImages[preset]}" alt="${avatarPresets.find(a=>a.id===preset)?.name||'Avatar'}">`}function avatar(id){const p=profiles[id];return p.photo?`<img class="user-avatar" src="${p.photo}" alt="${esc(p.name)}">`:p.preset?presetPortrait(p.preset):`<span class="user-avatar initials">${esc(p.name.slice(0,2).toUpperCase()||'TG')}</span>`}function avatarChooser(id){return `<div class="avatar-chooser" aria-label="Default avatars">${['Boys','Girls'].map(group=>`<div><small>${group} · Default avatars</small><div class="avatar-grid">${avatarPresets.filter(a=>a.group===group).map(a=>`<button type="button" class="avatar-choice" data-avatar-profile="${id}" data-avatar-preset="${a.id}" aria-label="${a.name}" aria-pressed="${profiles[id].preset===a.id&&!profiles[id].photo}">${presetPortrait(a.id)}</button>`).join('')}</div></div>`).join('')}</div>`}function profileForm(id,welcome=false){const p=profiles[id];return `<form class="profile-form" data-profile-form="${id}"><div class="profile-form-heading">${avatar(id)}<div><strong>${welcome?'Set up your profile':id==='work'?'Work profile':'Personal profile'}</strong><small>${id==='work'?'A separate space for your work notes':'Your name and picture in TypeGrid'}</small></div></div><label>Name<input class="profile-name" data-profile-name="${id}" aria-label="${id==='work'?'Work profile name':'Your name'}" value="${esc(p.name)}" maxlength="50" required></label><details class="avatar-options"><summary>Choose a profile avatar</summary>${avatarChooser(id)}</details><div class="profile-actions"><button type="button" data-profile-photo="${id}">${p.photo?'Edit picture':'Add picture'}</button><input class="profile-photo-input" type="file" accept="image/*" data-photo-for="${id}" aria-label="${id} profile picture"><button type="submit" class="primary">${welcome?'Get started →':'Save profile'}</button>${welcome?'':`<button type="button" data-switch-profile="${id}" ${activeProfile===id?'disabled':''}>${activeProfile===id?'Active profile':'Switch to '+(id==='work'?'work':'personal')}</button>`}</div></form>`}function switchProfile(id){activeProfile=id;notes=workspaces[id].notes;categories=workspaces[id].categories;trash=workspaces[id].trash;chosen=0;openTabs=[0];splitActive=false;splitChosen=null;activePane='primary';filter='';menuIndex=null;uploadOpen=false;shareOpen=false;ensureTabOpen(0);screen='notes';render();say('Switched to '+profiles[id].name)}function customFontFamily(){return customFont?`TypeGridCustom${String(customFont.id).replace(/[^a-z0-9]/gi,'')}`:null}async function loadCustomFont(){if(!customFont?.data||!document.fonts||!globalThis.FontFace)return null;const family=customFontFamily();if([...document.fonts].some(face=>face.family===family))return family;try{const encoded=customFont.data.split(',')[1];if(!encoded)throw new Error('Invalid font data');const binary=atob(encoded),bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);const face=new FontFace(family,bytes.buffer);await face.load();document.fonts.add(face);return family}catch(error){return null}}function applyEditorTabSize(){root.querySelectorAll('textarea.note-body').forEach(b=>{b.style.tabSize=String(editorTabSize)})}function applyEditorFont(){applyEditorTabSize();const fallback=editorFont==='jetbrains-mono'||editorFont==='space-mono'?"monospace":bundledFonts.find(([id,,kind])=>id===editorFont)?.[2]==='serif'?"serif":"sans-serif";const selected=editorFont==='custom'?customFontFamily():fontFamilyById[editorFont]||fontFamilyById.default;const family=`${selected},'Apple Color Emoji','Segoe UI Emoji','Noto Color Emoji',${fallback}`;root.querySelectorAll('.note-title,.rich-note,.editor textarea:not(.share-text):not(.task-source)').forEach(el=>el.style.setProperty('font-family',family,'important'));if(editorFont==='custom')loadCustomFont().then(loaded=>{if(!loaded){editorFont='default';applyEditorFont();persistNotes();say('That custom font could not be loaded')}})}function importCustomFont(file){const supported=/\.(ttf|otf|woff2?)$/i.test(file?.name||'');if(!file||!supported){say('Choose a .ttf, .otf, .woff, or .woff2 font');return}if(file.size>1572864){say('Custom fonts must be 1.5 MB or smaller');return}const reader=new FileReader();reader.onerror=()=>say('That font could not be read');reader.onload=async()=>{const next={id:Date.now().toString(36),name:file.name.replace(/\.(ttf|otf|woff2?)$/i,'').replace(/[_-]+/g,' ').trim()||'Custom font',data:String(reader.result)};customFont=next;editorFont='custom';const loaded=await loadCustomFont();if(!loaded){customFont=null;editorFont='default';say('That font file is not supported');return}persistNotes();render();say(`${next.name} added locally`)};reader.readAsDataURL(file)}function applyEditorZoom(){root.querySelectorAll('.editor .note-title').forEach(t=>{t.style.fontSize=(22*editorZoom/100)+'px';autoSizeTitle(t)});root.querySelectorAll('.editor textarea.note-body').forEach(b=>{b.style.fontSize=(editorSize*editorZoom/100)+'px'});const reset=root.querySelector('[data-action="zoom-reset"]');if(reset)reset.textContent=editorZoom+'%';const minus=root.querySelector('[data-action="zoom-out"]'),plus=root.querySelector('[data-action="zoom-in"]');if(minus)minus.disabled=editorZoom<=50;if(plus)plus.disabled=editorZoom>=200}const mobileToggle=document.createElement('button');mobileToggle.className='mobile-library-toggle';mobileToggle.setAttribute('aria-label','Open library navigation');mobileToggle.setAttribute('aria-expanded','false');mobileToggle.innerHTML='<i data-tg-icon="panel-left" aria-hidden="true"></i>';(root.querySelector('.titlebar-right')||root.querySelector('.titlebar')).prepend(mobileToggle);const mobileShade=document.createElement('button');mobileShade.className='mobile-nav-shade';mobileShade.setAttribute('aria-label','Close library navigation');win.appendChild(mobileShade);function toggleMobileNav(){const opened=root.classList.toggle('mobile-nav-open');mobileToggle.setAttribute('aria-expanded',String(opened))}mobileToggle.addEventListener('click',toggleMobileNav);mobileShade.addEventListener('click',toggleMobileNav);
let previousView='',previousPlatform='';const pageOrder=['welcome','notes','editor','search','trash','settings','about','privacy'];


root.addEventListener('click',e=>{const button=e.target.closest('[data-edit-profile]');if(!button)return;const panel=root.querySelector('#tg-edit-'+button.dataset.editProfile);panel.hidden=!panel.hidden;button.setAttribute('aria-expanded',String(!panel.hidden));button.textContent=panel.hidden?'Edit':'Done';if(!panel.hidden)panel.querySelector('input.profile-name').focus()});
function render(){root.classList.remove('mobile-nav-open');root.querySelector('.mobile-library-toggle')?.setAttribute('aria-expanded','false');root.dataset.screen=screen;root.classList.toggle('focus-mode',isFocusMode);root.querySelector('[data-action="toggle-focus"]')?.classList.toggle('active',isFocusMode);root.querySelectorAll('[data-action="toggle-wrap"]').forEach(btn=>btn.classList.toggle('active',isWordWrap));root.querySelector('.titlebar .time-island')?.remove();root.querySelector('.category-links').innerHTML=categories.length?categories.map((c,i)=>`<button data-category="${i}" class="${filter===c?'selected':''}" aria-label="${esc(c)}"><i data-tg-icon="folder" aria-hidden="true"></i><span>${esc(c)}</span></button>`).join(''):'<div style="padding:6px 10px;font-size:11.5px;color:var(--tg-muted)">No categories yet</div>';picker.value=screen;win.classList.toggle('phone',platform==='android');root.querySelector('.androidtime').hidden=platform!=='android';root.querySelectorAll('[data-platform]').forEach(b=>b.classList.toggle('active',b.dataset.platform===platform));root.querySelectorAll('.topbar [data-screen]').forEach(b=>b.classList.toggle('selected',b.dataset.screen===screen&&!filter));root.querySelector('.topbar [data-action="pinned"]')?.classList.toggle('selected',screen==='notes'&&filter==='Pinned');root.querySelector('.topbar [data-action="toggle-cats"]')?.classList.toggle('active',screen==='notes'&&!!filter&&filter!=='Pinned');root.querySelectorAll('[data-action="toggle-always-on-top"]').forEach(btn=>{btn.classList.toggle('active',isAlwaysOnTop);btn.setAttribute('aria-pressed',String(isAlwaysOnTop))});if(screen==='notes'||screen==='editor'){content.innerHTML=(screen==='notes'?`<section class="library"><div class="library-heading"><h2>${filter||'All notes'} <span class="subtitle">${notes.length}</span></h2><button data-action="new" aria-label="Create a new note"><i data-tg-icon="square-pen" aria-hidden="true"></i></button></div>${gooeySearch('Search notes','Search notes…')}<div class="list-caption"><span>YOUR COLLECTION · ${notes.length} NOTE${notes.length===1?'':'S'}</span><select class="library-sort" aria-label="Sort notes"><option value="pinned" ${noteSort==='pinned'?'selected':''}>Sort: Pinned first</option><option value="updated" ${noteSort==='updated'?'selected':''}>Sort: Recently edited</option><option value="created" ${noteSort==='created'?'selected':''}>Sort: Date created</option><option value="title" ${noteSort==='title'?'selected':''}>Sort: Title A–Z</option></select></div><div class="cards">${cards()}</div>${platform==='android'?'<button class="primary" data-action="new">+ New note</button>':''}</section>`:'')+(screen==='editor'?editor():'')}else if(screen==='welcome'){content.innerHTML=`<section class="full tg-beams-host"><div class="tg-beams" aria-hidden="true"></div><div class="welcome"><div class="welcome-story"><img class="brand-platforms" src="logo.png" alt="TypeGrid — Fast Autosaving Notes"><div class="platform-availability" aria-label="Available platforms"><span>Windows</span><span>Android</span><span>macOS</span><span>Linux</span></div><div class="welcome-kicker">THINK. WRITE. KEEP.</div><h1>Autosaved on<br>every keystroke.</h1><p>A little more room for your thoughts.<br>Notes, lists, and images, together in one quiet place. Saved on your device as you type.</p><div class="text-illustration" aria-label="Text highlight illustration"><div class="highlight-tools" aria-label="Illustration formatting"><button data-format="bold" aria-label="Bold highlighted text" aria-pressed="false"><b>B</b></button><button data-format="italic" aria-label="Italic highlighted text" aria-pressed="false"><em>I</em></button><button data-format="underline" aria-label="Underline highlighted text" aria-pressed="false"><u>U</u></button><button data-format="strike" aria-label="Strikethrough highlighted text" aria-pressed="false"><s>S</s></button><button data-format="replay" aria-label="Replay highlight animation">↻</button></div><p>A thought, a list, a little inspiration.<br><span class="illustration-highlight">Capture it the moment it arrives.</span> Keep writing. Every keystroke has a place to stay.</p></div><div class="banner"><span class="welcome-benefit">Instant autosave</span><span class="welcome-benefit">Private by default</span><span class="welcome-benefit">Ready offline</span></div></div><div class="welcome-setup"><h2>Make yourself at home.</h2><p>Your name, your notes, your space.<br>Start with a profile. No account required.</p>${profileForm('personal',true)}<p class="subtitle">TypeGrid 1.0.8 · Lightweight Offline Notes &amp; Editor</p><div class="creator-credit"><span>Lead Visionary &amp; Engineer</span><strong>Yeasin Arafat Sadiq</strong><a class="creator-link" href="https://www.sadiqtbh.com" target="_blank" rel="noopener noreferrer">www.sadiqtbh.com</a><a class="creator-link official-link" href="https://www.typegrid.site/" target="_blank" rel="noopener noreferrer">Official site · www.typegrid.site</a></div></div></div></section>`}else if(screen==='search'){content.innerHTML=`<section class="full"><h2>Search notes</h2>${gooeySearch('Search all notes','Search all notes…')}<div class="cards">${cards()}</div></section>`}else if(screen==='trash'){content.innerHTML=`<section class="full"><div class="library-heading"><div><h2>Trash</h2><p class="subtitle" style="margin:4px 0 0">Restore deleted notes or permanently remove them.</p></div>${trash.length?'<button type="button" class="tg-pill-btn" data-action="empty-trash">Empty Trash</button>':''}</div>${trash.length?trash.map((n,i)=>`<div class="feature"><div class="trash-title"><strong>${esc(n.title)||'Untitled note'}</strong><small>${esc((n.body||'').slice(0,90).trim())||'Empty note'}</small></div><div class="trash-actions"><button class="tg-pill-btn" data-restore="${i}">Restore</button><button class="tg-pill-btn" data-purge="${i}" title="Delete permanently">Delete</button></div></div>`).join(''):'<div class="welcome"><i data-tg-icon="trash-2"></i><h2>No deleted notes</h2><p>Deleted notes will appear here.</p></div>'}</section>`}else if(screen==='privacy'){content.innerHTML=`<section class="full about-page privacy-page"><header class="settings-heading"><h2>Privacy Policy</h2><p>TypeGrid — Fast Autosaving Notes. Last updated: October 2026.</p></header><p class="about-lede">TypeGrid is a fully offline notes app. It collects nothing, sends nothing, and shares nothing. This policy explains exactly what that means.</p><section class="settings-group" aria-label="Privacy policy details"><h3>Your data stays on your device</h3><div class="feature"><div>No data collection<small>TypeGrid does not collect, store, or transmit any personal data. Your notes, images, settings, and profile name are saved only on your own device — never on our servers, because we have no servers.</small></div></div><div class="feature"><div>No account, no sign-in<small>TypeGrid never asks for your name, email, password, or any identifying information. There is nothing to leak because there is nothing to take.</small></div></div><div class="feature"><div>No analytics or tracking<small>The app contains no analytics, no crash reporters, no advertising, and no third-party trackers of any kind. We do not know how many people use TypeGrid, and we like it that way.</small></div></div><div class="feature"><div>No network access<small>TypeGrid works entirely offline. It does not connect to the internet for any feature — no sync, no AI, no updates pushed in the background. The only outbound links are the ones you choose to tap, which open in your own browser.</small></div></div><div class="feature"><div>Exports are yours alone<small>When you export a note as PDF, Word, or text, the file is created on your device and saved where you choose. It never passes through us.</small></div></div><div class="feature"><div>Even we can't see anything about you<small>As the publisher, we have no access to your notes — there is no server holding them and no door for us to open. Nobody at TypeGrid, including us, can read a single word you write.</small></div></div><div class="feature"><div>Children's privacy<small>Because TypeGrid collects no data from anyone, it collects no data from children. It is safe for writers of every age.</small></div></div><div class="feature"><div>Changes to this policy<small>If this policy ever changes, the updated version will ship inside the app itself — you will never be asked to accept anything online.</small></div></div></section><div class="creator-credit"><span>Questions about privacy?</span><strong>TypeGrid</strong><a class="creator-link official-link" href="https://www.typegrid.site/" target="_blank" rel="noopener noreferrer">www.typegrid.site</a></div></section>`}else if(screen==='about'){content.innerHTML=`<section class="full about-page"><header class="settings-heading"><h2>About TypeGrid</h2><p>Fast, lightweight Notepad-speed notes and text editor — completely offline.</p></header><p class="about-lede">TypeGrid keeps every note, opened file, and image locally on your device. No account, no cloud, no telemetry, ever.</p><p class="release-version">Version 1.0.8 · Lightweight Desktop Release</p><div class="platform-availability platform-availability-wide" aria-label="TypeGrid is available for"><span>Windows</span><span>Android</span><span>macOS</span><span>Linux</span></div><section class="settings-group" aria-label="What makes TypeGrid different"><h3>Built like classic Windows Notepad, with modern superpowers</h3><div class="feature"><div>Zero-lag, Notepad-grade speed<small>Pure native text editing with zero blur layers or heavy DOM overlays. Typing, scrolling large files, Find &amp; Replace, and Go to Line stay instant.</small></div></div><div class="feature"><div>Open &amp; edit any text or code file<small>Open .txt, .md, .json, .csv, .log, .ini, .env, .py, .js, .html, or extensionless files directly via Ctrl+O, drag-and-drop, or Windows Explorer “Open with” — preserving line endings and original extensions.</small></div></div><div class="feature"><div>Fully offline, zero tracking<small>No sign-up, no sync servers, no analytics, and no network access. Everything stays strictly on your own disk.</small></div></div><div class="feature"><div>Non-blocking local autosave<small>Edits autosave cleanly in the background while attached images are stored as dedicated media files on disk to keep startup and typing instant.</small></div></div><div class="feature"><div>Structured writing without bloat<small>Checklists, bullet lists, categories, pinned notes, word/line metrics, Notepad Focus Mode, custom fonts, and one-click export to original format, PDF, or Word (.docx).</small></div></div></section><div class="creator-credit"><span>Lead Visionary &amp; Engineer</span><strong>Yeasin Arafat Sadiq</strong><a class="creator-link" href="https://www.sadiqtbh.com" target="_blank" rel="noopener noreferrer">www.sadiqtbh.com</a><a class="creator-link official-link" href="https://www.typegrid.site/" target="_blank" rel="noopener noreferrer">Official site · www.typegrid.site</a><button class="creator-link official-link privacy-link" data-screen="privacy">Privacy policy</button></div></section>`}else{content.innerHTML=`<section class="full settings-page"><header class="settings-heading"><h2>Settings</h2><p>Customize TypeGrid performance, appearance, and Windows file integration.</p></header><section class="settings-group" aria-labelledby="tg-preferences"><h3 id="tg-preferences">Appearance &amp; Editor</h3><div class="feature"><div>Theme<small>Switch between light and dark mode (Ctrl+T)</small></div><select aria-label="Theme" data-setting="theme"><option value="light">Light</option><option value="dark">Dark</option></select></div><div class="feature"><div>Base Font Size<small>Default editor font size at 100% zoom</small></div><select aria-label="Base font size" data-setting="size">${[12,13,14,15,16,18,20,22,24].map(sz=>`<option value="${sz}" ${editorSize===sz?'selected':''}>${sz} px</option>`).join('')}</select></div><div class="feature"><div>Word Wrap<small>Wrap long lines inside the editor window (Ctrl+W)</small></div><select aria-label="Word wrap" data-setting="wrap"><option value="on" ${isWordWrap?'selected':''}>Wrap long lines</option><option value="off" ${!isWordWrap?'selected':''}>No wrap (horizontal scroll)</option></select></div><div class="feature"><div>Layout Mode<small>Use standard sidebar + cards or distraction-free Notepad Focus Mode (Ctrl+B)</small></div><select aria-label="Layout mode" data-setting="focus"><option value="off" ${!isFocusMode?'selected':''}>Standard Workspace</option><option value="on" ${isFocusMode?'selected':''}>Notepad Focus Mode</option></select></div><div class="feature"><div>Tab Indentation<small>Spaces inserted when pressing Tab in notes &amp; code</small></div><select aria-label="Tab size" data-setting="tabsize"><option value="2" ${editorTabSize===2?'selected':''}>2 spaces</option><option value="4" ${editorTabSize===4?'selected':''}>4 spaces</option></select></div></section><section class="settings-group" aria-labelledby="tg-integration"><h3 id="tg-integration">Windows Integration &amp; Data</h3><div class="feature"><div>Windows Explorer “Open with”<small>Register TypeGrid in Explorer “Open with” for .txt and 65+ code, config, and data extensions without changing your default apps.</small></div><div class="openwith-action-row"><button type="button" class="tg-pill-btn" data-action="register-open-with">Refresh “Open with” Entry</button></div></div><div class="feature"><div>Export All Notes<small>Download all notes in your active workspace as a single plain-text backup file.</small></div><div class="openwith-action-row"><button type="button" class="tg-pill-btn" data-action="backup">Backup All Notes</button></div></div></section><details class="brand-about"><summary>About TypeGrid · Version 1.0.8</summary><div class="platform-availability platform-availability-wide" aria-label="TypeGrid is available for"><span>Windows</span><span>Android</span><span>macOS</span><span>Linux</span></div><img src="logo.png" alt="TypeGrid — Fast Autosaving Notes for Windows and Android. Website: www.typegrid.site"><a href="https://www.typegrid.site/" target="_blank" rel="noopener noreferrer">Visit typegrid.site ↗</a></details><div class="creator-credit"><span>Lead Visionary &amp; Engineer</span><strong>Yeasin Arafat Sadiq</strong><a class="creator-link" href="https://www.sadiqtbh.com" target="_blank" rel="noopener noreferrer">www.sadiqtbh.com</a><a class="creator-link official-link" href="https://www.typegrid.site/" target="_blank" rel="noopener noreferrer">Official site · www.typegrid.site</a></div><details class="icon-credits"><summary>Icon credits</summary><p>Solar icons by 480 Design · <a href="https://www.svgrepo.com/collection/solar-linear-icons/" target="_blank" rel="noopener noreferrer">SVG Repo collection</a> · <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener noreferrer">CC BY 4.0</a>. Sourced via Iconify, resized and colored for TypeGrid.</p></details></section>`;root.querySelector('[data-setting="theme"]').value=root.style.colorScheme==='dark'?'dark':'light'}const island=root.querySelector('.editor .time-island');const slot=root.querySelector('.titlebar-island-slot');if(island&&slot)slot.appendChild(island);icons();syncTitlebarDoc();applyEditorZoom();applyEditorFont();if(screen==='editor'){root.querySelectorAll('.editor .note-title').forEach(t=>autoSizeTitle(t));updateStatusMetrics()}previousView=screen;previousPlatform=platform;}
function notePdfDocument(n){const escHtml=t=>esc(t).replace(/\n/g,'<br>');const body=escHtml(n.body||'');return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>'+esc(n.title||'TypeGrid note')+'</title><style>@page{margin:2cm}body{font-family:Figtree,"Segoe UI",Arial,sans-serif;color:#1f292a;line-height:1.8;font-size:11.5pt;white-space:pre-wrap;overflow-wrap:anywhere}h1{font-family:Outfit,"Segoe UI",Arial,sans-serif;font-size:20pt;margin:0 0 6px;overflow-wrap:anywhere}.meta{color:#677776;font-size:9pt;margin-bottom:18px}</style></head><body><h1>'+esc(n.title||'Untitled note')+'</h1><div class="meta">TypeGrid · '+esc(n.updatedAt||n.createdAt||'')+'</div><div>'+body+'</div></body></html>'}
async function exportNotePdf(n){const html=notePdfDocument(n);const name=(n.title||'TypeGrid note')+'.pdf';if(window.TypeGridNative?.exportPdf){const ok=await window.TypeGridNative.exportPdf(html,name);say(ok?'PDF saved.':'PDF export cancelled.');return}
const w=window.open('','_blank');if(!w){say('Allow pop-ups to export PDF.');return}w.document.write(html);w.document.close();w.focus();setTimeout(()=>{w.print()},300);say('Choose "Save as PDF" in the print dialog.')}
function crc32(b){let c,t=crc32.t;if(!t){t=crc32.t=[];for(let n=0;n<256;n++){c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}}c=-1;for(let i=0;i<b.length;i++)c=t[(c^b[i])&255]^(c>>>8);return(c^-1)>>>0}function zipStore(files){const enc=new TextEncoder(),parts=[],cen=[];let off=0;for(const[name,str]of files){const nb=enc.encode(name),d=enc.encode(str),crc=crc32(d),h=new DataView(new ArrayBuffer(30));h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint32(14,crc,true);h.setUint32(18,d.length,true);h.setUint32(22,d.length,true);h.setUint16(26,nb.length,true);parts.push(new Uint8Array(h.buffer),nb,d);const c=new DataView(new ArrayBuffer(46));c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint32(16,crc,true);c.setUint32(20,d.length,true);c.setUint32(24,d.length,true);c.setUint16(28,nb.length,true);c.setUint32(42,off,true);cen.push(new Uint8Array(c.buffer),nb);off+=30+nb.length+d.length}const cs=cen.reduce((a,x)=>a+x.length,0),e=new DataView(new ArrayBuffer(22));e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,cs,true);e.setUint32(16,off,true);const all=[...parts,...cen,new Uint8Array(e.buffer)],out=new Uint8Array(all.reduce((a,x)=>a+x.length,0));let p=0;for(const x of all){out.set(x,p);p+=x.length}return out}function noteDocx(n){const x=t=>String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');const para=(t,title)=>`<w:p>${title?'<w:pPr><w:spacing w:after="240"/></w:pPr>':''}<w:r><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/>${title?'<w:b/><w:sz w:val="36"/>':'<w:sz w:val="24"/>'}</w:rPr><w:t xml:space="preserve">${x(t)}</w:t></w:r></w:p>`;const body=para(n.title||'Untitled note',1)+String(n.body||'').split(/\r?\n/).map(l=>para(l)).join('');const W='http://schemas.openxmlformats.org/';return zipStore([['[Content_Types].xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="${W}package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>`],['_rels/.rels',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="${W}package/2006/relationships"><Relationship Id="rId1" Type="${W}officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`],['word/document.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="${W}wordprocessingml/2006/main"><w:body>${body}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body></w:document>`]])}async function exportNoteDocx(n){const bytes=noteDocx(n),name=(n.title||'TypeGrid note')+'.docx';if(window.TypeGridNative?.exportDocx){let b='';for(let i=0;i<bytes.length;i+=8192)b+=String.fromCharCode(...bytes.subarray(i,i+8192));await window.TypeGridNative.exportDocx(btoa(b),name);return}const url=URL.createObjectURL(new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}async function download(text,name,eol='CRLF',targetNote=null){
  if(window.TypeGridNative?.exportText){
    const res=await window.TypeGridNative.exportText(text,name,eol);
    const ok=res===true||(res&&res.ok);
    if(res&&res.ok&&targetNote&&res.path){
      targetNote.filePath=res.path;
      targetNote.fileName=res.name||targetNote.fileName;
      targetNote.fileExt=res.ext||targetNote.fileExt;
      flushSave();
      if(screen==='editor')render();
      say('Saved as "'+(res.name||name)+'"');
    }else if(ok){
      say('Saved "'+name+'"');
    }
    return ok;
  }
  const url=URL.createObjectURL(new Blob([text],{type:'text/plain'}));
  const a=document.createElement('a');a.href=url;a.download=name;a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
  return true;
}
async function saveCurrentNoteToDisk(saveAs=false){
  const n=notes[getPaneIndex()];
  if(!n)return false;
  if(!saveAs&&n.filePath&&window.TypeGridNative?.saveFile){
    const res=await window.TypeGridNative.saveFile(n.filePath,n.body||'',n.eol||'CRLF');
    if(res&&res.ok){
      flushSave();
      say('✓ Saved "'+(n.fileName||res.name)+'"');
      return true;
    }
    say(res?.error||'Could not save disk file');
    return false;
  }
  const suggested=n.fileName?n.fileName:((n.title||'TypeGrid-note')+(n.fileExt||'.txt'));
  const content=(n.filePath||n.fileExt)?(n.body||''):(n.title?n.title+'\n\n'+(n.body||''):(n.body||''));
  return await download(content,suggested,n.eol||'CRLF',n);
}root.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.noteOptions!==undefined){chosen=+b.dataset.noteOptions;menuIndex=menuIndex===chosen?null:chosen;render();return}if(b.dataset.avatarPreset){const id=b.dataset.avatarProfile;profiles[id].preset=b.dataset.avatarPreset;profiles[id].photo='';render();scheduleSave(200);say('Default avatar selected');return}if(b.dataset.profilePhoto){root.querySelector('[data-photo-for='+b.dataset.profilePhoto+']').click();return}if(b.dataset.switchProfile){switchProfile(b.dataset.switchProfile);return}if(b.dataset.format){const mark=root.querySelector('.illustration-highlight');const format=b.dataset.format;if(format==='replay'){mark.style.animation='none';void mark.offsetWidth;mark.style.animation=''}else{const active=mark.classList.toggle('is-'+format);b.setAttribute('aria-pressed',String(active))}return}if(b.dataset.platform){platform=b.dataset.platform;render();saveState()}if(b.dataset.screen){screen=b.dataset.screen;filter='';render();saveState()}if(b.dataset.note!==undefined){chosen=+b.dataset.note;activePane='primary';ensureTabOpen(chosen);menuIndex=null;screen='editor';uploadOpen=false;shareOpen=false;render();saveState();scheduleSave(200);return}
if(b.dataset.tab!==undefined){const nextIdx=+b.dataset.tab;if(splitActive&&nextIdx===splitChosen&&chosen!==nextIdx){splitChosen=chosen}chosen=nextIdx;activePane='primary';ensureTabOpen(chosen);screen='editor';render();scheduleSave(200);return}
if(b.dataset.closeTab!==undefined){const closeIdx=+b.dataset.closeTab;openTabs=openTabs.filter(i=>i!==closeIdx);if(splitChosen===closeIdx){splitActive=false;splitChosen=null;activePane='primary'}if(!openTabs.length){screen='notes'}else if(chosen===closeIdx){chosen=openTabs[0];activePane='primary';if(splitChosen===chosen){const alt=openTabs.find(i=>i!==chosen);if(alt!==undefined)splitChosen=alt;else{splitActive=false;splitChosen=null}}}render();scheduleSave(200);return}if(b.dataset.restore!==undefined){notes.unshift(trash.splice(+b.dataset.restore,1)[0]);onNoteInsertedAtZero();render();scheduleSave(200);say('Note restored');return}
if(b.dataset.purge!==undefined){trash.splice(+b.dataset.purge,1);render();scheduleSave(200);say('Deleted permanently');return}if(b.dataset.category!==undefined){filter=categories[+b.dataset.category];screen='notes';menuIndex=null;closeCatMenu();render();saveState();return}let a=b.dataset.action;if(['zoom-in','zoom-out','zoom-reset'].includes(a)){editorZoom=a==='zoom-reset'?100:Math.max(50,Math.min(200,editorZoom+(a==='zoom-in'?10:-10)));applyEditorZoom();scheduleSave(300);return}if(a==='time-island'){const island=b.closest('.time-island');const open=island.classList.toggle('open');b.setAttribute('aria-expanded',String(open));return}if(a==='create-category'){const f=root.querySelector('.category-form');f.hidden=false;f.querySelector('input').focus();return}if(a==='cancel-category'){const panel=root.querySelector('.category-form');hidePanel(panel,()=>panel.hidden=true);return}if(a==='note-pin'){menuIndex=null;a='pin'}if(a==='note-delete'){menuIndex=null;a='delete'}if(a==='note-edit'){menuIndex=null;activePane='primary';ensureTabOpen(chosen);screen='editor';render();getTitleEl('primary')?.focus();return}
if(a==='note-split'){
  menuIndex=null;
  if(notes.length<2){
    notes.unshift({createdAt:new Date().toISOString(),title:'',tag:'Uncategorized',body:''});
    chosen=1;splitChosen=0;
  }else if(chosen===splitChosen||splitChosen===null){
    splitChosen=notes.findIndex((_,i)=>i!==chosen);
  }
  const targetIdx=+b.closest('.note-item')?.querySelector('[data-note]')?.dataset.note;
  if(!Number.isNaN(targetIdx)){
    if(targetIdx!==chosen){splitChosen=targetIdx}
    else{splitChosen=notes.findIndex((_,i)=>i!==targetIdx)}
  }
  splitActive=true;activePane='split';ensureTabOpen(chosen);ensureTabOpen(splitChosen);screen='editor';render();scheduleSave(200);say('Opened side-by-side split view');return;
}if(a==='note-image'){menuIndex=null;screen='editor';uploadOpen=true;shareOpen=false;render();return}if(a==='note-share'){menuIndex=null;screen='editor';shareOpen=true;uploadOpen=false;render();return}if(a==='close-share'){shareOpen=false;render();return}if(a==='copy-note'){const t=root.querySelector('.share-text');t.select();try{if(window.TypeGridNative?window.TypeGridNative.copy(t.value):document.execCommand('copy'))say('Note text copied');else say('Select the preview text and copy it.')}catch(e){say('Select the preview text and copy it.')}return}if(a==='open-search'){const wrap=b.closest('.gooey-search');wrap.classList.add('open');b.setAttribute('aria-expanded','true');wrap.querySelector('input').focus()}if(a==='close-search'){const wrap=b.closest('.gooey-search');wrap.classList.remove('open');wrap.querySelector('input').value='';wrap.querySelector('.gooey-trigger').setAttribute('aria-expanded','false');root.querySelector('.cards').innerHTML=cards();wrap.querySelector('.gooey-trigger').focus()}if(a==='add-image'){uploadOpen=!uploadOpen;root.querySelector('.upload-panel').hidden=!uploadOpen;b.setAttribute('aria-expanded',String(uploadOpen))}if(a==='choose-images')root.querySelector('.image-upload').click();if(a==='choose-font')root.querySelector('.custom-font-upload').click();if(a==='close-upload'){uploadOpen=false;const panel=root.querySelector('.upload-panel');hidePanel(panel,()=>panel.hidden=true)}if(a==='attachments'){const gallery=root.querySelector('.attachment-gallery');gallery.hidden=!gallery.hidden;const folder=root.querySelector('.attachment-folder');folder.classList.toggle('open',!gallery.hidden);folder.setAttribute('aria-expanded',String(!gallery.hidden))}if(a==='window-min'||a==='window-max'||a==='window-close'){if(window.TypeGridNative?.windowAction)window.TypeGridNative.windowAction(a.slice(7));else say('Window controls are available in the Windows app')}if(a==='new'){notes.unshift({createdAt:new Date().toISOString(),title:'',tag:'Uncategorized',body:''});onNoteInsertedAtZero();screen='editor';render();getTitleEl('primary')?.focus();scheduleSave(200);say('New note ready');return}if(['pinned','work','personal'].includes(a)){filter={pinned:'Pinned',work:'Work',personal:'Personal'}[a];screen='notes';render()}if(a==='toggle-always-on-top'){await toggleAlwaysOnTop();return}
if(a==='toggle-cats'){
  const m=root.querySelector('.topbar-cat-menu');
  if(m){const next=m.hidden;m.hidden=!next;b.setAttribute('aria-expanded',String(next))}
  return;
}
if(a==='toggle-split'){
  if(splitActive){splitActive=false;activePane='primary';render();scheduleSave(200);say('Split view closed');return}
  let alt=openTabs.find(i=>i!==chosen);
  if(alt===undefined)alt=notes.findIndex((_,i)=>i!==chosen);
  if(alt===-1){
    notes.push({title:'',tag:'Uncategorized',body:'',createdAt:new Date().toISOString()});
    alt=notes.length-1;
  }
  splitChosen=alt;splitActive=true;activePane='primary';ensureTabOpen(chosen);ensureTabOpen(splitChosen);render();scheduleSave(200);say('Side-by-side split view ready');return;
}
if(a==='close-split'){splitActive=false;activePane='primary';render();scheduleSave(200);return}
if(a==='swap-split'){if(splitChosen!==null&&splitChosen<notes.length){const tmp=chosen;chosen=splitChosen;splitChosen=tmp;render();scheduleSave(200)}return}
if(a==='split-new'){notes.push({title:'',tag:'Uncategorized',body:'',createdAt:new Date().toISOString()});splitChosen=notes.length-1;splitActive=true;activePane='split';ensureTabOpen(splitChosen);render();getTitleEl('split')?.focus();scheduleSave(200);return}
if(a==='toggle-tools'){
  const wrap=b.closest('.tg-tools-wrap'),menu=wrap?.querySelector('.tg-tools-menu');
  if(wrap&&menu){
    const open=menu.hidden;
    menu.hidden=!open;
    wrap.classList.toggle('open',open);
    b.setAttribute('aria-expanded',String(open));
  }
  return;
}
if(a&&a.startsWith('tool-')){runEditorTool(a);return}
if(a==='toggle-eol'){
  const n=notes[getPaneIndex()];
  if(n){
    n.eol=n.eol==='LF'?'CRLF':'LF';
    const el=root.querySelector('.status-eol');
    if(el)el.textContent=n.eol==='LF'?'Unix (LF)':'Windows (CRLF)';
    scheduleSave(200);
    say('Line endings set to '+n.eol);
  }
  return;
}
if(a==='empty-trash'){trash.length=0;render();scheduleSave(200);say('Trash emptied');return}
if(a==='note-duplicate'){
  menuIndex=null;
  const srcNote=notes[getPaneIndex()];
  if(srcNote){
    const copyTitle=(srcNote.title||'Untitled note')+' (Copy)';
    notes.unshift({title:copyTitle,tag:srcNote.tag||'Uncategorized',body:srcNote.body||'',eol:srcNote.eol||'CRLF',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});
    onNoteInsertedAtZero();screen='editor';render();scheduleSave(200);
    say('Note duplicated');
  }
  return;
}
if(a==='note-copy'){
  menuIndex=null;
  const n=notes[getPaneIndex()];
  const txt=n?((n.title&&!n.filePath&&!n.fileExt?n.title+'\n\n':'')+(n.body||'')):'';
  if(!txt){render();say('Note is empty');return}
  let ok=false;
  if(window.TypeGridNative?.copy)ok=!!window.TypeGridNative.copy(txt);
  if(!ok&&navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(txt);ok=true}catch(_){}}
  render();
  say(ok?'Note copied to clipboard':'Could not copy note');
  return;
}
if(a==='pin'){
  const n=notes[chosen];
  if(n){
    n.pinned=!n.pinned;
    const pinBtn=root.querySelector('.notetabs-bar [data-action="pin"]');
    if(pinBtn){pinBtn.textContent=n.pinned?'Pinned':'Pin';pinBtn.classList.toggle('active',!!n.pinned)}
    const cardTitle=root.querySelector(`.notecard[data-note="${chosen}"] strong`);
    if(cardTitle)cardTitle.textContent=(n.pinned?'⌑  ':'')+(n.title.trim()||'Untitled note');
    root.querySelector('.note-actions')?.remove();
    scheduleSave(200);
    say(n.pinned?'Note pinned':'Note unpinned');
  }
  return;
}
if(a==='save-file'){await saveCurrentNoteToDisk(false);return}
if(a==='delete'){const rmIdx=chosen;trash.push(notes.splice(rmIdx,1)[0]);onNoteRemovedAt(rmIdx);screen=notes.length?'editor':'notes';render();scheduleSave(200);say('Moved to trash. You can restore it.');return}
if(a==='insert'){const t=getBodyEl();if(t){replaceRangePreserveUndo(t,t.selectionStart??t.value.length,t.selectionEnd??t.value.length,b.dataset.text);t.dispatchEvent(new Event('input',{bubbles:true}));t.focus()}return}
if(a==='editor-undo'){const target=getTargetField();if(target){target.focus();document.execCommand('undo');target.dispatchEvent(new Event('input',{bubbles:true}));updateStatusMetrics()}return}
if(a==='editor-redo'){const target=getTargetField();if(target){target.focus();document.execCommand('redo');target.dispatchEvent(new Event('input',{bubbles:true}));updateStatusMetrics()}return}
if(a==='editor-cut'){await executeCut(getTargetField());return}
if(a==='editor-copy'){await executeCopy(getTargetField());return}
if(a==='editor-paste'){await executePaste(getTargetField());return}
if(a==='open-find'){
  findOpen=!findOpen;
  if(findOpen)replaceOpen=false;
  root.querySelector('.toolbar [data-action="open-find"]')?.classList.toggle('active',findOpen);
  syncFindBarUI();
  if(findOpen){
    const inp=root.querySelector('.find-input');
    const t=getBodyEl();
    if(inp&&t){
      const sel=t.value.slice(t.selectionStart||0,t.selectionEnd||0);
      if(sel&&sel.length<80&&!sel.includes('\n')){inp.value=sel;findQuery=sel}
    }
    inp?.focus();inp?.select();updateFindMatches(false);
  }else{
    getBodyEl()?.focus();
  }
  return;
}
if(a==='close-find'){findOpen=false;root.querySelector('.toolbar [data-action="open-find"]')?.classList.remove('active');syncFindBarUI();getBodyEl()?.focus();return}
if(a==='toggle-replace'){replaceOpen=!replaceOpen;syncFindBarUI();root.querySelector(replaceOpen?'.replace-input':'.find-input')?.focus();return}
if(a==='find-next'){findNext();return}
if(a==='find-prev'){findPrev();return}
if(a==='toggle-case'){findMatchCase=!findMatchCase;syncFindBarUI();updateFindMatches(false);return}
if(a==='toggle-word'){findWholeWord=!findWholeWord;syncFindBarUI();updateFindMatches(false);return}
if(a==='replace-one'){replaceOne();return}
if(a==='replace-all'){replaceAllMatches();return}
if(a==='toggle-wrap'){toggleWordWrap();return}
if(a==='toggle-focus'){toggleFocusMode();return}
if(a==='toggle-theme'){toggleTheme();return}
if(a==='goto-line'){openGoToLine();return}
if(a==='submit-goto'){const v=parseInt(root.querySelector('.goto-input')?.value,10);executeGoToLine(v);return}
if(a==='show-shortcuts'){showShortcutsModal();return}
if(a==='close-modal'){closeModal();return}
if(a==='open-file'){await triggerOpenFile();return}
if(a==='register-open-with'){
  if(window.TypeGridNative?.registerOpenWith){
    const res=await window.TypeGridNative.registerOpenWith(true);
    say(res?.ok?'Registered TypeGrid in Windows Explorer "Open with" ('+(res.extensions||60)+'+ file types)':'Could not register Open With: '+(res?.reason||res?.error||'unavailable'));
  }else{
    say('Windows Explorer integration is available in the installed Windows app.');
  }
  return;
}
if(a==='export'){await saveCurrentNoteToDisk(true);return}
if(a==='export-pdf'){exportNotePdf(notes[getPaneIndex()]);return}
if(a==='export-docx'){exportNoteDocx(notes[getPaneIndex()]);return}
if(a==='backup'){download(notes.map(n=>(n.title?n.title+'\n\n':'')+(n.body||'')).join('\n\n──────────\n\n'),'TypeGrid-notes.txt');return}
if(['copy-note','open-search','close-search','add-image','choose-images','choose-font','close-upload','attachments','new','restore','category','note-pin','note-delete','note-edit','note-image','note-share','close-share','avatarPreset','profilePhoto','switchProfile','create-category','cancel-category'].some(x=>a===x))scheduleSave(200);
});
root.addEventListener('mousedown',e=>{
  if(e.target.closest('.toolbar button, .notetabs-bar .editorhead-actions button, .split-pane-head button, .zoom-controls button, .find-replace-bar button'))e.preventDefault();
});
root.addEventListener('focusin',e=>{
  const pane=e.target.closest('.writing-pane');
  if(pane&&pane.dataset.pane){
    const nextPane=pane.dataset.pane;
    if(nextPane!==activePane){
      activePane=nextPane;
      root.querySelectorAll('.writing-pane').forEach(p=>p.classList.toggle('is-active',p.dataset.pane===activePane));
      updateStatusMetrics();
    }
  }
  if(e.target.matches('.note-title'))activeEditorField='title';
  else if(e.target.matches('textarea.note-body'))activeEditorField='body';
});
root.addEventListener('input',e=>{
if(e.target.classList.contains('find-input')){
  findQuery=e.target.value;
  updateFindMatches();
  return;
}
if(e.target.classList.contains('replace-input')){
  replaceQuery=e.target.value;
  return;
}
if(e.target.dataset.profileName){profiles[e.target.dataset.profileName].name=e.target.value;scheduleSave(400)}if(e.target.classList.contains('search'))root.querySelector('.cards').innerHTML=cards(e.target.value);if(e.target.matches('.note-title,textarea.note-body')){
  const paneKey=e.target.closest('.writing-pane')?.dataset.pane||'primary';
  const noteIdx=getPaneIndex(paneKey);
  const n=notes[noteIdx];
  if(n){
    const titleEl=getTitleEl(paneKey);
    const bodyEl=getBodyEl(paneKey);
    if(e.target===titleEl){
      n.title=titleEl.value;
      autoSizeTitle(titleEl);
      syncTitlebarDoc();
      const tabBtn=root.querySelector(`.note-tab-btn[data-tab="${noteIdx}"]`);
      if(tabBtn)tabBtn.textContent=(n.fileName||n.title||'').trim()||'Untitled note';
    }
    if(bodyEl)n.body=bodyEl.value;
    n.updatedAt=new Date().toISOString();

    scheduleSave(450);
    if(!window._tgMetricsPending){
      window._tgMetricsPending=true;
      requestAnimationFrame(()=>{
        window._tgMetricsPending=false;
        updateStatusMetrics();
      });
    }
  }
}});root.addEventListener('keydown',e=>{if(e.key==='Escape'&&e.target.closest('.gooey-search'))e.target.closest('.gooey-search').querySelector('.gooey-clear').click()});root.addEventListener('dragover',e=>{const zone=e.target.closest('.upload-drop');if(zone){e.preventDefault();zone.classList.add('dragging')}});root.addEventListener('dragleave',e=>{const zone=e.target.closest('.upload-drop');if(zone&&!zone.contains(e.relatedTarget))zone.classList.remove('dragging')});root.addEventListener('drop',e=>{const zone=e.target.closest('.upload-drop');if(zone){e.preventDefault();zone.classList.remove('dragging');addImages(e.dataTransfer.files)}});picker.addEventListener('change',()=>{screen=picker.value;filter='';render();saveState()});root.addEventListener('change',async e=>{if(e.target.classList.contains('font-picker')){editorFont=e.target.value;applyEditorFont();persistNotes();say('Font updated');return}if(e.target.classList.contains('custom-font-upload')){importCustomFont(e.target.files?.[0]);e.target.value='';return}if(e.target.classList.contains('category-addon')){if(e.target.value){notes[chosen].tag=e.target.value;render();say('Added to category: '+notes[chosen].tag)}return}if(e.target.dataset.photoFor){const f=e.target.files[0];if(f&&f.type.startsWith('image/')){try{profiles[e.target.dataset.photoFor].photo=await readLocalPicture(f,384);persistNotes();render();say('Profile picture updated')}catch(err){say(err.message)}}return}if(e.target.classList.contains('note-profile')){const destination=e.target.value;if(destination!==activeProfile){const moved=notes.splice(chosen,1)[0];moved.tag='Uncategorized';workspaces[destination].notes.unshift(moved);chosen=0;screen='notes';render();say('Note moved to '+profiles[destination].name)}return}if(e.target.classList.contains('note-category')){notes[chosen].tag=e.target.value;render();say('Note category updated');return}if(e.target.classList.contains('image-upload'))addImages(e.target.files);if(e.target.dataset.setting==='theme'){root.style.colorScheme=e.target.value==='dark'?'dark':'light';if(window.TypeGridNative?.setTheme)window.TypeGridNative.setTheme(root.style.colorScheme);persistNotes();say(e.target.value==='dark'?'Dark mode on':'Light mode on')}if(e.target.dataset.setting==='size'){editorSize=Number(e.target.value);applyEditorZoom();persistNotes();say('Base font size set to '+editorSize+' px')}if(e.target.dataset.setting==='wrap'){isWordWrap=e.target.value==='on';root.querySelectorAll('[data-action="toggle-wrap"]').forEach(btn=>btn.classList.toggle('active',isWordWrap));persistNotes();say(isWordWrap?'Word wrap ON':'Word wrap OFF')}if(e.target.dataset.setting==='focus'){isFocusMode=e.target.value==='on';root.classList.toggle('focus-mode',isFocusMode);root.querySelector('[data-action="toggle-focus"]')?.classList.toggle('active',isFocusMode);persistNotes();say(isFocusMode?'Notepad Focus Mode enabled':'Standard workspace enabled')}if(e.target.dataset.setting==='tabsize'){editorTabSize=Number(e.target.value)===4?4:2;applyEditorTabSize();persistNotes();say('Tab indentation set to '+editorTabSize+' spaces')}if(e.target.classList.contains('split-note-picker')){const idx=+e.target.value;if(!Number.isNaN(idx)&&notes[idx]){splitChosen=idx;activePane='split';ensureTabOpen(idx);render();scheduleSave(200);return}}if(e.target.classList.contains('library-sort')){noteSort=e.target.value;const q=root.querySelector('.search')?.value||'';root.querySelector('.cards').innerHTML=cards(q);persistNotes()}});

root.addEventListener('pointerdown',e=>{if(e.target.closest('.editor-context'))e.preventDefault();if(e.button===2&&e.target.closest('.note-title,textarea.note-body'))e.preventDefault()},true);
async function pasteEditorSelection(t,start,end){
  await executePaste(t,start,end);
  closeEditorMenu();
}

async function executeCopy(targetEl) {
  const el = targetEl || getTargetField();
  if (!el) return;
  const start = el.selectionStart ?? 0;
  const end = el.selectionEnd ?? 0;
  let text = '';
  if (start !== end) {
    text = el.value.slice(start, end);
  } else if (el.classList.contains('note-title')) {
    text = el.value;
  } else {
    const val = el.value;
    const lineStart = val.lastIndexOf('\n', start - 1) + 1;
    let lineEnd = val.indexOf('\n', start);
    if (lineEnd === -1) lineEnd = val.length;
    text = val.slice(lineStart, lineEnd);
  }
  if (!text) {
    say('Nothing to copy');
    return;
  }
  let ok = false;
  if (window.TypeGridNative && typeof window.TypeGridNative.copy === 'function') {
    ok = !!window.TypeGridNative.copy(text);
  }
  if (!ok && navigator.clipboard && navigator.clipboard.writeText) {
    try { await navigator.clipboard.writeText(text); ok = true; } catch (_) {}
  }
  if (!ok) {
    try { el.focus(); ok = document.execCommand('copy'); } catch (_) {}
  }
  say(ok ? 'Copied' : 'Select text and press Ctrl+C');
}

async function executeCut(targetEl) {
  const el = targetEl || getTargetField();
  if (!el) return;
  const start = el.selectionStart ?? 0;
  const end = el.selectionEnd ?? 0;
  let text = '';
  let cutStart = start;
  let cutEnd = end;
  if (start !== end) {
    text = el.value.slice(start, end);
  } else if (el.classList.contains('note-title')) {
    cutStart = 0;
    cutEnd = el.value.length;
    text = el.value;
  } else {
    const val = el.value;
    cutStart = val.lastIndexOf('\n', start - 1) + 1;
    let lineEnd = val.indexOf('\n', start);
    if (lineEnd === -1) lineEnd = val.length;
    else lineEnd = lineEnd + 1;
    cutEnd = lineEnd;
    text = val.slice(cutStart, cutEnd);
  }
  if (!text) {
    say('Nothing to cut');
    return;
  }
  let ok = false;
  if (window.TypeGridNative && typeof window.TypeGridNative.copy === 'function') {
    ok = !!window.TypeGridNative.copy(text);
  }
  if (!ok && navigator.clipboard && navigator.clipboard.writeText) {
    try { await navigator.clipboard.writeText(text); ok = true; } catch (_) {}
  }
  if (ok) {
    replaceRangePreserveUndo(el, cutStart, cutEnd, '');
    el.dispatchEvent(new Event('input', { bubbles: true }));
    say('Cut');
  } else {
    say('Cut unavailable. Press Ctrl+X');
  }
}

async function executePaste(targetEl, explicitStart, explicitEnd) {
  const el = targetEl || getTargetField();
  if (!el) return;
  let text = '';
  if (window.TypeGridNative && typeof window.TypeGridNative.paste === 'function') {
    try { text = await window.TypeGridNative.paste(); } catch (_) {}
  }
  if (!text && navigator.clipboard && navigator.clipboard.readText) {
    try { text = await navigator.clipboard.readText(); } catch (_) {}
  }
  if (text) {
    const start = explicitStart ?? el.selectionStart ?? el.value.length;
    const end = explicitEnd ?? el.selectionEnd ?? el.value.length;
    const normalized = el.classList.contains('note-title') ? text.replace(/[\r\n]+/g, ' ') : text;
    replaceRangePreserveUndo(el, start, end, normalized);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    say('Pasted');
  } else {
    el.focus();
    try { document.execCommand('paste'); } catch (_) {}
  }
}

function executeSelectAll(targetEl) {
  const el = targetEl || getTargetField();
  if (!el) return;
  el.focus();
  el.select();
}

let editorSelection=null;
function closeEditorMenu(){const menu=root.querySelector('.editor-context');if(menu)menu.remove()}
function showEditorMenu(t,x,y){
  closeEditorMenu();
  editorSelection={target:t,start:t.selectionStart??0,end:t.selectionEnd??0};
  const menu=document.createElement('div');
  menu.className='editor-context';
  menu.setAttribute('role','group');
  menu.setAttribute('aria-label','Text selection actions');
  const items=[['copy','Copy'],['cut','Cut'],['paste','Paste'],['all','Select All'],['line','Select Line'],['with-above','Select Line + Line Above ↑'],['with-below','Select Line + Line Below ↓']];
  menu.innerHTML=items.map(([action,label])=>`<button data-text-action="${action}">${solarIcon(action)}<span>${label}</span></button>`).join('');
  const editorEl=t.closest('.editor');
  if(!editorEl)return;
  editorEl.appendChild(menu);
  const rect=editorEl.getBoundingClientRect();
  const mx=x-rect.left,my=y-rect.top;
  menu.style.left=Math.max(8,Math.min(mx,editorEl.clientWidth-menu.offsetWidth-8))+'px';
  menu.style.top=Math.max(8,Math.min(my,editorEl.clientHeight-menu.offsetHeight-8))+'px';
  menu.addEventListener('mousedown',e=>e.preventDefault());
}
root.addEventListener('contextmenu',e=>{
  const card=e.target.closest('[data-note]');
  if(card){e.preventDefault();chosen=+card.dataset.note;menuIndex=chosen;uploadOpen=false;shareOpen=false;render();return}
  const t=e.target.closest('.note-title,textarea.note-body');
  if(!t||!t.closest('.editor'))return;
  e.preventDefault();
  showEditorMenu(t,e.clientX,e.clientY);
});
root.addEventListener('keydown',e=>{
  if(e.key==='Escape')closeEditorMenu();
  if((e.key==='F10'&&e.shiftKey)||e.key==='ContextMenu'){
    const t=e.target;
    if(t.matches('.note-title,textarea.note-body')&&t.closest('.editor')){
      e.preventDefault();
      const r=t.getBoundingClientRect();
      showEditorMenu(t,r.left+25,r.top+25);
    }
  }
});
root.addEventListener('pointerdown',e=>{if(!e.target.closest('.editor-context'))closeEditorMenu();if(!e.target.closest('.tg-tools-wrap'))closeToolsMenu();if(!e.target.closest('.topbar-cat-wrap'))closeCatMenu()});
root.addEventListener('click', async e => {
  const b = e.target.closest('[data-text-action]');
  if (!b) return;
  const action = b.dataset.textAction;
  const targetEl = editorSelection?.target || getTargetField();
  const savedStart = editorSelection?.start;
  const savedEnd = editorSelection?.end;
  closeEditorMenu();
  if (action === 'cut') {
    await executeCut(targetEl);
  } else if (action === 'copy') {
    await executeCopy(targetEl);
  } else if (action === 'paste') {
    await executePaste(targetEl, savedStart, savedEnd);
  } else if (action === 'all') {
    executeSelectAll(targetEl);
  } else if (targetEl && (action === 'line' || action === 'with-above' || action === 'with-below')) {
    targetEl.focus();
    const val = targetEl.value;
    const pos = targetEl.selectionStart ?? 0;
    const lineStart = val.lastIndexOf('\n', pos - 1) + 1;
    let lineEnd = val.indexOf('\n', pos);
    if (lineEnd === -1) lineEnd = val.length;
    if (action === 'line') {
      targetEl.setSelectionRange(lineStart, lineEnd);
    } else if (action === 'with-above') {
      const prevStart = lineStart > 0 ? val.lastIndexOf('\n', lineStart - 2) + 1 : 0;
      targetEl.setSelectionRange(prevStart, lineEnd);
    } else if (action === 'with-below') {
      let nextEnd = lineEnd;
      if (lineEnd < val.length) {
        nextEnd = val.indexOf('\n', lineEnd + 1);
        if (nextEnd === -1) nextEnd = val.length;
      }
      targetEl.setSelectionRange(lineStart, nextEnd);
    }
  }
});

root.addEventListener('submit',e=>{
  if(e.target.dataset.profileForm){
    e.preventDefault();
    const id=e.target.dataset.profileForm;
    profiles[id].name=e.target.querySelector('.profile-name').value.trim()||'Admin';
    if(screen==='welcome'){setupComplete=true;switchProfile(id)}else{render()}
    persistNotes();
    say('Profile saved');
    return;
  }
  if(!e.target.classList.contains('category-form'))return;
  e.preventDefault();
  const f=e.target;
  const name=f.querySelector('input').value.trim();
  if(!name){f.querySelector('.category-error').textContent='Enter a category name.';return}
  if(name.toLowerCase()==='uncategorized'||categories.some(c=>c.toLowerCase()===name.toLowerCase())){f.querySelector('.category-error').textContent='That category already exists.';return}
  categories.push(name);f.reset();f.hidden=true;f.querySelector('.category-error').textContent='';
  closeCatMenu();render();persistNotes();say('Category created: '+name);
});

// Keyboard shortcuts & Notepad editor interactions
document.addEventListener('keydown', e => {
  const tgt = e.target instanceof Element ? e.target : null;
  if (tgt && tgt.matches('.note-title')) {
    if (e.key === 'Enter') {
      e.preventDefault();
      const t = getBodyEl();
      if (t) { t.focus(); t.setSelectionRange(0, 0); }
      return;
    }
    if (e.key === 'ArrowDown' && tgt.selectionEnd >= tgt.value.length) {
      const t = getBodyEl();
      if (t) { e.preventDefault(); t.focus(); t.setSelectionRange(0, 0); }
      return;
    }
  }
  if (tgt && tgt.matches('textarea.note-body') && e.key === 'ArrowUp') {
    if (tgt.selectionStart === 0 || !tgt.value.slice(0, tgt.selectionStart).includes('\n')) {
      const titleEl = getTitleEl();
      if (titleEl) {
        e.preventDefault();
        titleEl.focus();
        titleEl.setSelectionRange(titleEl.value.length, titleEl.value.length);
        return;
      }
    }
  }

  if (tgt && tgt.classList.contains('goto-input') && e.key === 'Enter') {
    e.preventDefault();
    const v = parseInt(tgt.value, 10);
    executeGoToLine(v);
    return;
  }

  if (e.key === 'Tab' && tgt && tgt.matches('textarea.note-body') && !e.ctrlKey && !e.altKey) {
    e.preventDefault();
    const t = tgt, s = t.selectionStart, end = t.selectionEnd;
    const indent = ' '.repeat(editorTabSize);
    if (e.shiftKey) {
      const ls = t.value.lastIndexOf('\n', s - 1) + 1;
      if (t.value.slice(ls, ls + editorTabSize) === indent) {
        replaceRangePreserveUndo(t, ls, ls + editorTabSize, '');
        t.setSelectionRange(Math.max(ls, s - editorTabSize), Math.max(ls, end - editorTabSize));
      } else if (t.value[ls] === '\t' || t.value[ls] === ' ') {
        replaceRangePreserveUndo(t, ls, ls + 1, '');
        t.setSelectionRange(Math.max(ls, s - 1), Math.max(ls, end - 1));
      }
    } else {
      replaceRangePreserveUndo(t, s, end, indent);
    }
    t.dispatchEvent(new Event('input', { bubbles: true }));
    updateStatusMetrics();
    return;
  }

  if (tgt && tgt.classList.contains('find-input') && e.key === 'Enter') {
    e.preventDefault();
    if (e.shiftKey) findPrev(); else findNext();
    return;
  }
  if (tgt && tgt.classList.contains('replace-input') && e.key === 'Enter') {
    e.preventDefault();
    replaceOne();
    return;
  }

  const isCtrl = e.ctrlKey || e.metaKey;
  if (e.key === 'Escape') {
    const layer = root.querySelector('.modal-layer');
    if (layer && !layer.hidden) { e.preventDefault(); closeModal(); return; }
    if (findOpen) {
      e.preventDefault();
      findOpen = false;
      root.querySelector('.toolbar [data-action="open-find"]')?.classList.remove('active');
      syncFindBarUI();
      getBodyEl()?.focus();
      return;
    }
  }
  if (e.key === 'F1') { e.preventDefault(); showShortcutsModal(); return; }
  if (e.key === 'F5' && !isCtrl && screen === 'editor') { e.preventDefault(); runEditorTool('tool-datetime'); return; }
  if (e.altKey && !isCtrl && e.key.toLowerCase() === 'p') { e.preventDefault(); toggleAlwaysOnTop(); return; }

  if (isCtrl) {
    const k = e.key.toLowerCase();
    if (e.key === '+' || e.key === '=') {
      e.preventDefault();
      editorZoom = Math.min(200, editorZoom + 10);
      applyEditorZoom();
      scheduleSave(300);
      return;
    }
    if (e.key === '-' || e.key === '_') {
      e.preventDefault();
      editorZoom = Math.max(50, editorZoom - 10);
      applyEditorZoom();
      scheduleSave(300);
      return;
    }
    if (e.key === '0') {
      e.preventDefault();
      editorZoom = 100;
      applyEditorZoom();
      scheduleSave(300);
      return;
    }
    if (k === 's' && !e.shiftKey) {
      e.preventDefault();
      const n = notes[getPaneIndex()];
      if (n && n.filePath && window.TypeGridNative?.saveFile) {
        saveCurrentNoteToDisk(false);
      } else {
        flushSave();
        say('✓ Note saved to device');
      }
      return;
    }
    if (k === 's' && e.shiftKey) { e.preventDefault(); saveCurrentNoteToDisk(true); return; }
    if (e.key === '\\') {
      e.preventDefault();
      root.querySelector('[data-action="toggle-split"]')?.click();
      return;
    }
    if (k === 'n') {
      e.preventDefault();
      notes.unshift({ title: '', tag: 'Uncategorized', body: '', createdAt: new Date().toISOString() });
      onNoteInsertedAtZero(); screen = 'editor'; render(); flushSave();
      setTimeout(() => getTitleEl('primary')?.focus(), 20);
      return;
    }
    if (k === 'o') { e.preventDefault(); triggerOpenFile(); return; }
    if (k === 'f') {
      e.preventDefault();
      findOpen = true; replaceOpen = false;
      root.querySelector('.toolbar [data-action="open-find"]')?.classList.add('active');
      syncFindBarUI();
      const inp = root.querySelector('.find-input');
      const t = getBodyEl();
      if (inp && t) {
        const s = t.value.slice(t.selectionStart || 0, t.selectionEnd || 0);
        if (s && s.length < 80 && !s.includes('\n')) { inp.value = s; findQuery = s; }
        inp.focus(); inp.select(); updateFindMatches(false);
      }
      return;
    }
    if (k === 'h') {
      e.preventDefault();
      findOpen = true; replaceOpen = true;
      root.querySelector('.toolbar [data-action="open-find"]')?.classList.add('active');
      syncFindBarUI();
      const inp = root.querySelector('.find-input');
      inp?.focus(); inp?.select(); updateFindMatches(false);
      return;
    }
    if (k === 'd' && screen === 'editor') { e.preventDefault(); runEditorTool('tool-dup-line'); return; }
    if (k === 'g') { e.preventDefault(); openGoToLine(); return; }
    if (k === 'w') { e.preventDefault(); toggleWordWrap(); return; }
    if (k === 'b') { e.preventDefault(); toggleFocusMode(); return; }
    if (k === 't') { e.preventDefault(); toggleTheme(); return; }
    if (k === 'p') { e.preventDefault(); const n = notes[getPaneIndex()]; if (n) exportNotePdf(n); return; }
  }
});

// Live Notepad cursor position metrics
document.addEventListener('selectionchange', () => {
  const active = document.activeElement;
  if (active && active.matches && active.matches('textarea.note-body')) {
    updateStatusMetrics();
  }
});
root.addEventListener('click', e => {
  if (e.target.matches('textarea.note-body')) updateStatusMetrics();
});
root.addEventListener('keyup', e => {
  if (e.target.matches('textarea.note-body')) updateStatusMetrics();
});

// Single clean drag-and-drop handler for any file + images
window.addEventListener('dragover', e => {
  e.preventDefault();
  if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
});
window.addEventListener('drop', async e => {
  const zone = e.target.closest('.upload-drop');
  if (zone) return; // handled by .upload-drop listener
  e.preventDefault();
  const files = e.dataTransfer?.files;
  if (!files || !files.length) return;
  const imgFiles = [];
  for (const f of files) {
    if (f.type && f.type.startsWith('image/')) imgFiles.push(f);
    else await loadFileIntoNote(f);
  }
  if (imgFiles.length) await addImages(imgFiles);
});

const tgFileInp = document.getElementById('tg-file-importer');
if (tgFileInp) {
  tgFileInp.addEventListener('change', e => {
    if (e.target.files && e.target.files[0]) loadFileIntoNote(e.target.files[0]);
  });
}

window.addEventListener('blur', () => flushSave());
window.addEventListener('beforeunload', () => flushSave());
window.addEventListener('resize', () => { if (screen === 'editor') autoSizeTitle(); });

window.typeGridBack=()=>{if(root.classList.contains('mobile-nav-open')){toggleMobileNav();return true}if(root.querySelector('.editor-context')){closeEditorMenu();return true}if(menuIndex!==null){menuIndex=null;render();return true}if(screen!=='notes'){screen='notes';uploadOpen=false;shareOpen=false;render();return true}return false};

restoreNotes();
for(const w of Object.values(workspaces))for(const n of [...w.notes,...w.trash])n.createdAt=n.createdAt||n.updatedAt||new Date().toISOString();
chosen=Math.min(chosen,Math.max(0,notes.length-1));
screen=setupComplete?'editor':'welcome';
render();
if(screen==='welcome'){setupComplete=true;persistNotes()}
if(isAlwaysOnTop)toggleAlwaysOnTop(true);
migrateLegacyAttachments();

// External file launch / Explorer "Open with" inside IIFE scope
if (window.TypeGridNative && typeof window.TypeGridNative.onOpenExternalFile === 'function') {
  window.TypeGridNative.onOpenExternalFile(fileData => {
    if (fileData) loadFileIntoNote(fileData);
  });
}
if (window.TypeGridNative && typeof window.TypeGridNative.getStartupFile === 'function') {
  window.TypeGridNative.getStartupFile().then(fileData => {
    if (fileData) loadFileIntoNote(fileData);
  }).catch(() => {});
}
})();

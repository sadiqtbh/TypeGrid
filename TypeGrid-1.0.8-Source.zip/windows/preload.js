const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('TypeGridNative', {
  appVersion: '1.0.8',
  load: () => ipcRenderer.sendSync('typegrid:load'),
  save: (data) => ipcRenderer.sendSync('typegrid:save', data),
  saveAsync: (data) => ipcRenderer.invoke('typegrid:save-async', data),
  saveAttachment: (dataUrl) => ipcRenderer.invoke('typegrid:save-attachment', dataUrl),
  migrateAttachments: (dataUrls) => ipcRenderer.invoke('typegrid:migrate-attachments', dataUrls),
  copy: (text) => ipcRenderer.sendSync('typegrid:copy', text),
  paste: () => ipcRenderer.invoke('typegrid:paste'),
  openFileDialog: () => ipcRenderer.invoke('typegrid:open-file-dialog'),
  readFile: (filePath) => ipcRenderer.invoke('typegrid:read-file', filePath),
  saveFile: (targetPath, text, eol) => ipcRenderer.invoke('typegrid:save-file', targetPath, text, eol),
  getStartupFile: () => ipcRenderer.invoke('typegrid:get-startup-file'),
  onOpenExternalFile: (callback) => {
    ipcRenderer.on('typegrid:open-external-file', (_, fileData) => {
      if (typeof callback === 'function') callback(fileData);
    });
  },
  exportText: (text, name, eol) => ipcRenderer.invoke('typegrid:export', text, name, eol),
  exportDocx: (b64, name) => ipcRenderer.invoke('typegrid:export-docx', b64, name),
  exportPdf: (html, name) => ipcRenderer.invoke('typegrid:export-pdf', html, name),
  registerOpenWith: (force = true) => ipcRenderer.invoke('typegrid:register-open-with', force),
  setTheme: (theme) => ipcRenderer.send('typegrid:set-theme', theme),
  setAlwaysOnTop: (flag) => ipcRenderer.invoke('typegrid:set-always-on-top', flag),
  getAlwaysOnTop: () => ipcRenderer.invoke('typegrid:get-always-on-top'),
  windowAction: (action) => ipcRenderer.send('typegrid:window', action),
});
